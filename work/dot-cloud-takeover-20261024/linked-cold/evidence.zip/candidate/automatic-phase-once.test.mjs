import test from 'node:test';
import {roundTrip} from './automatic-phase-helper.mjs';
test('once-only body-free phases of unchanged original automatic small case',t=>roundTrip(t,true));
