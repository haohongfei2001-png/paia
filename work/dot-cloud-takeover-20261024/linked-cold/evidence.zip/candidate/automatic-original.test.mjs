import test from 'node:test';
import {roundTrip} from '../worktree-linked-cold/extension/tests/harness/context-mutation-shadow.mjs';
test('automatic Context original full small roundTrip(t,true), unchanged owning helper',t=>roundTrip(t,true));
