# Exact Working future state → cold linked Human composition

## Frozen candidate and result

- Candidate: `473349ba329cfbec979745ba90d83830d01a9a43`.
- Parent: `0130ad1080761616b198a1dcc2b299424f638fc0`, independently reviewed applications-first/finally lifetime on integrated C/Q/H/R/S.
- Branch: `codex/dot-cloud-linked-cold-20261024`; worktree `worktree-linked-cold`, clean and frozen. No push or main/PR change.
- Six runtime paths, one new owning test. No IDB/recovery/selection/Assist/Next modification, schema, version, dependency, timeout, budget or native-linked guard change.
- Final exact-code combination: **199/199 PASS**, 14290.561845 ms, 13 complete small files; zero fail/cancel/skip/todo. It includes the new **20 cases**, original lifetime16, original owner108, original Human search completeness19, and original R causal-tail36.
- Cloud Node v24.19.0, Linux x86_64. Node fake-IDB / in-memory transport or synthetic HTTP only. No native browser, Mac, Node22, Full, original100k, 129-group recovery, cloud diagnostic, install or deployment.

This closes a finite **generic cold Source/Working/linked-Human consumer**, not native-linked qualification or the complete automatic Context case. The unchanged original automatic Context helper first ran before the final terminal-epoch repair and remains **0/1 FAIL**, `BNS_GROUP_RESOURCE_LIMIT`. A separately approved **one-time phase-only diagnostic on final473349ba** also failed0/1 at fresh C activation, after completing B activation and cold B publication. No complete automatic success is inferred from either partial execution or the separate generic cases.

## Exact implementation and consuming path

1. `group-checkpoint-plan.js`: linked generic graphs may contain the original Working and Context families, but only one original Source bootstrap. Every linked evidence edge must name that exact Source record, Source identity, Input and the exact final Working content revision. The actual producer is a causal dependency. Missing, stale, future and substituted identities fail. `binding.currentSourceWorking` still refuses native/currentMixed linked graphs.
2. `input-working-commit.js`: both projectors share the complete operation-vector authentication, including unique revision IDs, exact Store/Core and original private capability. Source projection also requires exact original plan membership, original Source capability contents and the exact preceding Input/InputState operation or original bootstrap. It invokes the original `qualifyWorking`, preserving Source/filter/removal/purge/identity/content-revision checks. Reuse is refused.
3. The same file predicts only the original two-row invalidation effect by calling the fixed `enqueueInvalidation` implementation on a private detached effect. It does not infer epoch from a total Working count. Before and after the actual `applyWorkingOwner`, it checks the real epoch and real original invalidation event. It retains that real event through an original final-read fence; no success DTO or alternate writer replaces the original owner.
4. `human-library-plan.js`: the original private graph consumes that Source/Input/epoch effect together with the existing exact Working history/counter projection. Original `prepareHumanGraphNamedPlan`, original evidence hashing, membership, permissions and original Human writers remain authoritative. Existing linked provenance/dependencies prevent Working from being reordered after the linked consumer.
5. `human-library-group.js` and `group-checkpoint.js`: the cold coordinator passes its exact prepared application list, now explicitly dispatching Source and Working before the actual named Human owners. The existing lifetime finally/release remains unchanged. The original Human application also retains the exact future epoch and seals it through an original final-read fence after the real canonical Scope check. This prevents a late epoch change from certifying stale evidence.
6. `human-library-scope.js`: `compileHumanScope` privately binds its genuine wire object to the original immutable plan. Existing exact Scope/wire preparation checks remain. Linked Working scope expectations execute the same original invalidation rule in causal order from the complete cold-empty cut, then require exact actual epoch and provenance/dependency rows. The native-linked guard remains unchanged and exercised negatively.

All R restriction-only ticket registration/window/deadline propagation code is byte-identical to the parent. All original canonical-generation whole-table terminal fences remain. H's complete pending-locator proof remains, with original owning19/19 in the final combination.

## New owning coverage

- One and two genuine Working producers followed by original linked Entry/Topic placement, preserving immutable Source, body/note, content revision, original local epoch, complete history, protections and pending search.
- Original linked removal/restore, full negative suppression/history through cold B and C; no replay resurrection.
- Real edited Input `addToTopics` whole binding and exact excerpt, consuming original Working future state and preserving the authentic span and bindings.
- Foreign Store/Core, copied capability, cloned plan/group, substituted complete vectors, mutated original Source content/identity and changed prior Input/InputState all refuse. Reuse and post-release use refuse.
- Resealed self-consistent member/link shapes with wrong Source identity, Source record, Input identity, earlier or future content revision reach and fail the original graph causal check. They do not fabricate a passing owner.
- Genuine nonempty Human target refusal after staging captures/revokes the actual original Working cap and preserves every target table. Real target pause via `setEnabled(false)` refuses rather than importing permission.
- Faults after an applied group, before activation and after activation roll back all tables and release capabilities.
- Late real invalidation event corruption is refused by its actual terminal fence; late actual epoch corruption is refused by the Human terminal proof. The repository surfaces these aborted final fences as `STORAGE_FAILED`; the test does not claim its outer API preserves the inner semantic code.
- The actual complete original Scope rejects missing pending locators, changed provenance/dependency/history, removed suppression, extra tombstone and unqualified search term; every rejected transaction rolls back every table.
- The genuine generic-positive graph remains rejected by the untouched native/currentMixed linked guard.

## Preserved evidence chronology

- `01-first-owning.log`: 0/2, **test oracle error**. Actual cold activation succeeded, but the new test incorrectly compared local keyed Topic name tokens as portable history. No runtime workaround was made. The corrected assertion uses original `portableHumanEntity` and `normalizePhysical`.
- `02-parent-causal-red.log`: genuine frozen parent0130ad1, 0/2, original `BNS_HUMAN_UNSUPPORTED` graph gate. `parent-causal-red.test.mjs` points only at the untouched frozen parent.
- `03-owning-oracle.log`: 2/2 PASS, 1600.749859 ms.
- `04-source-identity.log`: exact original Source/preceding operation checks, 2/2 PASS, 1891.107428 ms.
- `05-complete-first.log`: 9/17 PASS, 8 FAIL, 8102.610654 ms. Diagnostic setup mistakes: expected an inner final-fence code instead of outer `STORAGE_FAILED`; created target Human after rather than before staging; called unsupported `consent(false)` instead of real `setEnabled(false)`; five malformed link-only changes failed the original Human group validator before the intended graph check. These failures are retained. Corrected fixtures use original owners and internally consistent resealed link/Entry/request fields, not relaxed runtime guards.
- `06-complete-controls.log`: 17/17 PASS, 7151.908446 ms.
- `07-original-owners.log`: ten full original small files,124/124 PASS,8677.851259 ms.
- `08-recovery-ticket.log`: complete original R causal-tail36/36 PASS,7905.495051 ms.
- `09-automatic-original.log`: original full small `roundTrip(t,true)` helper unchanged,0/1 FAIL,6391.082604 ms. Error is `BNS_GROUP_RESOURCE_LIMIT` at IDB repository579:1340 → generationTransaction60:13 → cold activation284:54 → original store queue203:11. The runtime six-file snapshot in `automatic-executed-runtime/` reconstructs those executed bytes before the final epoch-fence repair; it is evidence, not the final candidate.
- `10-late-epoch-control.log`: genuine **new candidate defect**,0/1 FAIL,1048.852611 ms. An after-activation `thought-epoch` mutation could commit after all earlier guards. No exception or authority was fabricated. This directly motivated the consumed original Human terminal fence.
- `11-terminal-epoch-fixed.log`: complete18/18 PASS,8988.994155 ms after the real terminal fix.
- `12-frozen-combination.log`: final thirteen complete files199/199 PASS,14290.561845 ms; includes the additional two real Input consumers.

Original historical four automatic attempts remain FAIL. Original 3454 references /2099146 bytes/237ms, including **1994 bytes over2MiB**, remain their old identities. They are **not** measurements of09 or this final candidate.

The original source-linked owner file contains its small suppression pagination checks at65/128/129 rows; these are not the exhausted129-group recovery scenario. `browser-native-sync-group-checkpoint-restore.test.mjs` and all large/full/native/cloud suites were deliberately not run.

## Exact final command

`node --test extension/tests/human-source-working-cold-composition.test.mjs extension/tests/working-application-lifetime.test.mjs extension/tests/browser-native-sync-input-working-receive.test.mjs extension/tests/source-working-restored-successor.test.mjs extension/tests/browser-native-sync-human-library-group.test.mjs extension/tests/browser-native-sync-saved-mixed.test.mjs extension/tests/consumer-preference-group-restore.test.mjs extension/tests/canonical-generation-owner-restore.test.mjs extension/tests/human-source-entry-plan.test.mjs extension/tests/human-source-placement.test.mjs extension/tests/human-graph-future-read-set.test.mjs extension/tests/human-scope-search-completeness.test.mjs extension/tests/browser-native-sync-recovery-causal-tail.test.mjs`

All six runtime files and the owning test pass `node --check`. `git diff --check` passed before the commit. Exact frozen hashes are in `SHA256SUMS`; frozen patch, owning test, identity and all logs accompany this report.

## Initial read-only failure localization and bounded proposal (historical before approval)

Read-only inspection of the complete saved stack cannot distinguish B from C: both call the same `activate` helper and `GroupedCheckpointRestore.activate` line. No B/C marker or detailed numeric work ticket was emitted. IDB repository579 deliberately replaces a failed private work limit with an `ArchiveError('BNS_GROUP_RESOURCE_LIMIT')` without carrying the private reference/byte/time totals. Runtime duration is not phase evidence.

If a further diagnostic is approved after independent review, use **one** copy of the exact existing small helper, changing only import paths and adding body-free synchronous phase markers immediately before/after its existing B activation, cold B publication and C activation awaits. Keep every original command, assertion, fixture size, meter, threshold and timeout unchanged. This identifies which real original await failed without replacing or monkeypatching an owner, and does not report private content, IDs or the value of any row. Stop at its first failure; do not automatically retry, alter budgets or add matrix points. At the initial report this proposal had **not been run**; the separately approved result is appended below. It is the original synthetic small Node case, not129-group/100k/native/browser/cloud diagnostic qualification.

Native Source-linked currentMixed raw view, provenance/dependency physical metering, native indexed search/table proof, and complete automatic Context round-trip remain separate open qualifications. No default activation or existing-library Selection gate is unlocked.


## Approved one-time phase diagnostic on frozen final code

After the preceding report and explicit parent authorization, exactly one phase-only copy ran on `473349ba329cfbec979745ba90d83830d01a9a43`. Frozen runtime and tests stayed unchanged and the worktree remained clean. `automatic-phase-helper.diff` and `automatic-phase-proof.json` show that reversing only the necessary absolute-import resolution and six phase markers reproduces the original helper byte-for-byte. Original helper SHA256: `2b7e4557be7c4e5675b9b5f731f9f38143c8243846249a04ec716dc539b832a7`.

Command: `node --test ../evidence-linked-cold/automatic-phase-once.test.mjs`.

`13-automatic-phase-once.log`: **0/1 FAIL**,5619.840146ms,exit1. Exact emitted stages:

1. `B_ACTIVATE_BEGIN`
2. `B_ACTIVATE_COMPLETE`
3. `COLD_B_PUBLISH_BEGIN`
4. `COLD_B_PUBLISH_COMPLETE`
5. `C_ACTIVATE_BEGIN`
6. Original `BNS_GROUP_RESOURCE_LIMIT`; no C-complete marker.

This localizes the current failure to the genuine **fresh C protected activation**, not B. The existing B helper completed its original restore, publication qualification, seal/reserve/recover, checkpoint-copy retirement and original active-store binding. The unchanged cold B path then executed its original undo/edit, automatic-Item human adoption and original re-publication before fresh C staging and activation. This is partial synthetic evidence only, not complete round-trip acceptance, native-linked export or a full-table/indexed native comparison. There is still no current references/bytes measurement or unique cause established.

The one authorized diagnostic is consumed. No second run, budget enlargement, source/meter alteration, assertion removal, timeout or fixture-scale change was performed. The previous proposal is now historical; any further execution needs a new scoped parent decision.
