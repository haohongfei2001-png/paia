import {portableHumanEntity} from '../worktree-working-lifetime/extension/core/browser-native-sync/human-library-codec.js';
import {normalizePhysical} from '../worktree-working-lifetime/extension/core/browser-native-sync/human-library-journal.js';
import test from 'node:test';
import assert from 'node:assert/strict';
import {IDBFactory,IDBKeyRange} from '../worktree-working-lifetime/extension/tests/vendor/fake-indexeddb/build/esm/index.js';
import {local,capture,inputEdit} from '../worktree-working-lifetime/extension/tests/harness/thought-m1.mjs';
import {LibraryDocumentsStore} from '../worktree-working-lifetime/extension/core/library-documents-store.js';
import {BrowserNativeSyncCore,sealOperation} from '../worktree-working-lifetime/extension/core/browser-native-sync/core.js';
import {SourceBootstrapJournal} from '../worktree-working-lifetime/extension/core/browser-native-sync/source-bootstrap-journal.js';
import {FilterIntentSyncJournal} from '../worktree-working-lifetime/extension/core/browser-native-sync/filter-intent-journal.js';
import {InputWorkingSyncJournal} from '../worktree-working-lifetime/extension/core/browser-native-sync/input-working-journal.js';
import {HumanLibrarySyncJournal} from '../worktree-working-lifetime/extension/core/browser-native-sync/human-library-journal.js';
import {InputWorkingCommitReceiver,prepareWorkingApplication,projectOriginalWorkingHistory,releaseOriginalWorkingApplication} from '../worktree-working-lifetime/extension/core/browser-native-sync/input-working-commit.js';
import {prepareGroupCheckpointPlan,prepareCurrentMixedGroupCheckpointPlan} from '../worktree-working-lifetime/extension/core/browser-native-sync/group-checkpoint-plan.js';
import {prepareGroupScope,requireGroupScope} from '../worktree-working-lifetime/extension/core/browser-native-sync/group-checkpoint-scope.js';
import {initialSourcePlan} from '../worktree-working-lifetime/extension/core/browser-native-sync/source-bootstrap-plan.js';
import {buildCheckpoint} from '../worktree-working-lifetime/extension/core/browser-native-sync/checkpoints.js';
import {GroupedCheckpointRestore} from '../worktree-working-lifetime/extension/core/browser-native-sync/group-checkpoint.js';
globalThis.IDBKeyRange=IDBKeyRange;
const portableHistory=async rows=>{const secret=rows.meta.find(r=>r.id==='thought-suppression-key').value;return (await Promise.all(rows.revisions.map(async r=>r.kind==='input'?{...r,sequence:null,listKey:null,documentList:null}:normalizePhysical('history',await portableHumanEntity('history',r,rows.revisions,secret))))).sort((a,b)=>a.id.localeCompare(b.id));};
const id=()=>crypto.randomUUID(),snapshot=s=>s.repository.transaction(false,async t=>Object.fromEntries(await Promise.all(s.repository.stores.map(async n=>[n,await t.all(n)]))));
async function operations(core){const rows=[];for await(const row of core.rows('revision'))rows.push(row.operation);return rows;}
async function device(t){const s=new LibraryDocumentsStore(local(),{indexedDB:new IDBFactory()});await s.consent(true);await s.finishFoundation();t.after(()=>s.repository.close());const core=new BrowserNativeSyncCore(s.repository,{datasetId:'SYNTHETIC_linked_working_cold',deviceId:id()});s.sourceBootstrapJournal=new SourceBootstrapJournal(core);s.filterIntentJournal=new FilterIntentSyncJournal(core);s.inputWorkingJournal=new InputWorkingSyncJournal(core,{filterJournal:s.filterIntentJournal,logicalCommits:true});s.humanLibraryJournal=new HumanLibrarySyncJournal(core);return {s,core};}
async function fixture(t,{count=1,negative=false,checkpoint=async()=>{},prepare=true}={}){
 const a=await device(t),topic=await a.s.createTopic({name:'SYNTHETIC exact original Topic',operationId:id()});await a.s.capture(capture((await a.s.status()).epoch));const input=(await a.s.snapshot()).library.blocks[0];
 for(let n=0;n<count;n++)await inputEdit(a.s,input.id,{libraryText:'SYNTHETIC Working 中文🙂 '+n,note:'SYNTHETIC selected note '+n});
 const evidence=await a.s.evidenceFor([{inputId:input.id,role:'primary',selectedFields:['body','note']}]),entry=await a.s.createEntry({actor:'user',body:'SYNTHETIC protected Human inference',type:'idea',formation:'explicit',evidence,operationId:id()});
 if(negative){await a.s.removeEntry({id:entry.id,expectedRevision:0,operationId:id()});}
 else await a.s.placeEntry({entryId:entry.id,topicId:topic.id,expectedEntryRevision:0,expectedTopicRevision:0,operationId:id()});
 const rows=new Map(),cloud={async putImmutable(ref,raw){rows.set(ref.id,raw.slice());},async get(ref){return rows.get(ref.id)?.slice();}},b=await device(t),restore=new GroupedCheckpointRestore(b.core,{store:b.s,restoreId:id(),checkpoint});
 let cut;if(prepare){cut=await buildCheckpoint(a.core,cloud,{grouped:{store:a.s}});await restore.stageCheckpoint(cut.ref,r=>cloud.get(r));}return {a,b,input,topic,entry,evidence,cloud,restore,cut};
}
for(const count of [1,2])test(`${count} original Working producers → linked Human preserve source, exact local epoch, history and pending search through cold B`,async t=>{
 const f=await fixture(t,{count}),before=await snapshot(f.a.s);assert.equal((await f.restore.activate()).state,'activated');const after=await snapshot(f.b.s);
 assert.equal(after.blocks[0].value.libraryText,'SYNTHETIC Working 中文🙂 '+(count-1));assert.deepEqual(after.records,before.records);assert.equal(after.inputStates[0].contentRevision,count);assert.equal(after.dependencies[0].eligibilityEpochAtUse,count);assert.equal(after.meta.find(r=>r.id==='thought-epoch').value,count);assert.equal(after.invalidations.length,count);
 assert.deepEqual(after.thoughts.map(r=>({...r,exactSignature:null})),before.thoughts.map(r=>({...r,exactSignature:null})));assert.deepEqual(after.placements,before.placements);assert.deepEqual(await portableHistory(after),await portableHistory(before));
 assert.notEqual(after.provenance[0].scopeToken,before.provenance[0].scopeToken);assert.equal(after.provenance[0].basedOnContentRevision,count);
 const p=await prepareGroupCheckpointPlan(f.b.core,await operations(f.b.core)),scope=await prepareGroupScope(p,{store:f.b.s});await f.b.core.transaction(false,t=>requireGroupScope(f.b.s,t,scope));assert.equal(after.libraryMigrationItems.length,after.thoughts.length+after.topics.length+after.sections.length);const stable=await snapshot(f.b.s);await f.restore.activate();assert.deepEqual(await snapshot(f.b.s),stable);
});
