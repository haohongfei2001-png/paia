# Worker selection admission prerequisites, 2026-10-24

Base: `1632908ab836738ea8c1f57308ae7c2610f670ef`. This is bounded cloud-source engineering only. No browser/native, Full/C-phase, 129-group, 100k, live account/provider, paid call, installation or deployment ran.

## Implemented

- The actual worker constructs the original worker coordinator from its one selected Store, Safety, Library, Filter, Maintenance, Context, Assist, Next, manual Prompt and surface instances. Construction neither acquires a hold nor supplies activation authority.
- Actual runtime ingress now consults the existing page guard before early dispatch and after startup awaits. This covers the previous early Prompt, Import, Sync, Maintenance-processing, Archive-arrival and content-capture bypasses. Original registered pages may finish saves before their FROZEN ACK. Fixed observation and provably restrictive command shapes retain their original owner authentication/validation. No GET/STATUS prefix is a blanket exception. Mixed Assist/Filter changes that could expand one permission are not classified as restriction-only.
- The worker observes actual accepted message completion, its explicit post-response notification and Maintenance/local-runner promises, startup/reconcile/settings/tab/port lifecycle callback promises, and original delayed Import publication. A coalesced Import timer retains its pending lifetime until the replacement publication settles. Repeated original local-runner drains are observed through their actual running promises.
- The activity drain returns no token or readiness flag. It is not a success receipt, does not stop ingress, and does not establish host/provider/cold quiescence.

## Deliberately incomplete production composition

No production selection command calls `freezeExtensionPages`, the source hold, or this activity drain. Current PREPARE remains the exact original read-only complete-cut review. ACTIVATE, CONTINUE and RESTART retain their original unconditional protection refusal. There is no marker write, backend activation or reload path added.

A source hold is not observational: original Context can close native listeners, Next can retire offers, and Assist can invalidate/cancel existing work. Applying those effects to PREPARE would violate its read-only contract. Performing them on an attempt guaranteed to refuse would unnecessarily alter user state without an attainable selection outcome. The independent reviewer and integration owner agreed not to manufacture a cosmetic consumer.

The observer currently tracks generation-command lifetimes too. A future admitted selection consumer must explicitly exclude its own active command before awaiting the drain, without skipping unrelated accepted work; otherwise it would await itself. No blanket command skip or workaround is introduced while that consumer is absent.

A future genuine admitted selection consumer still needs the original cross-page proof composed with source holds, a complete content/host freeze and acknowledged insertion/provider settlement, cold restart/unknown-outcome witnesses, all live event/transport producers and exact generation revalidation. Configured Maintenance refusal remains. Capture-recovery injection/probing and owner-internal asynchronous native/provider tasks are not certified by this worker's explicit-promise observer; their actual owners and native closure contracts remain necessary. Merely observing an empty worker task set, holding local runners or constructing the coordinator cannot bypass those requirements.

## Bounded evidence

1. `first-six.tap`: 6/6 new actual-worker/helper tests, before the later allowlist narrowing and extra cases. Historical scope only.
2. `regression-forty.tap`: 40/40 across complete application editor guard, selection consumer, selection editor safety, coordinator, worker admission (then six cases), Settings AI-style worker and update worker files. No failures, cancellations, skips or todo.
3. `final-owning-eight.tap`: final complete worker-admission file, 8/8. Includes actual guarded early routes, pre-ACK page save, actual post-response host-notification delay, both original delayed/coalesced Import publication paths, actual repeated local-maintenance successor, fixed restrictive shapes and nested promise accounting. Synthetic IndexedDB and ports only.

4. `final-regression-forty-two.tap`: final exact source with all eight owning cases plus the same six original complete regression files, 42/42. No failures, cancellations, skips or todo.

Original selection tests continue to assert unchanged canonical snapshots, no selection markers/reloads and false activation controls. These passes are not native, host, cold-provider, Full, main, performance or whole-programme acceptance. Root owns final integration and publication.

## Reviewed Close-path successor

The manual Prompt owner now permits its authenticated restrictive `close` RPC while held. Independent cross-owner review found that the worker's fixed exception list still denied that exact child RPC after permitting `REQUEST_CLOSE`. The worker now admits only the one-field `{type:'close'}` command shape; the original surface still validates its outer request, caller, nonce, live document and host ACK. Ordinary surface commands and malformed Close payloads remain denied. `close-successor-forty-two.tap` records the complete final seven-file 42/42 regression after this correction, with zero failures/cancellations/skips/todo. No selection consumer or activation path changed.

## Reviewed actual-startup construction correction

Independent integration review found an actual default startup defect missed by owner fixtures that pre-initialized their Store. `selectOriginalApplicationStore` with default-null configuration returns an unopened original Store. The new manual/surface birth identities and coordinator captured its not-yet-open database and not-yet-loaded databaseId before the previous later recovery/startup tasks initialized them. Immutable original identity checks then correctly refused that changed identity forever.

The worker now completes the original `recoverControlPublication()` and original read-only `status()` control snapshot immediately after selecting the Store, before constructing any services that capture its birth identity. The later duplicate recovery call is removed. Recovery alone opens the repository but does not populate `Store.databaseId` on the ordinary absent-reservation path; the original status/run owner supplies that identity. No owner guard was weakened, refreshed or rebound, and no direct mutable identity assignment was added.

Exact dependency composition for this correction: manual Prompt owner `4735c6bc8e1b2d7f4dcdf322fea5c251dc147602` (`prompt-reuse-commands.js`, `prompt-surface.js`) plus coordinator owner `72cf92b9203452b887e6bd1b54bcb6b7837ff716` (`application-worker-coordination.js`, `context-connections.js`, `prompt-assist.js`, `prompt-next.js`). Only the worker's own paths are committed here. The isolated `worker-startup-composition` tree supplied those exact dependency bytes; `startup-composition-SHA256SUMS` binds the relevant final runtime/test bytes.

- `startup-pre-fix-negative.tap`: one bounded deliberate reproduction against pre-fix worker `15eb40f5` with the composed original owners and new regression. 0/1, failed with `GENERATION_WORKER_NOT_QUIET` at the original local hold, as expected. This remains a failure record, not a pass.
- `startup-composition-forty-three.tap`: complete final seven-file corrected composition, 43/43, no failures/cancellations/skips/todo. Includes all original pending-selection/failed-ready STATUS/CANCEL, read-only PREPARE/no-marker/no-reload cases, and the new actual default unopened-Store lifecycle regression.
- `startup-corrected-positive.tap`: after restoring the exact corrected worker bytes from the negative control, the new actual default startup case passes 1/1. It verifies real local coordinator hold/release and separate manual/surface hold/fence/release; full source hold still refuses the absent Assist provider session, and manual intake remains usable.

This fixes genuine source binding at startup, not production activation or any missing native/host/cold witness. The unintegrated consumer and self-command exclusion requirements above remain unchanged.
