import test from 'node:test';
import assert from 'node:assert/strict';
import {setup} from 'file:///workspace/scratch/ff1c41bf9b29/paia-cloud-dev-20261024/context-transport-witness-20261024/extension/tests/harness/thought-m1.mjs';
import {OrganizerStore} from 'file:///workspace/scratch/ff1c41bf9b29/paia-cloud-dev-20261024/context-transport-witness-20261024/extension/core/organizer/store.js';
import {ContextCardsService} from 'file:///workspace/scratch/ff1c41bf9b29/paia-cloud-dev-20261024/context-transport-witness-20261024/extension/core/context-cards.js';
import {ContextConnections,CONTEXT_CONNECTION_KEY,CONTEXT_RESUME_WITNESS} from 'file:///workspace/scratch/ff1c41bf9b29/paia-cloud-dev-20261024/evidence-context-transport-review/mutant-transport.mjs';

// Pure synthetic original-owner tests: no child process, listener, browser,
// network, real profile, installed bridge or provider configuration is used.
const configuration={version:2,target:'chatgpt',transport:'native-loopback-http-bearer',principalMode:'paired-local-profile',qualificationId:'synthetic-quiescence',authorizationPolicy:{version:1,id:'synthetic-lifetime',authorizationLifetimeMs:86400000,runtimeLeaseMs:3600000}};
const op=()=>crypto.randomUUID();
const event=()=>{const listeners=new Set();return {addListener:fn=>listeners.add(fn),removeListener:fn=>listeners.delete(fn),emit:(...args)=>{for(const fn of [...listeners])fn(...args);}};};
const deferred=()=>{let resolve;const promise=new Promise(r=>resolve=r);return {promise,resolve};};
async function until(check){for(let i=0;i<100;i++){if(await check())return;await new Promise(r=>setImmediate(r));}assert.fail('synthetic owner did not reach its awaited boundary');}
async function fixture(t,{sourceConfiguration=configuration}={}){
 const {s,storage}=await setup(OrganizerStore);await s.finishFoundation();await s.setFilterMode('off');const cards=new ContextCardsService(s);
 for(const key of ['global','info'])await cards.change({kind:'access',operationId:op(),epoch:'initial',key,enabled:true,expectedRevision:0});
 const state={permitted:true,ports:[],writes:0,permissionHook:null,getHook:null,setHook:null,autoHello:true,autoReady:true,autoAck:true,postHook:null},changed=event();
 const api={permissions:{onRemoved:event(),contains:async()=>{await state.permissionHook?.();return state.permitted;}},storage:{local:{get:async key=>{await state.getHook?.(key);return storage.get(key);},set:async rows=>{state.writes++;await state.setHook?.(rows);await storage.set(rows);changed.emit(Object.fromEntries(Object.entries(rows).map(([k,v])=>[k,{newValue:v}])),'local');}},onChanged:changed},runtime:{id:'a'.repeat(32),onStartup:event(),onSuspend:event(),onSuspendCanceled:event(),sendMessage:async()=>{},connectNative:name=>{
  assert.equal(name,'com.paia.context_read');const port={onMessage:event(),onDisconnect:event(),nonce:op(),sent:[],disconnected:false,postMessage(message){this.sent.push(structuredClone(message));state.postHook?.(message,this);if(message.type==='configure'&&state.autoReady)queueMicrotask(()=>this.ready());if(message.type==='revoke'&&state.autoAck)queueMicrotask(()=>this.ack());},disconnect(){this.disconnected=true;},hello(){this.onMessage.emit({version:1,type:'hello',hostNonce:this.nonce,handover:'closed-listener-ack-v1'});},ready(){const c=this.sent.find(x=>x.type==='configure');assert.ok(c);this.onMessage.emit({version:1,type:'ready',hostNonce:this.nonce,generation:c.generation,port:c.port});},ack(changes={}){const r=this.sent.findLast(x=>x.type==='revoke');assert.ok(r);this.onMessage.emit({version:1,type:'revoked',hostNonce:this.nonce,generation:r.generation,handover:'closed-listener-ack-v1',...changes});}};
  state.ports.push(port);if(state.autoHello)queueMicrotask(()=>port.hello());return port;
 }}};
 const owner=new ContextConnections(s,api,{configuration:sourceConfiguration});t.after(()=>owner.dispose());
 const pair=async({ready=true}={})=>{const value=await owner.pair({expectedRevision:(await owner.status()).revision,port:49000+state.ports.length,authorizationPolicyId:sourceConfiguration?.authorizationPolicy?.id??null});if(ready)await until(async()=>(await owner.status()).connections.find(c=>c.id===value.id)?.state==='connected');return value;};
 return {s,storage,state,api,owner,pair,cards,row:async()=>(await storage.get(CONTEXT_CONNECTION_KEY))[CONTEXT_CONNECTION_KEY],witness:()=>s.repository.transaction(false,t=>t.get('meta',CONTEXT_RESUME_WITNESS),['meta'])};
}


import {readFile} from 'node:fs/promises';
import {ArchiveRepository} from 'file:///workspace/scratch/ff1c41bf9b29/paia-cloud-dev-20261024/context-transport-witness-20261024/extension/core/idb-repository.js';
const oldSource=(await readFile('/workspace/scratch/ff1c41bf9b29/paia-cloud-dev-20261024/context-transport-witness-20261024/extension/tests/fixtures/context-transport/v1-owner.txt','utf8')).replace(/from '([^']+)'/g,(_m,path)=>`from '${new URL(path,'file:///workspace/scratch/ff1c41bf9b29/paia-cloud-dev-20261024/context-transport-witness-20261024/extension/background/context-connections.js').href}'`);
const {ContextConnections:LegacyConnections}=await import('data:text/javascript;base64,'+Buffer.from(oldSource).toString('base64'));

test('independent stale no-witness predecessor registry retains legacyUnknown across explicit replacement',async t=>{
 const f=await fixture(t);f.owner.dispose();const legacyConfiguration={version:1,target:'chatgpt',transport:'native-loopback-http-bearer',principalMode:'paired-local-profile',qualificationId:'synthetic-quiescence'};
 const legacy=new LegacyConnections(f.s,f.api,{configuration:legacyConfiguration});const first=await legacy.pair({expectedRevision:0,port:49111});await until(async()=>(await legacy.status()).connectedCount===1);legacy.dispose();assert.equal(await f.witness(),undefined);
 await f.s.repository.transaction(true,t=>t.put('meta',{id:'recovery-restore-epoch',value:op()}),['meta']);
 const next=new ContextConnections(f.s,f.api,{configuration});t.after(()=>next.dispose());await next.pair({expectedRevision:first.revision,port:49112,authorizationPolicyId:configuration.authorizationPolicy.id},{replaceStale:true});await until(async()=>(await next.status()).connectedCount===1);
 assert.equal((await f.witness()).transport.legacyUnknown,true);
});
test('independent ready source port cannot survive same-ID database handle replacement',async t=>{
 const f=await fixture(t);await f.pair();const repo=f.s.repository,db=repo.db;const peer=new ArchiveRepository(f.storage,{indexedDB:repo.factory,name:repo.name,ia:repo.ia,smartFilter:repo.smartFilter,thoughtLibrary:repo.thoughtLibrary});await peer.open();assert.notEqual(peer.db,db);repo.db=peer.db;
 try{assert.equal((await f.owner.status()).connectedCount,0);}finally{repo.db=db;await peer.close();}
});
