import assert from 'node:assert/strict';
import {mock} from 'node:test';
import {assistServiceFixture} from '/workspace/scratch/ff1c41bf9b29/paia-cloud-dev-20261024/assist-cancel-rejection-review/services/ai-gateway/tests/assist-client-fixture.mjs';
import {PromptAssistState} from '/workspace/scratch/ff1c41bf9b29/paia-cloud-dev-20261024/assist-cancel-rejection-review/extension/ui/prompt-assist-state.js';
const early=process.argv[2]==='early',events=[],unhandled=[],handled=[];
const deferred=()=>{let resolve;const promise=new Promise(r=>resolve=r);return {promise,resolve};};
const tick=()=>new Promise(r=>setImmediate(r));
const entered=deferred(),provider=deferred(),cancelStopped=deferred(),cancelReturn=deferred(),unhandledSeen=deferred();
let running;
process.on('unhandledRejection',(error,promise)=>{const row={event:'unhandled',sameRunning:promise===running,code:error?.code};unhandled.push(row);events.push(row);unhandledSeen.resolve();});
process.on('rejectionHandled',promise=>{const row={event:'handled',sameRunning:promise===running};handled.push(row);events.push(row);});
const timeout=setTimeout(()=>{console.error(JSON.stringify({early,events,error:'CONTROL_TIMEOUT'}));process.exitCode=1;cancelReturn.resolve();provider.resolve();},10000);
try{
 const f=await assistServiceFixture({mock},{holdProvider:async()=>{events.push('provider-entered');entered.resolve();await provider.promise;}}),view=new PromptAssistState({send:f.rpc});
 const stop=f.commands.session.stop.bind(f.commands.session);
 f.commands.session.stop=async(...args)=>{events.push('original-stop-entered');const result=await stop(...args);events.push('original-stop-completed');cancelStopped.resolve();await cancelReturn.promise;events.push('cancel-return-released');return result;};
 await view.refresh();running=f.run();const rejected=early?assert.rejects(running,{code:'STALE_BASE'}):null;
 await entered.promise;const cancelled=view.cancel();events.push('cancel-invoked');provider.resolve();events.push('provider-released');await cancelStopped.promise;
 // Real cancellation has happened, but the independent view.cancel promise is
 // deliberately held so the old test cannot yet attach its rejection assertion.
 if(early){for(let i=0;i<8;i++)await tick();await rejected;assert.equal(unhandled.length,0);events.push('owned-rejection-asserted');}
 else{await unhandledSeen.promise;assert.deepEqual(unhandled,[{event:'unhandled',sameRunning:true,code:'STALE_BASE'}]);}
 cancelReturn.resolve();await cancelled;events.push('cancel-awaited');if(!early)await assert.rejects(running,{code:'STALE_BASE'});
 for(let i=0;i<3;i++)await tick();
 assert.equal(f.physical(),1);assert.equal(f.commands.views.size,0);assert.equal(f.insertions.length,0);
 const after=await f.s.repository.transaction(false,async t=>Object.fromEntries(await Promise.all([...t.tx.objectStoreNames].map(async n=>[n,await t.all(n)]))));
 assert.equal(after.organizerUsage[0].attemptCount,1);assert.equal(after.organizerWorkItems.length,0);assert.ok(['OUTCOME_UNKNOWN','EXPIRED_UNCOMMITTED'].includes(after.organizerJobs[0].state));
 if(!early)assert.deepEqual(handled,[{event:'handled',sameRunning:true}]);
 console.log(JSON.stringify({mode:early?'immediate-assertion':'late-assertion',events,physical:f.physical(),views:f.commands.views.size,insertions:f.insertions.length,attemptCount:after.organizerUsage[0].attemptCount,workItems:after.organizerWorkItems.length,jobState:after.organizerJobs[0].state,allOriginalPostconditions:true}));
 f.commands.dispose();await f.s.repository.close();mock.reset();
}finally{clearTimeout(timeout);}
