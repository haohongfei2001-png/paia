import assert from 'node:assert/strict';
import {setup} from '/workspace/scratch/ff1c41bf9b29/paia-cloud-dev-20261024/repo/extension/tests/harness/thought-m1.mjs';
import {OrganizerStore} from '/workspace/scratch/ff1c41bf9b29/paia-cloud-dev-20261024/repo/extension/core/organizer/store.js';
import {ContextCardsService,readContextCards,projectOriginalContextChange} from '/workspace/scratch/ff1c41bf9b29/paia-cloud-dev-20261024/repo/extension/core/context-cards.js';
import {prepareContextMutationDescription} from '/workspace/scratch/ff1c41bf9b29/paia-cloud-dev-20261024/repo/extension/core/browser-native-sync/context-mutation-codec.js';
const base=Date.parse('2026-10-24T00:00:00.000Z');
for(const mode of ['distinct','pinned']){
 let calls=0;const clock=()=>new Date(base+(mode==='distinct'?calls++:0)).toISOString();
 const {s}=await setup(OrganizerStore,{clock});await s.finishFoundation();const c=new ContextCardsService(s);
 assert.equal(c.syncJournal,null);
 const read=()=>s.repository.transaction(false,t=>readContextCards(t));
 const command={kind:'put',operationId:crypto.randomUUID(),epoch:'initial',itemId:crypto.randomUUID(),expectedRevision:0,body:'SYNTHETIC clock control',section:'SYNTHETIC',card:'info'};
 const before=await read(),result=await c.change(command);assert.equal(result.ok,true);const after=await read(),item=after.items[0],at=item.updatedAt;
 const projected=projectOriginalContextChange(before,command,at);
 if(mode==='distinct'){
  assert.equal(Date.parse(item.updatedAt)-Date.parse(item.createdAt),1);
  const normalized=structuredClone(after);normalized.items[0].createdAt=at;
  assert.deepEqual(projected.row,normalized);
  assert.notDeepEqual(projected.row,after);
  await assert.rejects(prepareContextMutationDescription(before,after,command,at),{code:'BNS_CONTEXT_MUTATION_INVALID'});
 }else{
  assert.equal(item.createdAt,item.updatedAt);assert.deepEqual(projected.row,after);
  const prepared=await prepareContextMutationDescription(before,after,command,at);assert.deepEqual(prepared.items,after.items);
 }
 assert.deepEqual(await read(),after);
 console.log(JSON.stringify({mode,createdAt:item.createdAt,updatedAt:item.updatedAt,replayCreatedAt:projected.row.items[0].createdAt,description:mode==='distinct'?'BNS_CONTEXT_MUTATION_INVALID':'accepted',originalWrite:result.ok,originalRowUnchanged:true}));
}
