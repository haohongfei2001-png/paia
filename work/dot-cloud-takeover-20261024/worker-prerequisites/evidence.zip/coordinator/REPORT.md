# Original worker source coordination prerequisite

Date: 2026-10-24. Base: `1632908ab836738ea8c1f57308ae7c2610f670ef`.

## Implemented boundary

The original coordinator composes the genuine Safety, Library, Filter,
Maintenance, ContextConnections, Assist, Next, manual Prompt and Prompt surface
owners through their original private hold/current/fence/release methods. The
new API is deliberately named `holdApplicationSources`, `applicationSourcesHeld`,
`fenceApplicationSources` and `releaseApplicationSources`. The prior local-only
maintenance API remains separate, and its receipts cannot qualify the source API.

All admission holds start synchronously before awaiting any drain. Synchronous
refusal is observed without losing earlier pending acquisitions. Any failure
invalidates the composed attempt and releases acquired receipts; the final
rejection waits for every late original acquisition to be released. Cleanup
attempts every receipt in reverse acquisition order. A cleanup exception closes
the coordinator permanently instead of allowing reuse. Final-fence failure also
releases the original receipts, and foreign tokens never release another hold.

The composer binds the original Store, repository, database, database ID, class
instances and Prompt service/surface relationships. Small deny-only private-brand
identity assertions in Context, Assist and Next validate their original
construction sources. Assist binds the session actually constructed from its
original Store and consumes the original LocalAssistSession prototype quartet,
not replaceable callbacks. A missing configured Assist session, a forged or
foreign owner/session, and copied or stale receipt remain unqualified.

Configured Maintenance explicitly refuses the existing source hold. Original
Context cold/nonempty host uncertainty and durable provider/insertion UNKNOWN
remain restrictive. No map emptiness is promoted into missing source evidence.
No core, schema, SQL, journal, editor guard, content script or configuration
contract was changed by this slice.

## Scope is not application selection

This is prerequisite source coordination, not a completed production hold
consumer or application-selection milestone. PREPARE remains strictly read-only.
Its original flow does not acquire these invalidating holds. Acquiring holds
before an unconditional protection refusal would discard current Prompt state
and close Context transports without a successful selection path, so it is not
introduced. ACTIVATE, CONTINUE and RESTART are not enabled. Editor safety,
cold insertion/host freeze, configured remote Maintenance and whole-selection
qualification remain separate obligations.

The actual worker must construct the fixed owners only after its original Store
is initialized. A null database captured at construction intentionally cannot be
refreshed into proof later. Review identified this integration-order requirement;
its worker-owned correction and actual-worker positive regression are separate
from the initialized-Store tests in this receipt.

## Exact bounded verification

Five complete Node files passed **160/160**, zero failures, skips, cancellations
or TODOs, in 5971.716055 ms:

- `extension/tests/application-worker-coordination.test.mjs`
- `extension/tests/application-worker-sources.test.mjs`
- `extension/tests/context-connections-quiescence.test.mjs`
- `extension/tests/assist-source-quiescence.test.mjs`
- `extension/tests/prompt-next-source-quiescence.test.mjs`

Command: `node --test --test-reporter=tap` followed by exactly those five paths.
The full output is `final-source-owners.tap` beside this report, SHA-256
`49fb1dbb675845f694fab601aa807fbfbeac66c62f5aaa8f102ae007e5e0e3fb`.

The 26 new composition cases cover genuine source composition; local/full token
separation; absent Assist; five copied private-brand owners; foreign Context;
forged/genuine replacement Assist sessions; Next birth-service replacement;
instance/prototype callback forgery over durable UNKNOWN; late session fence
replacement; competing composers; synchronous admission; synchronous partial
factory refusal; close during drain; owner relinking; final epoch changes;
database replacement; cleanup exception; captured callbacks; cold Context;
and configured Maintenance refusal. Existing source suites retain their own
original provider/insertion/native-ACK uncertainty and late-settlement cases.

Earlier invocations are not added to this total: an initial local-only 8/9
exposed premature Promise.all rejection before late token release, and the
settlement-barrier correction passed 9/9. The first Assist-file invocation was
blocked by a missing `pg` import; existing pinned `pg` 8.23.1 dependencies were
then reused without installation. The preliminary 59/59 and later 35/35
composition invocations overlap the final aggregate and are not independent
extra coverage. The earlier 160/160 at 6293.694481 ms used the prior Prompt
surface bytes; the final aggregate reran after the exact manual-owner successor.

All data is synthetic. Existing signed service fixtures use intercepted HTTPS
and deterministic SQL protocol models, not a real provider or PostgreSQL run.
Browser/native application runs, Full certification, C-phase/129/100k scale,
real accounts, installation and deployment were **NOT RUN**. No acceptance gate,
threshold, workflow, timeout, dependency version or product version was changed.
Root integration owns the coherent product version and publication.

## Tested source identities

SHA-256 of this slice's runtime files:

- application-worker-coordination.js: `330855d81eb32d5cd4a1ddde8dc895cb0a242ce178f9574f789ff392589ac5df`
- context-connections.js: `25f1054c268ea605d03bc771c66962ac5d8b10f98307865ea8caade81f1eca28`
- prompt-assist.js: `c2e56d0936b5e15bbda6174136e115089521bc21d274b997c846aea5c0e4c219`
- prompt-next.js: `16de59ec641020b9dcdce0573f45ea1dde3f83cb820b0ff03f69c4234959b6d4`

The full-source test consumed the separately owned manual Prompt implementation
at exact commit `4735c6bc8e1b2d7f4dcdf322fea5c251dc147602`, not the old base
versions. Those files
are not included in this slice's commit:

- prompt-reuse-commands.js: `85598fac23596f4c1f400e7afad386f5473fe3759815fadf4d659cc355d77d51`
- prompt-surface.js: `817e1a0ed108e0467b20415ac1759dd85eb343e6c72d0765e482d7a883672894`

A changed manual-owner successor or later Context witness work needs the final
combined owning tests again. This receipt does not relabel later bytes tested.
