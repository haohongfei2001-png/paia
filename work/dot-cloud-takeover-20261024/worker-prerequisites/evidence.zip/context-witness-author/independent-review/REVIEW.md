# Context transport witness independent review

Result: CLEAN for the bounded synthetic/source slice. No production edits were made by the reviewer.

## Exact candidate

- Worktree: `context-transport-witness-20261024`.
- Base: `1632908ab836738ea8c1f57308ae7c2610f670ef`, plus the separately coordinated same-Store identity seam in the original Context owner.
- Runtime `extension/background/context-connections.js` SHA256: `93d1a8b633d5e773621679e8deb96d9b907968dd86576f1b8f10e55bef2db961`.
- New owning test SHA256: `67724b845b3104be56679be0cec3c5cbedfcc655fef8dcae0b15c9c2eca63034`.
- Quiescence test SHA256: `39c573e02635c47ac21727ad436561a3c90058e92a48e2570bc68b8d4ad22603`.
- Frozen actual v1 owner SHA256: `3f22c411fa59d21ebb0100c67d613abe469ea6517b4bd043d07d34ac6077a443`; verified byte-identical to the original base source.

## Review findings resolved before freeze

1. Stale no-witness legacy registry replacement initially lost prior history because invalidation cleared the row used to derive legacyUnknown. The final owner retains observed history. Independently tested with the actual frozen v1 owner producing a legacy no-witness registry, then a restore epoch change and explicit replacement.
2. A ready port initially could survive replacement of its original database handle by a different handle with identical durable IDs. The final live check binds the captured repository/database. Independently tested with a real second fake-IndexedDB handle, not an invalid proxy.
3. Previously observed legacy uncertainty could be lost after the registry disappeared. A genuine candidate RED is retained in `sticky-edge.log` (2 pass, 1 fail); the final fallback preserves sticky unobserved-host history. The same independent test now passes.

The two first findings also have isolated mutation controls: reversing only those safeguards produces 0/2 passes in `independent-mutant.log`. This is mutation evidence, not a claim that the final candidate failed.

## Invariants reviewed

The single existing nonportable meta key holds strict v2 publication and bounded body-free transport facts. Every configure follows an exact durable unresolved-claim CAS and a final same-owner epoch/witness/row check. Closure requires the exact original private port's ACK and exact retained claim CAS. Timeout/disconnect alone never establish closure; a later exact original ACK may settle only its still-retained original claim, never resurrect the failed hold or a replaced claim.

Capacity is eight retained claims. The only compaction is one explicit CAS atomically replacing a durably CLOSED slot with a fresh unique unresolved claim. All unrelated unresolved claims and legacyUnknown remain unchanged. Full unresolved capacity refuses rather than evicts; twelve explicit closed-slot reconnects prove the slot limit is not a permanent eight-cycle limit. Ordinary automatic renewal and suspend/resume are separately covered by the retained quiescence tests; the twelve-cycle control is not twelve automatic renewals.

Unknown write outcomes are confirmed only by exact full-witness durable reread, with no blind write retry. v1 remains legacy-unknown; the actual v1 reader rejects v2 intact. Restore invalidates old bindings and preserves unresolved records. Backup and Sync exclude this metadata. Positive cold hold remains disabled. The final original prepared-selection all-rows comparison rejects a closure-only witness claim-status write; no marker exemption or PREPARE/refusal removal was introduced.

## Independent verification

- Pre-final-test-strengthening owning subset: 86/86 pass; zero failure/cancellation/skip. Log `final-owning-rerun.log`, SHA256 `e5548fce642c86a54b58dd2c2504e00672c3ff3ee958413cd89c0583102baf0d`.
- Final seven-file owning group: 135/135 pass; zero failure/cancellation/skip. Log `final-seven-file-cut-rerun.log`, SHA256 `0836cef1a083be84a14df320b7323d9985139b3ca6a8c6835fd7d763186647d0`. This rerun includes the strengthened closure-only original-cut assertion on the exact final test bytes.
- Three independently authored original-owner controls: 3/3 pass. Log `final-independent.log`, SHA256 `5736de1640b2ef5c541b606073ad9a3e5c0dcfe3148abc03cec3044da79186f1`.
- The 86-case subset overlaps the 135-case group; these are not additive unique coverage.
- `git diff --check` passes. Runtime and owning-test hashes remained unchanged across independent runs.
- Original author preimplementation RED: 0/4 pass, verified log SHA256 `2665cc1c37e7193a92c8ce6fb680415795af879e1e073cc93934a80b90cead65`; one case directly observes the unsafe configure send rather than only a missing shape.
- Author final group log SHA256 `9e25ce722e87ee3037c3b7ae6e1401c8eab7dd7be8947d49b5dd0dcc716cb1b8` independently verified. Earlier owning logs remain preserved under their original names and hashes.

Command from the candidate root:

    node --test extension/tests/context-transport-witness.test.mjs extension/tests/context-connections-quiescence.test.mjs extension/tests/context-read-publication.test.mjs extension/tests/context-connection-policy.test.mjs extension/tests/privacy-context-bridge.test.mjs extension/tests/context-receipt-portability.test.mjs extension/tests/context-connections-ui.test.mjs

## Limits

This establishes synthetic original-owner behavior only. No native host, browser, real account, paid request, installation, deployment, Full/C-phase, 129/100k scale or live-provider qualification was run or claimed. The prohibited native-spawning `context-connections.test.mjs` was not run. Root owns integration/publication and final composed identity; a new runtime composition needs applicable rerun evidence.
