

## 2026-10-25 independent Settings UI checkpoint (local candidate)

The preceding published development checkpoint is `510d2c7f5a94367db2411f38ad1017860d9b81d8`, tree `74b1c25ab8c38134c4476e3668c4039ba4bc0736` (Settings Sync stop UI and its exact scoped evidence). Historical readiness entries above remain historical.

Independent local source `dbc989fa2a81d99df806585b49704f0063de573c`, tree `a57c2d0c01d5592bc07f3e54149c57f7156db680`, combines reviewed Settings feedback focus/selection and pending-observer lifetime repair with reviewed original detail-close lifetime repair. Only `settings-feedback.js` and `settings-details.js` change at runtime. One unfiltered 12-complete-file ordinary Settings consumer run passed 216/216, zero failures/skips/cancellations, 29.204 seconds within the unchanged 240-second ceiling. Source-bound component and post-run independent review passed. Full current source/test/failure-history evidence is in `settings-ui-lifetimes-20261025/REPORT.md` and `evidence.zip`; all prior published report/ZIP blobs remain unchanged and are hash-referenced, not nested again.

This is a local candidate until root separately publishes the verified tree. It does not import or clear held Context/sync/security candidates (including the separately held b30 work), Source continuation7ceb, or their later findings. Historical whole-file/Release counts stay attached to their original commits. No native/browser/OS clipboard/Full/build/paid operation or test/provider network ran. Authorized read-only GitHub retrieval supplied three exact published HTML fixture blobs, without a remote mutation; no whole Settings/product or native focus/IME qualification is claimed. Root's pre-existing staged metadata and all prior failed evidence remain intact.
