import {test,assert,fixture,put,deferred,tick} from './fixture.mjs';

for(const kind of ['delete','restore'])for(const intent of ['normal','focus','typed','composition','selection'])test(`review synthetic ${kind} completion ${intent}`,()=>fixture(async({c,makePage,transport,dispatch,calls})=>{
 const second=put('info');await c.change(second);const page=makePage();await page.open('info');await tick();
 const target=[...page.editors.values()][0],sibling=page.editors.get(second.itemId);
 if(kind==='restore')await page.remove(target);
 const trigger=kind==='delete'?target.menu.querySelector('button'):page.message.querySelector('button');trigger.focus();
 const gate=deferred(),entered=deferred();transport.dispatch=async message=>{const result=await dispatch(message);if(message.change?.kind===kind){entered.resolve();await gate.promise;}return result;};
 const pending=kind==='delete'?page.remove(target):page.undoDelete();await entered.promise;
 const priorSelection=Object.getOwnPropertyDescriptor(globalThis,'getSelection');let selection=null;
 try{
  if(intent!=='normal'){
   sibling.field.focus();document.dispatchEvent({type:'focusin',target:sibling.field});
   if(intent==='typed'){sibling.field.textContent='SYNTHETIC reviewer newer typing';sibling.field.listeners.get('input')({isComposing:false});sibling.autosave.cancel();}
   if(intent==='composition'){sibling.field.listeners.get('compositionstart')({});sibling.field.textContent='SYNTHETIC reviewer 新输入';sibling.field.listeners.get('input')({isComposing:true});}
   if(intent==='selection'){const node=sibling.field.firstChild;selection={rangeCount:1,isCollapsed:false,anchorNode:node,anchorOffset:10,focusNode:node,focusOffset:3,setBaseAndExtent(...args){[this.anchorNode,this.anchorOffset,this.focusNode,this.focusOffset]=args;}};globalThis.getSelection=()=>selection;document.dispatchEvent({type:'selectionchange'});}
  }
  const beforeText=sibling.field.textContent;gate.resolve();await pending;
  assert.equal((await c.snapshot()).items.some(item=>item.id===target.id),kind==='restore','durable mutation must remain acknowledged');
  assert.equal(page.journal.undo.length,kind==='delete'?1:0,'Undo record must reflect committed mutation');
  assert.equal(sibling.field.textContent,beforeText);assert.equal(page.editors.get(sibling.id),sibling);
  if(intent==='normal')assert.equal(document.activeElement,kind==='delete'?page.add:page.editors.get(target.id).field,'ordinary completion focus still works');
  else assert.equal(document.activeElement,sibling.field,'newer sibling intent must keep focus');
  if(intent==='composition')assert.equal(sibling.composing,true);
  if(selection){assert.equal(selection.anchorOffset,10);assert.equal(selection.focusOffset,3);}
  assert.equal(calls.filter(call=>call.change?.kind===kind).length,1);assert.equal(page.busy,false);
 }finally{gate.resolve();sibling.autosave.cancel();if(priorSelection)Object.defineProperty(globalThis,'getSelection',priorSelection);else delete globalThis.getSelection;}
}));
