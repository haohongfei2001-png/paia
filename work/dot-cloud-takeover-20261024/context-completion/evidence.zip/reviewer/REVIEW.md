# Independent read-only review: Context mutation completion

## Scope and identities

- Base reviewed: e2a2198e50d303974a1e53b1f550d9be1ca82df7.
- Original runtime SHA-256: 5563eab2ccc20ab329525cb45a2703ec302d851cf5c7e651e51f5c2942309a2b.
- First author candidate: 5044c301fecace7121908eb3f3ca9986fa6b2a30, tree 0e1af4d8ba874496aae1bc53c34b5d41d5027eac.
- First candidate runtime SHA-256: 98554e3b57b01e7fa4dcb7ef6331ce5e5545cd8a145820efd751b1059eaf2df8.
- Review is read-only for production and author tests. Reviewer-owned scripts and logs live only in this directory.
- Final reviewed successor: 7b0585f7b626979e16089465c33c2f2f7273d27f, tree 32f584beab51ec1a6444bb2e036af1c246bec727. No remaining blocking finding in this bounded scope. The first candidate remains explicitly failed at its selection-only Undo boundary.

## Findings and preserved failures

1. Baseline actual-controller focus reproduction: 10 controls, 2 normal completions pass and 8 newer sibling focus/typing/selection/IME controls fail across delete and restore. Durable mutation and Undo journal assertions precede and pass before each focus failure. See baseline-focus.log.
2. Baseline target and edit-Undo reproduction: six controls fail. Four exercise target typing or composition before/after the durable delete; two exercise later typing or composition while editor Undo awaits save. See baseline-retention.log.
3. Baseline forced lifecycle controls: six fail for close/reopen/replacement across delete/restore. These are lifecycle hardening controls, not claims of normal menu navigation bypass: normal leave blocks busy/pending mutations. See baseline-lifecycle.log.
4. Baseline recovery-token and epoch controls: four fail. Exact null/non-null admission token protection and newer-epoch UI/journal ownership are checked. The epoch control changes synthetic metadata through the real store and reads a real snapshot; it is not a full reset/restore-workflow test. See baseline-epoch-token.log.
5. First candidate initially passes 25/26 reviewer controls. The sole failure was a reviewer overconstraint: same-page restore may legitimately publish its successful completion notice after a restored Item has independently been mounted. The corrected assertion still requires preserved replacement identity/text/focus, and still rejects stale notices after close/reopen/old delete ownership. The original test source and failure are preserved; no production change was requested to satisfy this correction.
6. Expanded first-candidate matrix passes 30/30, including pure keyboard-selection intent, away/back focus, and completed composition. Six complete related owning files pass 198/198, with zero skipped/cancelled/todo. These suites overlap author evidence and must not be summed into a combined coverage total.
7. Additional first-candidate finding: a genuine change in same-field Selection during held save, accompanied only by document selectionchange, is not recognized by the gesture-only focus lease. The earlier editor Undo overwrites the pending body with historical text. candidate-selectionchange.log preserves 0/1; candidate-selectionchange-expanded.log preserves 1/2 with an unchanged-selectionchange normal-Undo control. This is a synthetic actual-controller counterexample, not native browser evidence. Author accepted a minimal selection snapshot fence before historical text assignment.

## Recovery and mutation truth

Reviewer target-retention tests call the actual ContextCardsService.recoverySources before recovery writes. A typed draft after a durable tombstone is rejected by the production admission owner. It may be retained only in the live DOM; no post-tombstone persistent/cold recovery guarantee is claimed.

A pretransaction newer draft may be admitted while the Item is still active. Exact captured-token cleanup must not erase that newer raw token. The tests do not treat the remaining raw token as recovery authority after removal. No core/worker recovery admission or tombstone rule may be relaxed.

The current repair keeps the original deletion committed, retains newer target text/composition in the same conflicted editor, cancels its obsolete autosave, and uses existing explicit Keep as new / View saved controls. Independent controls confirm explicit Keep as new creates one different Item and no restore command. Ordinary delete/restore still receive normal completion focus when no newer intent exists. Old lifecycle or epoch completions do not mutate current editor mapping, journal, notice, or focus.

## Commands and limitations

Independent matrix uses reviewer-focus, reviewer-retention, reviewer-lifecycle, reviewer-epoch-token and reviewer-same-owner test files with CONTEXT_REVIEW_CHECKOUT selecting the author checkout. reviewer-selectionchange adds the late exact-selection boundary.

Complete related command:

node --test extension/tests/context-cards-local-ui.test.mjs extension/tests/context-edit-lifecycle.test.mjs extension/tests/context-draft-discard.test.mjs extension/tests/context-navigation-lifecycle.test.mjs extension/tests/context-navigation-history-owner.test.mjs extension/tests/cpv1-01-recovery-draft.test.mjs

All execution is small Node synthetic controller/service/IndexedDB evidence. There was no browser/native/physical IME, Full, original-C, 129-group, 100k, old-cloud, real-account/provider/network/paid, install/deploy, remote, or local-Codex execution. No claim of whole-product, exact-main, installed or production acceptance is made.

## Final exact-source verification

The selection successor captures rangeCount, anchor/focus nodes and offsets, and isCollapsed before awaited Undo preflight. It compares those actual values before assigning historical text. A changed selection cancels the stale Undo; an unchanged delayed selectionchange does not cancel ordinary Undo. No general listener was added that could confuse deletion's own node detachment with later human intent.

- Final independent adversarial matrix: final-matrix.log, 32/32 PASS, zero failures/cancelled/skipped/todo.
- Final complete six-file related suite: final-related.log, 200/200 PASS, zero failures/cancelled/skipped/todo.
- node --check extension/ui/context-cards.js: PASS.
- Scoped git diff --check from base through the final source/test commit: PASS. Raw failed Node logs remain unnormalized evidence.
- Production source and author tests were never edited by this reviewer. Final execution confirmed the exact commit and tree above.

Final runtime SHA-256: fd24a15eb5703c65fba0d07d5f5a3b0bee85c0f1f91e702e6bd17acfcbdf2d3e.
Final local-ui test SHA-256: 3956cd8c6928f43db9e92a211b0cc9e820134f3e6dfcdfd4b428325b3842eb0c.
Final edit-lifecycle test SHA-256: ba0c394be49dba7ed4151e98e47b257b16d43b4301b714f925500553924b76a6.

The reviewer-selected 32 tests, six-file 200 suite and author-selected 13-file 333 suite overlap. Their counts are separate evidence, not an additive total.
