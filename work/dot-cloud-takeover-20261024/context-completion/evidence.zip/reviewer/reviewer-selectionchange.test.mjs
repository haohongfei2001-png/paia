import {test,assert,fixture,deferred,tick} from './fixture.mjs';

test('review synthetic editor undo preserves same-field selectionchange without keyboard or pointer event',()=>fixture(async({c,makePage,transport,dispatch,calls})=>{
 const page=makePage();await page.open('info');await tick();const editor=[...page.editors.values()][0];
 editor.field.textContent='SYNTHETIC same owner pending body B';editor.changed();editor.autosave.cancel();if(editor.recovery.running)await editor.recovery.running;editor.field.focus();
 const before=Object.getOwnPropertyDescriptor(globalThis,'getSelection'),node=editor.field.firstChild;
 const selection={rangeCount:1,isCollapsed:true,anchorNode:node,anchorOffset:0,focusNode:node,focusOffset:0};globalThis.getSelection=()=>selection;
 const gate=deferred(),entered=deferred();let held=false;transport.dispatch=async message=>{const result=await dispatch(message);if(message.change?.kind==='put'&&!held){held=true;entered.resolve();await gate.promise;}return result;};
 try{const pending=editor.undo();await entered.promise;selection.isCollapsed=false;selection.anchorOffset=4;selection.focusOffset=12;document.dispatchEvent({type:'selectionchange',target:document});gate.resolve();await pending;
  assert.equal(editor.field.textContent,'SYNTHETIC same owner pending body B','same-owner selectionchange is newer editing intent even without a document pointer/key event');assert.equal(calls.filter(x=>x.change?.kind==='put').length,1);
 }finally{gate.resolve();editor.autosave.cancel();if(before)Object.defineProperty(globalThis,'getSelection',before);else delete globalThis.getSelection;}
}));

test('review synthetic editor undo ignores delayed unchanged selectionchange from original gesture',()=>fixture(async({c,makePage,transport,dispatch,calls})=>{
 const page=makePage();await page.open('info');await tick();const editor=[...page.editors.values()][0],original=editor.saved.body;
 editor.field.textContent='SYNTHETIC same owner pending body B';editor.changed();editor.autosave.cancel();if(editor.recovery.running)await editor.recovery.running;editor.field.focus();
 const before=Object.getOwnPropertyDescriptor(globalThis,'getSelection'),node=editor.field.firstChild;
 const selection={rangeCount:1,isCollapsed:true,anchorNode:node,anchorOffset:0,focusNode:node,focusOffset:0};globalThis.getSelection=()=>selection;
 const gate=deferred(),entered=deferred();let held=false;transport.dispatch=async message=>{const result=await dispatch(message);if(message.change?.kind==='put'&&!held){held=true;entered.resolve();await gate.promise;}return result;};
 try{const pending=editor.undo();await entered.promise;document.dispatchEvent({type:'selectionchange',target:document});gate.resolve();await pending;
  assert.equal(editor.field.textContent,original,'unchanged delayed selectionchange is not newer human intent');assert.equal(calls.filter(x=>x.change?.kind==='put').length,2);assert.equal(editor.journal.undo.length,0);
 }finally{gate.resolve();editor.autosave.cancel();if(before)Object.defineProperty(globalThis,'getSelection',before);else delete globalThis.getSelection;}
}));
