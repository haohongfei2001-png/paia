import {test,assert,fixture,put,deferred,tick} from './fixture.mjs';

for(const kind of ['delete','restore'])for(const invalidation of ['close','reopen','replace'])test(`review synthetic ${kind} completion after forced ${invalidation}`,()=>fixture(async({c,makePage,transport,dispatch})=>{
 const second=put('info');await c.change(second);const page=makePage();await page.open('info');await tick();const target=[...page.editors.values()][0];if(kind==='restore')await page.remove(target);
 const gate=deferred(),entered=deferred();transport.dispatch=async message=>{const result=await dispatch(message);if(message.change?.kind===kind){entered.resolve();await gate.promise;}return result;};
 const pending=kind==='delete'?page.remove(target):page.undoDelete();await entered.promise;
 try{
  if(invalidation==='close')page.close();
  if(invalidation==='reopen'){page.close();await page.open('info');await page.refresh({force:true,rebuild:true});}
  if(invalidation==='replace'){
   const old=page.editors.get(target.id);if(old){old.dispose();old.root.remove();page.editors.delete(old.id);}
   const replacement=page.mountItem({...target.saved});replacement.local='SYNTHETIC replacement owner draft';replacement.field.textContent=replacement.local;replacement.field.focus();
  }
  const expectedEditor=page.editors.get(target.id);const current=page.editors.get(second.itemId);
  if(current)current.field.focus();else document.body.focus();
  page.notice('SYNTHETIC newer page status');const focus=document.activeElement,notice=page.message?.textContent;
  gate.resolve();await pending;
  assert.equal(document.activeElement===focus,true,'stale completion cannot move focus');
  if(kind==='delete'||invalidation!=='replace')assert.equal(page.message?.textContent,notice,'stale completion cannot replace current notice');
  // A same-page restore may legitimately acknowledge success after the restored
  // Item was mounted by a refresh. The replacement draft itself must survive.
  if(invalidation==='replace'){assert.equal(page.editors.get(target.id)===expectedEditor,true,'old target cannot remove replacement mapping');assert.equal(expectedEditor.field.textContent,'SYNTHETIC replacement owner draft');}
  assert.equal((await c.snapshot()).items.some(x=>x.id===target.id),kind==='restore','stale UI ownership does not roll back durable mutation');
 }finally{gate.resolve();}
}));
