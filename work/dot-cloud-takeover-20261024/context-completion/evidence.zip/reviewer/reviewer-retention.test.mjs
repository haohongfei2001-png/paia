import {test,assert,fixture,deferred,tick} from './fixture.mjs';

for(const phase of ['before-commit','after-commit'])for(const edit of ['typed','composition'])test(`review synthetic target ${edit} during delete ${phase}`,()=>fixture(async({c,recovery,makePage,transport,dispatch,calls})=>{
 const page=makePage();await page.open('info');await tick();const target=[...page.editors.values()][0],root=target.root,field=target.field;
 const gate=deferred(),entered=deferred();let deleted=false;
 transport.dispatch=async message=>{
  if(message.type==='PAIA_RECOVERY_DRAFT_SAVE')await c.recoverySources(message.draft);
  if(message.change?.kind==='delete'){
   if(phase==='before-commit'){entered.resolve();await gate.promise;}
   const result=await dispatch(message);deleted=true;
   if(phase==='after-commit'){entered.resolve();await gate.promise;}return result;
  }
  return dispatch(message);
 };
 target.menu.querySelectorAll('button').find(x=>x.textContent==='Delete').focus();const pending=page.remove(target);await entered.promise;
 try{
  assert.equal(deleted,phase==='after-commit');target.field.focus();document.dispatchEvent({type:'focusin',target:field});
  if(edit==='composition')field.listeners.get('compositionstart')({});
  const text='SYNTHETIC reviewer newer deletion draft 新文字';field.textContent=text;field.listeners.get('input')({isComposing:edit==='composition'});target.autosave.cancel();
  if(target.recovery.running)await target.recovery.running;
  const beforeRecovery=await recovery.load('context_item',target.id);
  if(phase==='before-commit'&&edit==='typed')assert.equal(beforeRecovery?.operation.change.body,text,'recovery B admitted while Item still active');
  if(phase==='after-commit'&&edit==='typed')assert.equal(beforeRecovery,null,'production service rejects postcommit recovery writes');
  gate.resolve();await pending;
  assert.equal((await c.snapshot()).items.some(item=>item.id===target.id),false,'original deletion remains committed');
  assert.equal(page.journal.undo.length,1);assert.equal(calls.filter(x=>x.change?.kind==='restore').length,0);
  assert.equal(page.editors.get(target.id)===target,true,'same live target editor must retain newer human text');
  assert.equal(target.root,root);assert.equal(target.field,field);assert.equal(root.isConnected,true);assert.equal(field.textContent,text);assert.equal(target.conflicted,true);assert.equal(document.activeElement===field,true);
  if(edit==='composition'){assert.equal(target.composing,true);assert.equal(await target.flush(),false);field.listeners.get('compositionend')({});target.autosave.cancel();if(target.recovery.running)await target.recovery.running;}
  assert.equal(await target.flush(),false,'conflicted draft never silently restores or saves removed Item');
  await page.refresh();assert.equal(page.editors.get(target.id),target);assert.equal(field.textContent,text);
  if(phase==='before-commit'&&edit==='typed')assert.equal((await recovery.load('context_item',target.id))?.token,beforeRecovery.token,'late clear cannot erase newer precommit token');
  const beforePut=calls.filter(x=>x.change?.kind==='put').length;await page.keepConflict(target);
  const snapshot=await c.snapshot(),replacement=snapshot.items.find(x=>x.body===text);assert.ok(replacement,'explicit Keep as new saves newer human draft');assert.notEqual(replacement.id,target.id);assert.equal(snapshot.items.some(x=>x.id===target.id),false);
  assert.equal(calls.filter(x=>x.change?.kind==='put').length,beforePut+1);assert.equal(calls.filter(x=>x.change?.kind==='restore').length,0);
 }finally{gate.resolve();target.autosave.cancel();}
}));

for(const intent of ['typed','composition'])test(`review synthetic editor undo held save with newer ${intent}`,()=>fixture(async({c,makePage,transport,dispatch,calls})=>{
 const page=makePage();await page.open('info');await tick();const editor=[...page.editors.values()][0];
 editor.journal.record({body:'SYNTHETIC historical undo body'});editor.field.textContent='SYNTHETIC body A to save';editor.field.listeners.get('input')({isComposing:false});editor.autosave.cancel();if(editor.recovery.running)await editor.recovery.running;
 const gate=deferred(),entered=deferred();let held=false;
 transport.dispatch=async message=>{const result=await dispatch(message);if(message.change?.kind==='put'&&!held){held=true;entered.resolve();await gate.promise;}return result;};
 const pending=editor.undo();await entered.promise;try{
  editor.field.focus();if(intent==='composition')editor.field.listeners.get('compositionstart')({});
  const newer='SYNTHETIC newer edit B 中文';editor.field.textContent=newer;editor.field.listeners.get('input')({isComposing:intent==='composition'});editor.autosave.cancel();
  gate.resolve();await pending;assert.equal(editor.field.textContent,newer,'earlier Undo cannot replace newer human edit');
  if(intent==='composition'){assert.equal(editor.composing,true);assert.equal(calls.filter(x=>x.change?.kind==='put').length,1);}
  assert.notEqual((await c.snapshot()).items.find(x=>x.id===editor.id).body,'SYNTHETIC historical undo body');
 }finally{gate.resolve();editor.autosave.cancel();}
}));
