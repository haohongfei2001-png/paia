import {test,assert,fixture,deferred,tick} from './fixture.mjs';

for(const mode of ['normal','keyboard-selection','focus-away-back','completed-composition'])test(`review synthetic editor undo same owner ${mode}`,()=>fixture(async({c,makePage,transport,dispatch,calls})=>{
 const page=makePage();await page.open('info');await tick();const editor=[...page.editors.values()][0];const original=editor.saved.body;
 editor.field.textContent='SYNTHETIC same-owner B';editor.changed();editor.autosave.cancel();if(editor.recovery.running)await editor.recovery.running;
 editor.menu.querySelector('summary').focus();const gate=deferred(),entered=deferred();let held=false;
 transport.dispatch=async message=>{const result=await dispatch(message);if(message.change?.kind==='put'&&!held){held=true;entered.resolve();await gate.promise;}return result;};
 const pending=editor.undo();await entered.promise;try{
  if(mode==='keyboard-selection'){editor.field.focus();document.dispatchEvent({type:'keydown',target:editor.field,key:'ArrowLeft',shiftKey:true});}
  if(mode==='focus-away-back'){page.add.focus();document.dispatchEvent({type:'focusin',target:page.add});editor.menu.querySelector('summary').focus();document.dispatchEvent({type:'focusin',target:editor.menu.querySelector('summary')});}
  if(mode==='completed-composition'){editor.field.focus();editor.field.listeners.get('compositionstart')({});editor.field.listeners.get('compositionend')({});editor.autosave.cancel();}
  const focus=document.activeElement;gate.resolve();await pending;
  assert.equal(editor.field.textContent,mode==='normal'?original:'SYNTHETIC same-owner B');assert.equal((await c.snapshot()).items.find(x=>x.id===editor.id).body,mode==='normal'?original:'SYNTHETIC same-owner B');
  assert.equal(calls.filter(x=>x.change?.kind==='put').length,mode==='normal'?2:1);
  assert.equal(document.activeElement=== (mode==='normal'?editor.field:focus),true);
  assert.equal(editor.journal.undo.length,mode==='normal'?0:1);
 }finally{gate.resolve();editor.autosave.cancel();}
}));
