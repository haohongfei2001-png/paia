import {test,assert,fixture,put,deferred,tick} from './fixture.mjs';

for(const admissionToken of ['null','non-null'])test(`review synthetic deletion late clear captured ${admissionToken} token`,()=>fixture(async({c,recovery,makePage,transport,dispatch,calls})=>{
 const page=makePage();await page.open('info');await tick();const target=[...page.editors.values()][0];
 const seed=admissionToken==='null'?null:crypto.randomUUID();if(seed){const change={kind:'put',operationId:seed,epoch:'initial',itemId:target.id,expectedRevision:1,body:target.saved.body,section:target.saved.section,card:'info'};await target.recovery.protect({type:'PAIA_CONTEXT_CARDS_CHANGE',change},seed);}
 const gate=deferred(),entered=deferred();transport.dispatch=async message=>{if(message.type==='PAIA_RECOVERY_DRAFT_SAVE')await c.recoverySources(message.draft);if(message.change?.kind==='delete'){entered.resolve();await gate.promise;}return dispatch(message);};
 const pending=page.remove(target);await entered.promise;try{
  target.field.textContent='SYNTHETIC B admitted before delete transaction';target.changed();target.autosave.cancel();if(target.recovery.running)await target.recovery.running;const stored=await recovery.load('context_item',target.id);assert.ok(stored);assert.notEqual(stored.token,seed);
  gate.resolve();await pending;assert.equal((await recovery.load('context_item',target.id))?.token,stored.token,'newer B token remains stored, without claiming cold recoverability');
  const clears=calls.filter(x=>x.type==='PAIA_RECOVERY_DRAFT_CLEAR'&&x.draft.ownerId===target.id);assert.deepEqual(clears.map(x=>x.draft.token),seed?[seed]:[]);
  assert.equal((await c.snapshot()).items.some(x=>x.id===target.id),false);
 }finally{gate.resolve();target.autosave.cancel();}
}));

for(const kind of ['delete','restore'])test(`review synthetic ${kind} completion refuses newer epoch UI`,()=>fixture(async({s,c,makePage,transport,dispatch})=>{
 const second=put('info');await c.change(second);const page=makePage();await page.open('info');await tick();const target=[...page.editors.values()][0];if(kind==='restore')await page.remove(target);
 const gate=deferred(),entered=deferred();transport.dispatch=async message=>{const result=await dispatch(message);if(message.change?.kind===kind){entered.resolve();await gate.promise;}return result;};
 const pending=kind==='delete'?page.remove(target):page.undoDelete();await entered.promise;try{
  await s.repository.transaction(true,t=>t.put('meta',{id:'recovery-restore-epoch',value:'SYNTHETIC reviewer newer epoch'}),['meta']);await page.refresh({force:true});
  page.journal.clear();const sentinel={itemId:'SYNTHETIC current journal sentinel',revision:12,deletedBy:'SYNTHETIC latest action'};page.journal.record(sentinel);
  page.notice('SYNTHETIC newer epoch notice');const sibling=page.editors.get(second.itemId);sibling.field.focus();const focus=document.activeElement;
  gate.resolve();await pending;
  assert.equal(document.activeElement===focus,true);assert.equal(page.message.textContent,'SYNTHETIC newer epoch notice');assert.deepEqual(page.journal.undo,[sentinel],'old ACK cannot add/pop current epoch Undo history');
  assert.equal(page.snapshot.epoch,'SYNTHETIC reviewer newer epoch');
  assert.equal((await c.snapshot()).items.some(x=>x.id===target.id),kind==='restore');
 }finally{gate.resolve();}
}));
