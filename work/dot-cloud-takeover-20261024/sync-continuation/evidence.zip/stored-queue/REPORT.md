# Original recovery stored-read queue admission

## Separate source and causal evidence

This is a separate follow-on to empty Context enrollment source
`fa32ca8546d151b256cb6abc40bc9cc746e85761`, with its evidence parent
`4d2df9429598fb84c9583a5ba3f62c4868a33e88`. It changes only the original Store
queue entry and `LocalSyncRecoverySession.#stored(work)` ordering. The original
negative-tail freeze and empty-enrollment source/tests remain intact. Root owns
integration and publication; this is not native/provider/full qualification.

The single separately approved diagnostic is preserved unchanged in
`work/empty-context-enrollment-20261024/RESOURCE-DIAGNOSTIC.md` and its archive.
Both observed all-deleted publication failures first hit original
`idb-repository.js:549`, `recovery.pending`, with references 1, bytes 104,
pending/window true, active callback phase, and 29,996.696403 / 29,998.553879 ms
remaining. The competing caller was the actual idle Thought purge preflight,
not reference/byte/time quota exhaustion. Its original Store queue work
collided with recovery's direct stored-stage observation outside that queue.
This proves those two observed invocations, not every historical resource error.
No diagnostic retry was run.

## Narrow original-owner correction

The original ticket is still created before waiting, with its original finite
4096-reference / 2 MiB / at-most-30-second allowance and original serial check.
The two stored-stage observations now join the same existing original Store tail
before opening that ticket's original repository recovery window. Queued local
maintenance before or after this observation therefore cannot borrow its ticket.
No new queue, global pause, scheduler suppression, async-local substitute or
shadow repository exists. Other `#native` operations retain their original
owners and are not blanket-wrapped, avoiding nested Store-queue deadlocks.

`indexed-store.js` captures its original `run` implementation and uses a private
queue-only token. The exported scheduling helper requires a genuine original
Store-to-repository/local-adapter binding and an already-loaded, already-open
physical database, before and inside the queued callback and after completion.
A substituted public `run` is not authority. Queue-only scheduling uses captured
native Promise settlement on the existing tail. A fake thenable is refused;
a substituted native-Promise `then` is ignored. Neither its return value nor
a counterfeit Promise-species result can provide stored data or completion:
a native task resolves only from the actual one-shot original queued execution.
The normal public `run` scheduling path is unchanged. Queue-only entry retains the
original execution-interference bookkeeping but does not initialize storage,
refresh/read local control data, create a control scope, or grant transaction or
write authority. All actual reads still enter the unchanged original Core and
repository scope while the original ticket is active.

The existing bounded read/cancellation wrapper now covers queue admission using
the original deadline and captured serial. Pause, close and expiry settle while
previous local work is still held. A late queued callback rechecks that serial
and the original ticket before opening a window or reading native data. Resuming
the session cannot make the earlier callback current again. Physical database
replacement and overlapping public-tail aliases fail closed.

`idb-repository.js`, including the same-ticket pending overlap guard, was not
edited. Direct overlapping repository work still receives that original
refusal. This correction claims ordering for this exact stored observation and
same-Store queued work, not global attribution/isolation for arbitrary direct
repository consumers. No limit, fixture, page size, automatic behavior,
checkpoint content, permission, native capability or recovery ticket is reset.

## Independent correction before freeze

Independent review found that the first captured-run implementation still
called mutable public `store.tail.then`. A fake thenable returned forged stored
stage data without invoking the real action. This was a real candidate defect,
not an original baseline failure. The exact independent failure is retained in
`independent-forged-tail.log`. The intrinsic/native one-shot scheduling described
above corrects it. Added tests cover fabricated return, dropped/replayed callback,
substituted genuine Promise `then`, and forged Promise-species completion.
The pre-review 12-test and full owning successes below are not final acceptance.

## Verification and preserved failures

- Initial selected smoke: 4/4 pass.
- First new regression run: 6/12. The six failures were incorrect test observer
  expectations (one Core call plus a direct stage repository read, not two Core
  calls; fresh repository `db` was undefined, not null). The exact log remains.
  Only those assertions/observers were corrected; runtime bytes did not change.
- Corrected deterministic queue regressions: 12/12 pass, zero skips.
- Complete original local, causal-tail and negative-tail recovery files,
  unchanged complete portable checkpoint file, and new queue regressions:
  **124/124 pass**, zero failures/skips/cancellations, 76,329.257569 ms.
  This includes all four original Google/OneDrive × all-deleted/surviving-Working
  A-to-B-to-cold-edit-to-C cases, without fixture or Resume changes. The portable
  file is 18/18 on this changed source.
- Existing original Store/Prompt queue, control identity, preload, material,
  pending-lifetime, fallback and control-publication owners: **202/202 pass**,
  zero failures/skips/cancellations, 17,757.91048 ms.
- Complete empty-Context enrollment worker/lifecycle/journal/desired-access and
  Settings owners on the changed Store source: **122/122 pass**, zero failures,
  skips or cancellations, 45,635.609838 ms.

## Final corrected-source verification

After the independent forged-tail correction, the exact source hashes in
`source-sha256.txt` received these complete results:

- Original local/causal/negative recovery and unchanged portable files, plus all
  17 queue regressions: **129/129 tests pass**, zero skips/cancellations, in
  83,799.857551 ms (`final-owning.log`). The total rose from 124 by the five
  new small tail-substitution tests; this is not the separately excluded
  129/100k scale workload. All four original cold portable worker routes pass.
- Complete Store/Prompt/control and enrollment/worker/Settings owners together:
  **324/324 tests pass**, zero skips/cancellations, in 62,671.313971 ms
  (`final-store-enrollment.log`).
- Independent final reviewer: **102/102** complete queue/Prompt identity/pending/
  Context journal tests and **7/7** additional forged/dropped/replayed tail and
  Promise-species controls pass, zero skips. The reviewer verifies all unchanged
  file hashes and reports no remaining concrete code blocker on these exact
  three source/test hashes. Final commit binding is recorded separately.

The earlier base27/32, first candidate107/108, pre-review133/134,
empty-enrollment aggregate151/154 and diagnostic16/18 remain failed historical
results. The separate filter-owner expected-rejection baseline case is not
changed or relabelled by this follow-on. Its correction belongs to its own
owner. The new result is evidence on changed source, not a retry that declares
an unexplained old resource refusal transient.

The deterministic tests exercise actual idle Thought cleanup before and after
stored-stage reads, no ticket borrowing, one unchanged ticket for both stored
observations, no local-control prelude/writes, public-run substitution,
fresh/fake/foreign Store no-init refusal, physical DB change, queued stage and
discovery pause/close/deadline, late callback nonrevival after resume, public-tail
interference, and the unchanged actual same-ticket pending refusal.

Syntax checks and `git diff --check` pass. All executions are small synthetic
fake-IndexedDB tests. The complete owner/regression invocations used the
recorded 120-second process ceilings. No browser,
native, Full, C, 129/100k, real account, paid model, install/deploy, remote write,
missing historical blob fetch/replacement, or production-owner edit outside the
approved two-file locks was performed.
