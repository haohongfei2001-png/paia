# Independent review: original recovery queue admission

Base: `4d2df9429598fb84c9583a5ba3f62c4868a33e88`, retaining enrollment source `fa32ca8546d151b256cb6abc40bc9cc746e85761`.

Conclusion: no remaining concrete code blocker in this bounded queue-before-ticket follow-on. Review is bound to the exact three files listed below; publication/integration remain Root's responsibility. This does not establish native, browser, provider, full-suite or whole-programme acceptance.

## Exact reviewed SHA256

- extension/core/indexed-store.js: `ea161a78eaa62526bca5a7aedf2398c6cc976f44f74a8601e3142e434f3cb530`
- extension/core/browser-native-sync/recovery-session.js: `ce81d2e2a87c60275cbf879bbde463667ffc3b6918633059537bcfe9dc0fe6be`
- extension/tests/sync-recovery-queue-admission.test.mjs: `ae4325a147a095bac4d1559057965e9278e49c8dfbc007b827891257da8303b1`

## Finding and correction

The first candidate bypassed public Store.run but still trusted mutable `store.tail.then` return data. An independent repro returned a fabricated activated-stage shape with the actual queued action invoked zero times. This was a real candidate defect, preserved in `forged-tail.log` and the first regression script.

The corrected private queue-only path calls captured native Promise scheduling and uses its own native completion resolved only by the actual one-shot original execution. Non-Promise fake tails fail closed without calling their methods or action. Substituted then methods on genuine native promises are ignored. Arbitrary Promise species return objects cannot counterfeit action completion. The ordinary public run path retains its previous then/catch behavior.

## Boundary review

The helper is bound to the genuine Store's original repository/local adapter and already-loaded/open physical database before and inside execution and after completion. It uses the same existing Store tail and original execution-interference bookkeeping. It performs no initialization, control refresh, or control/native authorization minting. Only the original stored-stage reads receive queue admission before the existing recovery window; other #native operations are not blanket-wrapped.

The original work ticket is created before waiting. Existing bounded read deadlines and captured session serial cover admission. Pause, close and expiry settle while queued; late callbacks recheck the original serial/ticket before any recovery window or read. A resumed session cannot revive an older callback. The active genuine-run/public-tail alias, physical-database replacement and direct same-ticket pending-overlap guards remain fail-closed.

Verified all hashes in the implementer's unchanged-files manifest, including idb-repository.js, original portable and filter fixtures, original lifecycle, Context owner and Settings UI. No limits, fixture content, repository pending guard or frozen negative-tail/enrollment semantics changed. This establishes ordering for the specific stored-stage observation and same-Store queued work, not global isolation of arbitrary unqueued repository consumers.

## Independent verification

- Initial targeted queue tests: 12/12, zero skips; `initial-targeted.log`. This did not cover the forged-tail defect.
- Final complete queue17 + original Prompt control identity/pending lifetime + Context mutation journal files: 102/102, zero failures/skips/cancellations; `final-independent-owning.log`.
- Seven independent non-Promise forge/drop/replay, overridden native-Promise then and malicious species-return checks: 7/7, zero failures/skips/cancellations; `final-independent-tail.log`.
- `git diff --check` clean; all reviewed source hashes reverified after final tests.

## Complete implementer evidence inspected

- Final original recovery/causal/negative-tail + unchanged full portable + queue17 suite: 129/129, zero failures/skips/cancellations, 83,799.857551 ms.
- Final complete original Store/Prompt and enrollment owners: 324/324, zero failures/skips/cancellations, 62,671.313971 ms.
- All four original Google/OneDrive all-deleted/surviving-Working cold worker flows pass on this changed source without fixture/Resume changes.

Earlier enrollment151/154 and diagnostic16/18 remain failed historical results. The separately owned filter expected-rejection baseline case was neither changed nor relabelled by this follow-on. No real browser/native, broader Full/C or large-scale gate, account, paid, installation, deployment or remote write was performed by this review. All tests use existing small synthetic Node/fake-IDB fixtures.

## Confirmed frozen commit and evidence binding

This review applies to committed source/evidence `592764a60406cf3fba3eb5ecd3778a7efdd9b970`, tree `c8b4de310af37c786651d1b1bd7376f039cc01cf`, parent `4d2df9429598fb84c9583a5ba3f62c4868a33e88`. All three reviewed source/test hashes were reverified unchanged after commit.

Verified frozen implementer report: `work/sync-recovery-queue-admission-20261024/REPORT.md`, SHA256 `b8afd3ba14c83664df1e53d567fbe732c93e347216de4e6afb399b717a7ca394`.
Verified initial frozen evidence archive: `work/sync-recovery-queue-admission-20261024/evidence.zip`, SHA256 `ff0364ac47f3dbc2a1e42e8f19f01010c80a127b435caf70f7e115fdec79854e`.

An evidence-only successor may add this final review without changing the reviewed source bytes or rewriting this commit. Its archive identity is separate from the initial frozen archive above.
