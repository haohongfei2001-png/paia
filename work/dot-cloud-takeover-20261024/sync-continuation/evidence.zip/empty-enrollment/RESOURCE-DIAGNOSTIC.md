# One bounded original resource-refusal diagnostic

Source: `fa32ca8546d151b256cb6abc40bc9cc746e85761`.
This was the single separately approved diagnostic, not a production change or
an acceptance retry. The original complete portable test file was unchanged.
The process ran under a 120-second TERM / 5-second KILL ceiling and exited 1 in
20,592.029789 ms: 16/18 pass, two all-deleted provider cases fail. No skips.

## Observed cause in this invocation

Both Google and OneDrive all-deleted original A-publication failures reach the
same first refusal: original `idb-repository.js:549`, the existing
`recovery.pending` overlap guard. At that branch:

- references: 1; bytes: 104;
- pending: true; recovery window: true; active transaction phase: callback;
- remaining deadline: 29,996.696403 ms / 29,998.553879 ms;
- the interrupted original scope has 4096-reference and 2,097,152-byte limits,
  with approximately 29,998 ms scope time limit.

The competing request is the original readonly idle purge-maintenance preflight
at `thought-maintenance.js:71`, through `thought-store-owner.js:82`,
`smart-filter-store-owner.js:57`, `ia-store-owner.js:43` and `indexed-store.js:203`.
It collides with the original recovery `#stored` lookup in `#discover`, under
`withOriginalRecoveryWork`, invoked by checkpoint publication `#head`.

The guard then aborts/marks the original work failed and its finalizer preserves
the resource error. The diagnostic does not establish that all historical
resource failures had this same cause. For these two observed failures it is
transaction overlap, not reference/byte/deadline exhaustion. It is unrelated to
the later cold empty-Context binding check, which neither case reached.

## Instrumentation integrity

Only three files in a disposable 58 MiB copied source tree were instrumented:
`core/idb-repository.js`, `core/browser-native-sync/group-page-reader.js` and
`background/sync-local-lifecycle.js`. Insertions emit only refusal branch/count,
primitive work counters/phase and sanitized code-location stacks. Every original
condition, throw, limit, ticket, page size, scheduler and fixture remains.
Removing the explicitly delimited diagnostic insertions reproduces each original
file byte-for-byte; every other copied file is identical. Exact before/after
hashes, stripped verification, complete instrumentation diff/script, unchanged
test hash, command, exit code, raw log and parsed events are in
`resource-diagnostic.zip`. No source bodies, credentials or real account data
were logged. The original reviewed production source is unchanged.

## Boundary and next owner

No follow-up run or production fix was performed. A separate original-owner
investigation should address head-discovery/recovery work coordination with the
same-store maintenance queue. Do not increase limits, reset the ticket, suppress
maintenance, shrink the fixture, weaken the overlap guard or call this a
transient pass. The 151/154 uninstrumented aggregate and all older failures
remain failed. Root owns any new file locks and integration decision.
