# Empty Context cold enrollment consumer repair

## Scope and source

This is a separate local consumer correction on frozen negative-tail source
`41db1b0fa45f5fea6b19cfbcc9cec0afe85e6109`, not a change to that tail's recovery,
publication, target-purge or admission semantics. All original failure records
remain. Root owns publication and integration/version decisions.

The original worker explicitly resumed on an empty/default Context before
restore, but `#enrollContext` emitted no Item/access journal state. On cold open,
the original Context journal was therefore unbound and `NOW` correctly returned
`BNS_CONTEXT_BOOTSTRAP_REQUIRED`. Settings simultaneously offered `NOW` and
`RESUME`. Canonical BNS contract §BNS-08 requires normally usable empty datasets
without manufactured Context; its worker-termination row requires durable
continuation.

`ContextDesiredSyncJournal.bootstrapAccess` is a genuine existing producer for
an existing desired-access value, including revision zero. It was not used as
an enrollment token: doing so would create unrelated portable intent and expand
the finite negative portable scope. No Context Item, access choice, revision,
operation receipt, outbox entry or portable grant is manufactured here.

## Minimal local receipt and original owner

Only explicit `RESUME` may persist optional `contextEnrollment` in the existing
`paia-sync-local-lifecycle:v1` local row:

- `version: 1`;
- persistent physical `databaseId` from the active original migration;
- actual Core `namespace`;
- actual restore `epoch`, including null before restore.

The outer existing `bindingId` and configuration `generation` remain mandatory.
The receipt is data, not a capability. Original
`core/browser-native-sync/context-mutation-journal-owner.js` provides only a
readonly `emptyEnrollment(service)` observation. It requires genuine original
Store/Core/service/fence identities, a loaded and already-open exact database,
original repository transaction/data methods and successful settlement, original
current control/publication facts, matching active migration, and byte-exact
`emptyContextCards()`.

No public `Store.run` result is trusted: that method is intentionally excluded
from an existing owner-identity guard and can initialize storage or be replaced.
The new observation cannot initialize a fresh store or reopen a closed database.
The exact owner/control/fence/database identity is checked again before returning.
An unbound service stays unbound; no read, write or restore capability is minted.

Cold attachment compares the optional receipt to the fresh original observation,
then rechecks the exact lifecycle row identity, binding, configuration generation
and host-current predicate after the awaited read. Missing, foreign, stale,
malformed, changed-epoch/namespace, unmanaged nonempty and nondefault-access
situations cannot use an empty receipt. Status/startup never creates or repairs
one. Existing nonempty journal attachment/enrollment stays with the original
Item/access owners. A stale existing receipt is retained rather than silently
cleaned up.

Settings with `needsContextEnrollment` now hides/guards `NOW` and explains the
explicit `RESUME` prerequisite in both languages. The worker's original guard
remains. No automatic Resume or transport request was added.

## Compatibility and explicit paused rollback

This is an optional versioned field in the existing local lifecycle row, not a
canonical database schema migration. Existing rows without it retain their
previous behavior. An older strict v1 reader rejects the unknown field with
`BNS_SYNC_STATE_CORRUPT`: downgrade is deliberately fail-closed.

If an explicitly requested downgrade/rollback is necessary, first use the
current owner's explicit `PAUSE` and verify its durable paused row. Then stop the
current worker and remove only the optional `contextEnrollment` field from that
same local lifecycle row. Preserve every other property, task/reference,
revision, binding, mode and error, and every canonical/protocol/control row.
Do not replace the row, reset the task, clear the database, or change permissions.
The old reader then accepts the original paused row; cold Context again requires
explicit enrollment. There is no automatic cleanup or rollback implementation.
The test uses the byte-for-byte original `checked()` body from the frozen base,
with its original-body SHA256 in the fixture, and proves receipt-only removal
preserves all tables and task state.

## Preserved baseline and review corrections

- Exact frozen base, original two complete files: **27/32**, five failures.
  Four Google/OneDrive × all-deleted/surviving-Working cases fail at original
  cold `NOW`, line 19, with `BNS_CONTEXT_BOOTSTRAP_REQUIRED`. The fifth is the
  independent original filter-owner rejection expectation, not the same cause.
  `baseline-two-files.log` preserves the raw invocation.
- First candidate five-file run: **107/108**. Three unchanged portable cold
  flows pass; Google all-deleted stops earlier at original publication line 17
  with `BNS_GROUP_RESOURCE_LIMIT`. `first-owning.log` is retained as failed.
- Pre-review six-file serial run: **133/134**. The same Google all-deleted early
  publication resource failure remains, in `owning-serial.log`.
- Independent review reproduced a missing post-await host recheck, fresh-store
  read initialization, and substitution/delayed-result vulnerabilities through
  public `Store.run`. These were real candidate defects, not baseline failures.
  The corrected original readonly path and final binding rechecks address them.
- Corrected Context/worker smoke: **29/29**. Targeted original-owner, cold
  rejection, held host/lifecycle and no-init checks: **23/23**. Original-reader
  and explicit paused rollback: **1/1**. These are separate commands.
- Independent reviewer reports **121/121** complete Context journal/shadow/
  desired/manual/coexist/Settings cases on corrected source, plus **26/26** independent
  final targeted fresh-store, substituted-run, host/lifecycle-race and rollback checks. Final snapshot review is
  recorded separately by Root.

Neither the original five failures nor the candidate resource failures are
relabelled by any later pass. The first resource failure varied across provider
variants in predecessor evidence. Its precise cause remains unestablished here;
four-case overall publication acceptance remains pending that separate issue.
No timeout/byte/reference bound, concurrency rule, recovery ticket, fixture size,
automatic behavior, target-purge guard, or native-capability check changed.

## Final verification

Final seven-file serial owning run on `source-sha256.txt` bytes: **151/154**,
zero skip/cancel/todo, 70,921.532236 ms. It is a failed aggregate, not acceptance.
Both unchanged surviving-Working portable A→B→cold-edit→C cases pass. Both
all-deleted provider cases stop at original A publication line 17 with
`BNS_GROUP_RESOURCE_LIMIT`, before their cold enrollment phase. The original
filter-owner expected-rejection case also remains failed. `final-owning.log`
contains all raw outcomes. No assertion or Resume was added to either original
failure file. `commands.txt` preserves the exact command.

`git diff --check` and syntax checks for all three changed production modules
pass. Independent final source review reports no remaining concrete code blocker;
that is separate from the still-failed aggregate and unresolved publication work.
The review's exact file hashes and raw independent results are included in the
evidence archive.

No browser/native, Full, C, 129/100k, real account, paid model, installation,
deployment or external write was performed. This slice is not whole-programme,
production-provider, native or four-case resource qualification.
