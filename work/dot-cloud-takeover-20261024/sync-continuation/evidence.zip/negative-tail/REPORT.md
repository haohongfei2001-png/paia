# Original negative checkpoint continuation — 2026-10-24

## Identity and scope

Source/test commit: `41db1b0fa45f5fea6b19cfbcc9cec0afe85e6109`.
Source/test tree: `62326661db69cab54ab0b24b94893c919df5a992`.
Base: `7664b093e46874d344bc532a96641ae0c302b11c`.
Branch: `codex/negative-tail-continuation-20261024`.

This implements one bounded existing BNS recovery gap: a durable, validated negative v1 checkpoint may advance through a sole authenticated single-parent negative causal chain before activation. The only new remote delta is an original `sourcePurgeIntent` group permanently denying a previously represented, complete independent initial Source. The actual existing trusted `PAIA_SYNC_CONTINUE` consumer supplies this path; no new command, caller-provided reference, provider/account permission, or production activation was introduced.

Runtime locks are only `background/sync-local-lifecycle.js`, `core/browser-native-sync/recovery-session.js`, and `core/browser-native-sync/source-purge-group.js`. Test locks are only the new `tests/browser-native-sync-recovery-negative-tail.test.mjs` and existing `tests/sync-local-lifecycle.test.mjs`. Product plans, schema, workflows, manifests and package versions are unchanged. A coherent integration owns any applicable version adjustment and later acceptance gates.

## Original red and actual consumer

Two synthetic independent initial Sources are created through `SourceBootstrapJournal`. The first genuine permanent-ignore and cleanup produce N1: one negative Source plus one initial positive Source. B's original native activation is deliberately aborted, preserving its real validated N1 stage. A's original second purge and cleanup produce N2 through `RecoverableCheckpointPublication`, with N1 as its causal parent. A closes; B cold-opens and receives the existing trusted `PAIA_SYNC_CONTINUE` command.

On the original runtime, this command activates pinned N1 and leaves one Source present: the assertion reports `1 !== 0`. This is the substantive original red, not a fabricated manifest or a replaced owner result. The implemented consumer selects N2, keeps the same restore ID, performs no original positive Source application even transiently, and activates two permanent denials. Both stale original bootstrap groups remain rejected, and incoming application emits no local outbox echo.

An earlier fixture attempted direct provider-mutating checkpoint export and correctly hit the original snapshot-change guard. That failed fixture is retained separately; using the existing recoverable publication owner corrected the fixture rather than weakening a guard.

## Owner, continuation and budget invariants

- The source-purge owner independently reauthenticates old/new complete manifests, exact revisions, original seven-target/eight-operation denial groups, retention and the precise purge-only delta. Existing negative intent remains exact. `requireCheckpointRevisionRetention` admits only its original authenticated body-redaction exception.
- Every causal edge is validated before replacement. Multi-parent/reconverged paths, incomparable heads, missing ancestry/shards, repeated listing cursors, unchanged-denial fabricated children, unsupported positive additions, wrong references and corrupted stage inventory remain refusals.
- Before lifecycle candidate CAS, the original owner proves the exact durable row, authenticated old manifest/revisions, database/namespace/epoch, original physical base digest, complete current qualification and final recapture. No refreshed local baseline becomes authority.
- Lifecycle candidate persistence precedes original owner advancement, using existing local-row compare/read-back. A saved candidate may be ahead of the durable stage after interruption; the next explicit continuation proves both on the same retained chain. Unknown local write or native acknowledgement never causes blind retry or a replacement restore ID.
- The owner performs complete local/remote application preflight before the strict transaction changes the body-free stage row. Activation remains with original cold-denial application, protocol receipts, physical prediction and terminal rollback fences.
- One original 4096-reference / 2 MiB / 30-second work ticket covers discovery, every owner reread and transaction, actual lifecycle continuation storage operands/results, and final activation/confirmation. Lower deadlines remain supported; no allowance resets, prepaid counts or raised caps were added. Direct negative tail reconciliation outside the branded work envelope is refused.
- A held candidate or terminal lifecycle acknowledgement is bounded by the same deadline. Cancellation of a held local write reports uncertain outcome and does not queue another write behind it. Late completion cannot gain fresh authority. An already confirmed native activation stays known restored even when lifecycle confirmation is unknown.
- Independent user stop controls do not inherit an already-interrupted recovery ticket. They also cannot claim durable pause when an earlier local write is still uncertain.

## Deliberate limitations and migration/rollback

Positive-to-negative owner handoff, reverse tails, live-target deletion, edited/append Source purge, settings-v2 publication, arbitrary Human/Context negative families and broader protected-generation authority are not admitted. Unchanged/activated/publishing and unsupported-family stages keep their original exact-reference confirmation behavior. Production configuration remains absent/default-off.

A valid remote descendant can conflict with an already-live identical local Source. In that case the authenticated lifecycle candidate may remain selected, but the original cold owner refuses the live/full-versus-redacted overlap. The old validated stage, local Source and all other rows remain untouched. This is an explicit unsupported-local-owner result, not successful continuation and not authority to delete the live Source. Unsupported remote deltas and corrupt local stage bindings are rejected before candidate selection.

No schema migration or new persistent progress format is used. Existing v1 rows retain restore ID, database, namespace, epoch and base digest. An older reader can confirm a same-schema final stage but does not gain continuation support. Rollback cannot erase an activated denial/tombstone or later human work. Failed activation leaves the original stage and canonical data intact; lost acknowledgement is resolved from original durable state.

## Verification

Only Node `v24.19.0`, repository fake IndexedDB, original production functions, small synthetic fixtures and injected fake HTTP were used. No native/browser run, Full/C run, 129/100k experiment, real provider/account, credentials, installation, dependency install, deployment, or remote Git write occurred.

The frozen five-file SHA-256 inventory, final and baseline commands, and chronological logs are included in `evidence.zip`. Earlier commands not retained verbatim are not reconstructed. Historical outcomes are retained separately:

- Initial fixture: 0/1, original snapshot-change refusal; fixture corrected to use original publication.
- Genuine original trusted-CONTINUE red: 0/1, stale N1 incorrectly materializes Source2.
- First implementation and shared-preflight focused runs: each 1/1.
- First direct owning batch: 18/20. One test incorrectly expected a transaction argument the checkpoint did not expose; the other hit the original 64 KiB stage limit before its intended cumulative-byte edge. Both failures are retained. The corrected tests use the real original activation transaction and repeated actual native payload reads.
- Corrected direct owning batch: 20/20.
- First composed consumer batch: 52/54. Two storage-injection fixtures changed an already-bound control method and correctly triggered original control identity refusal. Installing the injected storage method before cold-opening corrected the fixtures; no control guard changed.
- Isolated original confirmation fixture failures: 0/2, retained separately.
- Corrected two-store acknowledgement batch: 5/5.
- Original-anchor-qualified consumer batch: 6/6.
- Recovery/consumer regression batch: 123/123, no fail/cancel/skip/todo, 33728.029216 ms.
- Added missing-shard/repeated-cursor/live-target cases: 3/3.

## Frozen final result and independent review

The complete 11-file serial run on the frozen source tested **286 cases: 281 passed, 5 failed**, with zero cancellations, skips or todos, in 174355.678106 ms. No failing case was dropped or relabelled. The five failures are one canonical-generation `filter-owner` refusal assertion and all four Google/OneDrive × all-deleted/surviving-Working portable checkpoint consumer cases. All four candidate portable failures are the cold worker `NOW` at line 19, column 456, returning `BNS_CONTEXT_BOOTSTRAP_REQUIRED`; they are not preference-update failures.

Independent source review found no remaining blocking finding in the bounded negative-tail implementation. Five frozen independent deadline, irreversible-activation, corrupt-binding and actual lifecycle cancellation probes passed 5/5 in 16035.247428 ms, with source/test SHA-256s unchanged. Review reproduced two genuine implementation defects before correction: cancellation during a held candidate storage acknowledgement, and corrupt stage/database binding reaching candidate CAS. Original failed and corrected logs are preserved. An older final reviewer fixture was stopped after four direct passes because it changed a bound storage method after Store load; the corrected fixture installs the fault before cold reopen and bounds its entry wait. That fixture correction is not a waived product assertion.

The full aggregate remains failed and overall acceptance is withheld. Independent bounded source review does not waive those five adjacent failures. These small synthetic tests do not establish native/provider qualification, whole Sync completion, installation, or whole-programme acceptance.

## Exact baseline comparison and separate follow-on

A detached checkout at exact base `7664b093e46874d344bc532a96641ae0c302b11c` ran the two failing whole files unchanged: **32 cases, 27 passed, 5 failed**, zero cancellation/skip/todo, 25017.880719 ms. The same five names fail. The `filter-owner` assertion and three portable variants fail at the same assertions; the baseline OneDrive all-deleted variant instead hits `BNS_GROUP_RESOURCE_LIMIT` earlier at line 17. This earlier resource failure is retained and not presented as an identical cold-NOW reproduction. The initial comparison command accidentally ran the root checkout after creating, but not entering, the detached worktree. Its separate 27/32 log is explicitly a root crosscheck, not base evidence. Root HEAD read back as `af560f6de7a478e3c45937d628581bb87def8c0a`; that is a readback, not a claim the concurrent root branch was pinned for the run.

Source-backed classification, with no adjacent repair in this snapshot:

1. **Stale genuine-filter-owner refusal.** `tests/canonical-generation-negative-recovery.test.mjs:53` installs a real `FilterIntentSyncJournal` and then expects purge rejection at line 55. The original `source-purge-journal.js:43–55,117–118` now deliberately admits that exact same-core original owner while requiring original transaction authority and unchanged initial filter state. `tests/browser-native-sync-source-purge-filter.test.mjs:18–21` positively specifies original capture→purge, separately refusing forged/foreign/altered owners, human Keep/Working, unknown/evaluated filter state and late resurrection. Minimal separate test lock: `canonical-generation-negative-recovery.test.mjs`. Preserve the other six refusals, replace the obsolete genuine-owner-as-defect with an actually forged/rebound owner refusal, and add original-owner success with stale-source replay denial. Do not weaken the runtime filter guard.

2. **Existing empty-Context cold consumer mismatch, not an ownership defect to bypass.** In `sync-local-lifecycle.js:138–147`, explicit `RESUME` enrolls Context but emits original journal facts only for actual Items or nondefault access revisions. The portable fixture's Context is empty/default, so B's pre-restore `RESUME` leaves no represented Context fact. On cold startup `attachContextService` at lines 126–135 correctly refuses to invent a bootstrap and leaves the journal unbound. The legitimate publish guard at line 200 rejects cold `NOW`. Yet `ui/settings-sync.js:30,35` simultaneously shows the required `RESUME` and allows `NOW` without checking enrollment. Thus the fixture omits the currently required explicit route, but simply adding `RESUME` would not fix the misleading consumer affordance or prove durable empty enrollment. The canonical contract requires empty datasets to stay normally usable without manufactured Context (line 133), and preserves durable work on worker termination (line 236). Minimal safe follow-on should retain the guard and use original `RESUME`/status controls: gate new `NOW` while enrollment is required and test the actual explicit enrollment route, with locks in `ui/settings-sync.js`, `tests/settings-sync.test.mjs`, `tests/sync-worker-context-consumer.test.mjs`, and `tests/source-purge-portable-checkpoint.test.mjs`. If seamless cold empty enrollment is selected instead, first identify an original owner-authenticated empty-enrollment producer and exact durable binding; `mode: active` alone is not authority and no marker should be invented as a fixture shortcut. That runtime design would separately own lifecycle and, only if justified, the original Context journal owner. It is not implemented or accepted here.

3. **Earlier baseline resource refusal remains separate.** The baseline OneDrive all-deleted producer failure is not diagnosed as uniquely caused by Context. Preserve its exact log and investigate under the existing ordinary limits if reproduced by the separate follow-on. No threshold, deadline or resource guard may be raised to force the old consumer case through.

No adjacent source/test path was edited for this classification. The frozen negative-tail source remains `41db1b0`; any follow-on must retain the failed final and baseline identities and obtain its own coherent controls/evidence.
