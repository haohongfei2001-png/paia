# Source-proven original Filter owner regression repair

Date: 2026-10-24. Isolated candidate based on `41db1b0fa45f5fea6b19cfbcc9cec0afe85e6109`, parent `7664b093e46874d344bc532a96641ae0c302b11c`. This is a test-only correction, not a runtime or permission change.

## Classification and authority

The former `selected Source purge refuses filter-owner` case constructed a genuine `FilterIntentSyncJournal` bound to the same original core and incorrectly expected purge refusal. It is a superseded test assertion, not evidence of a missing runtime guard:

- `extension/core/browser-native-sync/source-purge-journal.js:39-55,115-118` explicitly admits only the constructor-private original Filter owner with the original Source purge/core binding, requires the initial unedited filter state, and enforces the original transaction and final-write fences.
- `extension/core/browser-native-sync/filter-intent-journal.js:118-125` checks constructor-private registration, prototype, original core/fence/prepared/working identities and unchanged method identities. Same-shaped objects or rebound owners cannot supply this authority.
- `extension/core/smart-filter-store-owner.js:201-203` refuses an invalid Filter owner with `BNS_FILTER_WRITER_UNSUPPORTED` and requires the admitted original purge transaction before deleting filter rows.
- The unchanged complete `browser-native-sync-source-purge-filter.test.mjs` requires genuine capture -> purge -> body-free publication while retaining fake/foreign/altered owner, human Keep/Working, unknown/missing/evaluated filter, late resurrection/journal swap and unknown-publication refusal controls.
- Current canonical `PRODUCT_INTENT_CONTRACT.md` section 6 and `BROWSER_NATIVE_SYNC_CONTRACT.md` sections 3-4 retain human Keep/edit protection, distinct typed purge intent and permanent anti-resurrection. The BNS plan's verification guidance requires source-grounded fixture correction, complete affected files and truthful retained failures. No product rule requires blanket refusal merely because the legitimate Filter owner is present.

The original negative-recovery test, Source purge owner and dedicated filter-suite Git blobs are identical on base7664 and candidate41db. Their exact identities, including the changed test blob, are in `source-and-log-identities.json`.

## Exact scope

Only `extension/tests/canonical-generation-negative-recovery.test.mjs` changes, plus this scoped evidence directory. The stale genuine-owner denial is replaced by:

1. A real original-owner selected-generation path using the unchanged two-Source capture, grouped restore, complete copy retirement and cold-open fixture. It purges through the original Source and Filter owners, retains the other Source/Input/filter rows, removes the selected body, emits the original eight outbox records and permanent-ignore tombstone/deny row, then proves exact all-table persistence and replay refusal after another cold open.
2. A forged Filter instance with the genuine owner's exact prototype and own descriptors, refused by constructor-private identity with exact `BNS_FILTER_WRITER_UNSUPPORTED` and zero table mutation.
3. An original Filter instance rebound to a distinct core having the same repository/dataset/device configuration, refused with the same exact code and zero table mutation.

Every other original fixture and denial/protection/rollback assertion is unchanged. `preservation-check.txt` records an exact byte comparison after subtracting the deliberately replaced stale member and the additive cases. No capability DTO, registration bypass, fake materializer, native bypass, test skip, smaller fixture, weaker error oracle or runtime alteration was introduced.

## Executed evidence

Both invocations use the complete two files named in `commands.txt`, Node v24.19.0, local synthetic fake IndexedDB and no browser/provider.

- Unchanged candidate41db baseline: **28/29 pass, 1 fail**, exit1, 8615.367206 ms. The sole failure is the original `selected Source purge refuses filter-owner and preserves every table`, `ERR_ASSERTION: Missing expected rejection`, at the original line55. Exact stdout/stderr is preserved in `baseline-two-file.log`; it remains FAILED.
- Changed candidate: **31/31 pass**, exit0, 10752.968742 ms. The owning negative-recovery file is 16/16, dedicated filter suite 15/15. Zero failures, cancellations, skips or todo. Exact stdout/stderr is `candidate-two-file.log`.
- `git diff --check` passed. Runtime, package/version, dependencies, workflows and the dedicated suite are unchanged.

These counts are not the earlier negative-tail 11-file 281/286 run or base7664 two-file 27/32 comparison. Those original failures remain separate evidence. The unrelated empty-Context enrollment failures are outside this repair and were not touched.

## Boundaries and remaining gates

Independent review and integration belong to Root. No browser/native, Full/C, 129/100k, real account, paid operation, install, deployment or remote write was performed. This small synthetic result establishes only the repaired test contract on its exact source identities, not native, scale, provider or whole-programme acceptance.
