# Settings Assist queued authority settlement

Date: 2026-10-24 UTC. Bounded cloud-development candidate, not installed,
published, native-browser certified or a whole-plan completion.

## Exact scope and identities

- Base commit: `46759adf67acd089fa6d355fce787b517f02fa38`.
- Base tree: `82f563f384f2bc1d1078e04b1a5f77988681c834`.
- Original runtime Git blob: `91b68012a531a55bdaeaa7ac9170870f5c391549`.
- Fixed `extension/ui/settings-assist-state.js` SHA-256:
  `4ccde5074b556fac9d86c4777523ea65b2119c30fc38c8fa3bb7aea7e9d12548`.
- Final `extension/tests/settings-assist-state.test.mjs` SHA-256:
  `0a6b67f609f9cef965bc39b325061fe738b365dd334902b654f5ab0db0c02a2a`.
- Runtime: Node `v24.19.0`; no dependency installation.
- Only that existing state owner and existing test file change, plus this
  evidence directory. Parent integration owns any coherent version increment.

## Reproduced defect and unchanged authority

The original configure finalizer cleared `busy` and synchronously notified
observers before awaiting an already queued status read. An acknowledged write
can precede another window's revocation. While the authoritative read is held,
the original owner exposes that stale ACK with `editable === true`.

This reaches the existing mounted consumer directly: `settings-assist.js`
passes `changed: () => sync()`, and `sync` sets both switches' disabled state
from `!state.editable`. Actual trusted switch and confirmation listeners also
use that getter. Storage and runtime notices call the same `state.load()`.

This is a stale actionable presentation interval and an avoidable extra write
attempt, not evidence of backend reauthorization. The original worker's
generation CAS, independent permission checks, version-2 consent and default-off
behavior remain unchanged. No backend, provider, schema, source-body, draft or
permission owner is changed.

The existing state owner now uses one private read operation. Configure keeps
`busy` true while draining the pending notification flag, including notices
and synchronous observer refreshes arriving during a held read. Only after all
queued reads settle does it unlock and emit. Failed/malformed authority reads
remain noneditable; failed writes are never replayed and retain explicit
`save-error` / `save-unknown` feedback after a successful queued recovery.

## Original negative controls

The original runtime was not patched and reverted for the negative controls:
both ran before the production edit. At the second run, `git hash-object
extension/ui/settings-assist-state.js` and `git rev-parse
HEAD:extension/ui/settings-assist-state.js` both returned the original blob
listed above. The second run used the exact final test file hash listed above.

Command, run from the candidate worktree root in each invocation:

```sh
node --test --test-name-pattern='queued revocation keeps|mounted Settings switches' extension/tests/settings-assist-state.test.mjs
```

- `original-red.log`: exit 1; 0/3 pass, 3 failures, zero cancelled/skipped.
  Both state tests first assert busy remains true; the mounted consumer test
  asserts disabled remains true. Original runtime fails those assertions.
- `original-red-editable.log`: exit 1; 0/3 pass, 3 failures, zero
  cancelled/skipped. Only the two state tests' first assertion order changed
  before this invocation: each directly proves `editable` is incorrectly true
  while the read is held. The mounted actual-consumer failure remains.

Neither failure is reclassified as a pass or substituted for final evidence.

## Fixed verification

```sh
node --test extension/tests/settings-assist-state.test.mjs
node --test extension/tests/settings-assist-state.test.mjs extension/tests/prompt-assist-presenter.test.mjs extension/tests/ai-assist-automatic-consent.test.mjs extension/tests/settings-next-state.test.mjs
git diff --cached --check -- extension/ui/settings-assist-state.js extension/tests/settings-assist-state.test.mjs work/settings-assist-settlement-20261024/REPORT.md
```

- `focused-green.log`: exit 0, 17/17; zero failure/cancellation/skip. This
  includes all eight original cases and nine new cases.
- `related-green.log`: exit 0, 34/34; zero failure/cancellation/skip. This
  overlaps the focused 17 and is not an additional disjoint 34.
- The scoped final source/test/report whitespace check above exits 0. A full
  staged whitespace check also inspected the newly added raw failure logs and
  reported Node's space-padded blank lines in those two logs; the raw evidence
  bytes are retained unchanged rather than relabeled or silently normalized.
- Independent read-only review found no blocking issue at the exact runtime
  and test hashes above. The reviewer did not run another test suite.

Coverage includes both independent permissions; no actionable stale emission;
rejected second configure with no extra write; several coalesced notifications;
a second held authority read; synchronous observer refresh/configure reentry;
rejected and malformed status; explicit subsequent recovery; lost-ACK failure
feedback; existing no-notification ACK/CAS/default behavior; and original epoch
rejection of stale reads.

The new mounted test invokes the real trusted Settings switch/confirmation
listeners with the existing synthetic PresentationNode fixture, then delivers
the real storage/runtime event types. Both actual control nodes remain disabled
through settlement. A synthetic unsent draft, selection and focus are unchanged.
Detaching/reusing the same persistent host does not rebuild its owner or replay
the write. This is synthetic persistent-host detach/reuse evidence, not a DOM
layout, native browser, page teardown, disposal or user-data test. Neither this
state owner nor its existing mounted consumer exposes a dispose API; no unused
API or unwired lifecycle claim was introduced.

## Limits retained

Browser/native, Full, 129/100k/scale, provider, installation and deployment work
was not run. No public GitHub write, evidence upload, push, merge, dependency
installation, workflow edit or new authority occurred. Broad acceptance and
other programme gaps remain separate. Package/version files are unchanged.

## Log SHA-256

```text
4a6e757de3cbdc791377deec0eacc9e755b67471d4ef4947a8c87e09b902a256  original-red.log
bffde32af8c518d9208f706cbebcb41965bd15d7c0704a818d44e48b1184f8c1  original-red-editable.log
10b8473889f0076f2539a6a2b132d53ee764860cd978bcd9ce019d5a27a75ebd  focused-green.log
2dd7c755623d00dc64a2c1388fc86a8c28e96db729d60dd0914cb95f780efb45  related-green.log
```
