# Working conflict retention candidate

## Identity and authorized scope

- Source commit: 36c193cc4e8372eaa8ffd61e31f859bd20921d08.
- Tree: 82a140480c921d3a8313aeb6528119108597b327.
- Base: 954943c4df255404dd8e488f8c038d724f45f0c6.
- Branch: codex/dot-cloud-working-retention-20261024.
- Original four-file implementation lock covered Core, original Working receiver, new retention owner, and its owning test. A subsequent narrow authorization added only the declaration-owner deny-only JournalRestoreFence identity assertion in prompt-journal.js. No fence behavior, shared IDB/recovery writer, generation compiler, Human authority, or workflow changes.
- The exact five authoritative paths and SHA256/git-blob identities are in manifest-36c193cc.json. candidate-36c193cc.patch is the exact binary-capable base-to-candidate diff. Candidate worktree was clean at freeze and independent final review.

## Implemented behavior

The original InputWorkingCommitReceiver.retainConflict consumes one complete incoming group through a private Working-only native capability and Core.retainWorkingConflict. readConflict requalifies a native retained graph without manufacturing a canonical view. The profile requires an existing canonical incumbent, complete common ancestry, exactly two incomparable Input heads, complete descriptor/companion/parent vectors, original active and unreferenced Source closure, current consent/control/restore epoch, and ordinary unprotected library binding.

Only original protocol revision/entityRevision/head/receipt/sequence/frontier/generation rows may change. Canonical bodies, local history allocation/mappings, derived indexes, outbox, invalidations and negative facts remain byte-for-byte unchanged. Same-device incoming retention, same-Source purge/redaction, third heads, missing groups/ancestors, selected/protected/checkpoint generations and cold neutral intake refuse. Sorting is representation only, never winner selection. Coalesced history variants and legitimate new-history single heads remain in complete protocol branches.

Retained sibling receipts cannot become ordinary applied/duplicate acknowledgements or finish inbox claims. Original incumbent and its applied ancestors still have legitimate duplicate ACKs. Core generic Working intake remains guarded. The existing 954 restore projection/release/actual-invalidation additions are preserved unchanged.

One original ordinary work ticket spans parsing, qualification, native reads, writes, final physical-cut count/point fences and original transaction settlement: 4096 references, 2 MiB, 30 seconds, with original 128-operation closure bound. No new heap-budget claim or expanded limit. Genuine original native transaction identity/completion is mandatory; Human retention authority is not borrowed. A late cancellation after confirmed original native commit is not reported as rollback.

## Evidence and retained failures

- Author initial owning test: 10/10, 1192.494947 ms, zero failures/skips/cancellations/todo. This is historical pre-final evidence.
- Author exact final owning command: node --test extension/tests/browser-native-sync-working-conflict-retention.test.mjs. Result: 12/12, 1587.507975 ms, zero failures/skips/cancellations/todo.
- Author results above are tool-output-only. No original TAP log was retained. This report is a summary, not a reconstructed execution log.
- Independent early existing-file check observed an import-cycle failure: working-application-lifetime.test.mjs could not import because JournalRestoreFence was accessed before initialization. The remaining 52 cases were reported passing. This remains a real historical failure, not reclassified as pass.
- The correction captures fence method identity in the original declaration-owner module after class declaration; no unsafe first-use method snapshot. Subsequent independent four-file Working/lifetime run passed 68/68; three Prompt files passed 57/57.
- Independent exact final combined eight-file run on the frozen five hashes: 137/137, 5012.041206 ms, zero failures/skips/cancellations/todo. Five node --check commands and base diff --check also passed; worktree clean before/after. No remaining blocking code findings were reported. Exact reviewer command/log availability is recorded separately when received.
- Review found and corrected private application-record leakage, mutable receiver binding, receiver-specific journal/fence replacement, mutable Core namespace-map identity, missing historical entityRevision verification, applied-incumbent ACK handling, selected/read-only scope, original native schema getter use, original control/restore epoch alignment, and same-device allowed-write-set mismatch. These were static review findings, not successful native exploit evidence.

## Acceptance boundary

Native outcomes: NOT_RUN. No browser launch was attempted. Node coverage proves pure graph qualification, non-native refusal, owner identity guards, and receipt/inbox classification against deliberately unqualified synthetic protocol cuts. It does not prove a successful native retained-conflict commit, cold native reopen, real native rollback, Source/release equivalence, production deployment, installation, or whole-programme completion.

A separate preparation-only authorization covers two new native test files, with no shared harness changes and no browser launch. Those files are a later, separate artifact, not part of this candidate patch or the 137-case evidence. Production source remains frozen at 36c193cc.

## Exact retained independent final log

The reviewer retained its original final log at /tmp/paia-working-retention-review-final-36c193c.tap. That file is copied unchanged as reviewer-final-36c193cc.tap; this is not an author log or reconstructed output.

Exact independent command:

    node --test extension/tests/browser-native-sync-working-conflict-retention.test.mjs extension/tests/browser-native-sync-input-working-receive.test.mjs extension/tests/browser-native-sync-input-working-inbox.test.mjs extension/tests/browser-native-sync-input-working.test.mjs extension/tests/working-application-lifetime.test.mjs extension/tests/browser-native-sync-prompt-conflict-owner.test.mjs extension/tests/manual-prompt-bound-conflict.test.mjs extension/tests/manual-prompt-conflict-consumer.test.mjs
