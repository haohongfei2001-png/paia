# Independent ContextConnectionsView request-ordering review

## Scope and decision

The final production source `3b00df7adcb16a8105a053cc7d1810447cac0e197d5bcebae4fae71e322ca46a` has no remaining blocking finding in the reviewed same-view request/lifecycle scope. All final author test additions have been reviewed and independently run.

Frozen author head: `70499a6fd75cf2c2c146b149906877aa30833a3d`, tree `44b3194c223c7e7660d137ea13fbed8b0af333ed`. Its parent production/test commit is `f495245ede9518e5085f316654c127fa6385ea7b`; the successor only adds the report and bounded evidence archive. The final report SHA-256 is `ca1fe5a8ec0c42a9dedc26894b6c55efaa6137c5a8a543075764632b6675e3c9`, and archive SHA-256 is `85631da6729eefca86ed76a72e9a14ff21a8c26e4a601f78053a6b490711f3a7`. Archive names were inspected: it preserves the author and independent synthetic evidence, including failures. Final delta is exactly four paths (view, owning tests, report, evidence archive); the extra archive path was explicitly surfaced to the coordinator/integrator instead of silently describing this as the earlier three-path plan.

This is a read-only production review with reviewer-owned synthetic Node tests. No production file was edited by this reviewer. It is not native/browser, live transport/provider, visual, Full, installation, deployment, account or whole-product acceptance.

Accepted base: `98761c8c627ee66445c20dee452959d644fcd634`.
Author worktree: `/workspace/scratch/ff1c41bf9b29/paia-cloud-dev-20261024/context-connection-status-ordering-20261024`.
The separate root repository HEAD was read as `2f9250fe817dd9eebc0fc1373c05d01dcd7a0ed6`; the reviewer did not modify it or its existing work.

## Contract and original defect

The current `extension/docs/consumer-product-v1/AI_CONTEXT_CARDS_V2_PLAN.md` preserves CTX4-06 truthful connection/pause/revoke/reconnect behavior and the prior non-conflicting contracts. The retained PRE_REFINEMENT section 1.5 requires distinguishing actual connection availability, pause, revocation and unconfirmed state, preserving confirmed authority rather than optimistically claiming success. The retained PRE_UI CTX4-06 section prohibits treating mock connections as real-client acceptance. The persistent-authorization checkpoint requires durable acknowledgement before claiming restriction success.

On exact base source SHA-256 `6d7cb03705376b416c0b31b7f478e7e0002e88cdd19cb9ee8fe2d5aab438a868`, an earlier held STATUS returns connected revision 2 after the original CHANGE revoke and its own STATUS have already confirmed revoked revision 3. The earlier read regresses the view to revision 2 and revives stale row controls. The independent R1 proves exactly one CHANGE with expectedRevision 2 and exactly two STATUS calls. This is presentation/request ordering: the original backend's exact revision CAS, restriction-before-persistence behavior, read authority and durable confirmation remain protective and untouched.

The initial 16-case independent exploratory run was 2 pass / 14 fail; its broader failures include separately identified permission-await lifecycle cases. Those counts are not an author baseline suite result. The expanded 22-case baseline was 7 pass / 15 fail and also preserves positive unchanged-behavior controls.

## Review findings and correction history

1. The minimal STATUS read generation fence resolves older read success and failure after a newer parent update, newer STATUS, action admission, or close. Registry revision alone is insufficient because availability and connection presentation can change without incrementing it. The source also avoids STATUS dispatch from an inactive view.
2. Separately approved pairing lifecycle correction captures the original PAIR/REPAIR route, expectedRevision, port and policy before permission await. It requires the original live/current basis before dispatch. Parent revision/route/policy changes and close do not retarget or issue a mutation after the await. Duplicate gestures still acquire only one prompt and mutation. This does not add or change a permission request or grant.
3. A transient blanket action-update fence introduced a regression: the original backend calls its notification before returning the one-time credential, so an own-action parent notification or harmless baseline snapshot could hide the valid credential forever. Independent R21/R22 caught both failures. The attempted source `10f0da8fb478e5f4c29168c84d38c33fb698cddc354ab0533f33ef991557e46f` and its failure logs are retained, not relabeled passed.
4. The refined source checks actual result revision/id against observed ready/available status when the view basis changed. Same-action matching or genuinely newer result credentials remain visible; newer revocation, restoration or uncertain status cannot be covered by an obsolete credential. Accepted STATUS data and parent updates both participate. Noncredential success retains the original authoritative STATUS readback, and a null result means only the explicitly abandoned pre-dispatch pairing continuation. Current failure feedback remains truthful without synthesizing pause/revoke success.
5. Close disposes display state, prevents late STATUS and action effects, and leaves a replacement view using the same host untouched. Credentials are not copied by these flows. No replay, new mutator, extra scope grant or backend writer is introduced.

The reviewer also had one cleanup-hook ordering error in R19 while adding a replacement-view positive control: the fixture removed global document before the separate cleanup ran. The original failed log and test version are retained. Closing the replacement inside the test's finally block fixes only that fixture; the frozen transient production source still fails exactly the two real credential-regression cases.

## Verified results on refined source

- Independent adversarial suite: 22/22 pass, no skip/cancel/todo, 121.656224 ms.
- Full owning UI test file at that checkpoint: 37/37 pass, no skip/cancel/todo, 139.507494 ms.
- Source/test SHA-256 recorded immediately before and after these runs matched; test source was `ceadf67f2a2a98e90f52d033198589904dce0ed75e285e4ca42621043fa48949`.
- Final complete owning UI test file independently rerun: 49/49 pass, no skip/cancel/todo, 163.018548 ms. Final test SHA-256: `a9ed0daa53d7ad9783fe526d31e639a3ed15afd4830ebde935d1ca244d027cdf`. Production source is unchanged from the independently tested 22/22 and 37/37 checkpoint.
- Author's final four-file synthetic scoped run was inspected, not independently rerun: 174/174 pass in 6121.113534 ms, no skip/cancel/todo. Files: `context-connections-ui.test.mjs`, `context-cards-local-ui.test.mjs`, `context-connection-policy.test.mjs`, `context-connections-quiescence.test.mjs`. Author log `work/context-connection-status-ordering-20261024/final-scoped.log` SHA-256: `e93c14b1042fa28e4ed1146d32524bc53ab051f45bf8373ddc65cddcebb5c9ab`.
- `git diff --check` passed.
- Production diff scope inspected: only `extension/ui/context-connections-view.js`; the author also owns its test file and receipt. `context-cards.js`, backend transport/witness/authority, permissions and startup were not modified in this worktree.
- Runtime: Node v24.19.0, synthetic PresentationNode DOM and synthetic runtime/permission/clipboard responses only. No native host or real browser was started, no permission was requested from a real browser, and no network/provider/account/service was used.

## Evidence identities

All following artifacts are in this review directory and contain only synthetic test data:

- `baseline-context-connections-view.js`: `6d7cb03705376b416c0b31b7f478e7e0002e88cdd19cb9ee8fe2d5aab438a868`.
- `independent-ordering-v1.test.mjs`: `ebdc0b597ddae9d85a7076521e29fe787cab1ac259fd0cba2615109dd38eddf1`.
- `baseline-review.log`: `abd2519ef7fef0645892bfe5dfcbf810a4b73ade3baec00b51360fcf6d60de35`.
- `intermediate-review.log`: `faed38f09de56f9ec80172b502ce53b4090cce67bffb4f4c2582392838868de0` (STATUS-only source, 11 pass / 5 fail across the initial broader suite).
- `action-fence-view.js`: `10f0da8fb478e5f4c29168c84d38c33fb698cddc354ab0533f33ef991557e46f`.
- `action-fence-review.log`: `6c9468bfa3051925d54d0b225ea608d418077aad4bcaeacf32b4629a682d919f` (19 pass / 3 fail including reviewer cleanup error).
- `action-fence-cleanup-corrected-review.log`: `96ee7d98c8268e232cee9ef3fe392b097740b2541c8741705553be7676732e79` (20 pass / 2 actual credential-regression failures).
- `expanded-baseline-review.log`: `a9d3c32d3c246072a30bba26341728e0d7bea5443613301d52b7838343e7dc4e`.
- Final independent `independent-ordering.test.mjs`: `b28d830ab6101e300ed839dc8c2aff105ac9025274cc8419a3ce707cccdf4e08`.
- `refined-independent-review.log`: `87aea10219bc129d2140eb0780a9edbab880fbab250f9c22af956bd144634331`.
- `refined-owning-review.log`: `9928a263d3d6725fd77a0c590c44fa838072ad11f4487ea5f04fb6aa1e059383`.
- `final-owning-review.log`: `ec4fa0a75d61edf1d6055a7a86ca2e7312e3d8a9c4e1892fbbfd0007f3b7b153`.

The author separately preserves the first original-button legacy-row reproduction, its 13 pass / 9 fail RED owning run, its own fixture cleanup attempt, the pairing RED and attempted blanket-fence RED. These are distinct evidence sets, not cumulative independent test totals.

## Explicit limits

This review establishes ordering among this view's own STATUS requests, admitted actions, accepted parent updates and close events, plus the approved pre-dispatch pairing continuation. It does not certify freshness of data supplied by a different owner, real client behavior, native permission UI, transport quiescence, storage durability under real failures, screen-reader/visual behavior, complete integration or broad acceptance. Existing backend authority and all later required acceptance boundaries remain in force.
