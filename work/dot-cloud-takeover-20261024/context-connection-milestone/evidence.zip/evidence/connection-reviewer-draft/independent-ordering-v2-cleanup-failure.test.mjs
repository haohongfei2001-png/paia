import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';

const root=process.env.REVIEW_ROOT||'/workspace/scratch/ff1c41bf9b29/paia-cloud-dev-20261024/settings-authority-integration-20261024/extension';
const sourcePath=process.env.REVIEW_VIEW||root+'/ui/context-connections-view.js';
const source=await readFile(sourcePath,'utf8');
console.log(JSON.stringify({sourcePath,sha256:createHash('sha256').update(source).digest('hex'),qualification:'synthetic Node DOM only, not native/browser/provider acceptance'}));
const executable=source.replace("'./common.js'",JSON.stringify(pathToFileURL(root+'/ui/common.js').href));
const {ContextConnectionsView}=await import('data:text/javascript;base64,'+Buffer.from(executable).toString('base64'));
const {PresentationNode}=await import(pathToFileURL(root+'/tests/harness/presentation-dom.mjs').href);
class Node extends PresentationNode{
 querySelectorAll(selector){const all=this.children.flatMap(n=>[n,...(n.querySelectorAll?.('*')||[])]);return selector==='*'?all:all.filter(n=>selector.split(',').some(s=>s.startsWith('.')?n.classList.contains(s.slice(1)):n.tagName.toLowerCase()===s.toLowerCase()));}
 querySelector(selector){return this.querySelectorAll(selector)[0]||null;}
}
const row={id:'synthetic-connection',state:'connected',target:'chatgpt',principalMode:'paired-local-profile'};
const status=(revision=2,state='connected',extra={})=>({available:true,reason:'ready',revision,connections:[{...row,state}],connectedCount:state==='connected'?1:0,externalAllowed:false,...extra});
const tick=()=>new Promise(r=>setImmediate(r));
const held=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});return {promise,resolve,reject};};
const ok=data=>({ok:true,data});
function fixture(t,initial=status()){
 const previous=new Map(['document','chrome','navigator'].map(k=>[k,Object.getOwnPropertyDescriptor(globalThis,k)]));
 const calls=[],permissions=[],copies=[];let receive=async()=>ok(initial);
 globalThis.document={documentElement:{lang:'en'},createElement:tag=>new Node(tag)};
 globalThis.chrome={permissions:{request:async request=>{permissions.push(request);return true;}},runtime:{sendMessage:request=>{calls.push(structuredClone(request));return receive(request);}}};
 Object.defineProperty(globalThis,'navigator',{configurable:true,value:{clipboard:{writeText:async value=>copies.push(value)}}});
 const host=new Node('section'),view=new ContextConnectionsView({host,status:structuredClone(initial)});
 t.after(()=>{view.close();for(const [key,value]of previous)if(value)Object.defineProperty(globalThis,key,value);else delete globalThis[key];});
 return {host,view,calls,permissions,copies,receive:fn=>receive=fn};
}

test('R1 first reproduction: held old STATUS cannot undo CHANGE revoke plus confirmed STATUS',async t=>{
 const f=fixture(t),old=held();let reads=0;
 f.receive(request=>request.type==='PAIA_CONTEXT_CONNECTIONS_STATUS'?(++reads===1?old.promise:Promise.resolve(ok(status(3,'revoked')))):Promise.resolve(ok({changed:true})));
 const pending=f.view.refresh();await tick();await f.view.change(row,'revoke');
 assert.equal(f.view.status.revision,3);assert.equal(f.view.status.connections[0].state,'revoked');
 old.resolve(ok(status(2)));await pending;
 assert.deepEqual(f.calls,[{type:'PAIA_CONTEXT_CONNECTIONS_STATUS'},{type:'PAIA_CONTEXT_CONNECTIONS_CHANGE',options:{id:row.id,action:'revoke',expectedRevision:2}},{type:'PAIA_CONTEXT_CONNECTIONS_STATUS'}]);
 assert.equal(f.view.status.revision,3,'old connected revision 2 must not replace confirmed revoked revision 3');
 assert.equal(f.view.status.connections[0].state,'revoked');assert.doesNotMatch(f.host.textContent,/Revoke connection|Pause/);
});
test('R2 old STATUS success cannot replace newer parent status, even with same registry revision',async t=>{
 const f=fixture(t),old=held();f.receive(()=>old.promise);const pending=f.view.refresh();
 f.view.update(status(2,'disconnected',{available:false,reason:'qualification_required'}));old.resolve(ok(status(2)));await pending;
 assert.equal(f.view.status.connections[0].state,'disconnected');assert.equal(f.view.status.available,false);
 assert.match(f.host.textContent,/External connections are unavailable/);assert.equal(f.calls.length,1);
});
test('R3 old STATUS failure cannot add stale error over newer parent state',async t=>{
 const f=fixture(t),old=held();f.receive(()=>old.promise);const pending=f.view.refresh();
 f.view.update(status(3,'revoked'));old.reject(new Error('synthetic old failure'));await pending;
 assert.equal(f.view.feedback.textContent,'');assert.equal(f.view.status.revision,3);assert.equal(f.calls.length,1);
});
test('R4 duplicate STATUS requests settle only the latest intent, with no mutation',async t=>{
 const f=fixture(t),first=held(),second=held();let i=0;f.receive(()=>++i===1?first.promise:second.promise);
 const a=f.view.refresh(),b=f.view.refresh();second.resolve(ok(status(3,'revoked')));await b;first.resolve(ok(status(2)));await a;
 assert.equal(f.view.status.revision,3);assert.equal(f.calls.length,2);assert.ok(f.calls.every(r=>r.type==='PAIA_CONTEXT_CONNECTIONS_STATUS'));
});
test('R5 obsolete read error cannot overwrite current successful read feedback',async t=>{
 const f=fixture(t),first=held(),second=held();let i=0;f.receive(()=>++i===1?first.promise:second.promise);
 const a=f.view.refresh(),b=f.view.refresh();second.resolve(ok(status(3,'revoked')));await b;first.reject(new Error('synthetic stale failure'));await a;
 assert.equal(f.view.feedback.textContent,'');assert.equal(f.view.status.revision,3);
});
test('R6 latest read failure remains truthful and does not admit older pending success',async t=>{
 const f=fixture(t),first=held(),second=held();let i=0;f.receive(()=>++i===1?first.promise:second.promise);
 const a=f.view.refresh(),b=f.view.refresh();second.reject(new Error('synthetic current failure'));await b;
 assert.match(f.view.feedback.textContent,/Could not read connection status/);first.resolve(ok(status(1,'paused')));await a;
 assert.equal(f.view.status.revision,2);assert.match(f.view.feedback.textContent,/Could not read connection status/);
});
test('R7 action admission invalidates older pending read and retains one mutator',async t=>{
 const f=fixture(t),read=held(),change=held();let reads=0;
 f.receive(request=>request.type==='PAIA_CONTEXT_CONNECTIONS_CHANGE'?change.promise:++reads===1?read.promise:Promise.resolve(ok(status(3,'revoked'))));
 const old=f.view.refresh(),action=f.view.change(row,'revoke');await f.view.change(row,'pause');
 read.resolve(ok(status(1,'paused')));await old;assert.equal(f.view.status.revision,2);assert.equal(f.view.busy,true);
 assert.ok(f.host.querySelectorAll('button,input').every(n=>n.disabled));change.resolve(ok({changed:true}));await action;
 assert.equal(f.view.status.revision,3);assert.equal(f.calls.filter(r=>r.type==='PAIA_CONTEXT_CONNECTIONS_CHANGE').length,1);assert.deepEqual(f.permissions,[]);
});
test('R8 parent update supersedes pending action failure without obsolete feedback',async t=>{
 const f=fixture(t),change=held();f.receive(()=>change.promise);const pending=f.view.change(row,'revoke');
 f.view.update(status(3,'revoked'));change.reject(Object.assign(new Error('synthetic old failure'),{code:'STALE_BASE'}));await pending;
 assert.equal(f.view.status.revision,3);assert.equal(f.view.feedback.textContent,'');assert.equal(f.view.busy,false);assert.equal(f.calls.length,1);
});
test('R9 parent revocation suppresses late reconnect credential and avoids extra STATUS',async t=>{
 const f=fixture(t),change=held();f.receive(()=>change.promise);const pending=f.view.change(row,'reconnect');
 f.view.update(status(4,'revoked'));change.resolve(ok({id:row.id,revision:3,state:'enabled',credential:'SYNTHETIC obsolete credential'}));await pending;
 assert.equal(f.view.secret,null);assert.equal(f.view.status.revision,4);assert.match(f.host.textContent,/Revoked/);assert.equal(f.calls.length,1);assert.deepEqual(f.copies,[]);
});
test('R10 close makes held read success inert and blocks new read dispatch',async t=>{
 const f=fixture(t),read=held();f.receive(()=>read.promise);const pending=f.view.refresh();f.view.close();read.resolve(ok(status(3,'revoked')));await pending;
 await f.view.refresh();f.view.update(status(4,'paused'));assert.equal(f.calls.length,1);assert.equal(f.view.status.revision,2);assert.equal(f.host.children.length,0);
});
test('R11 close makes held read failure inert even to detached feedback',async t=>{
 const f=fixture(t),read=held();f.receive(()=>read.promise);const pending=f.view.refresh(),feedback=f.view.feedback;f.view.close();read.reject(new Error('synthetic after close'));await pending;
 assert.equal(feedback.textContent,'');assert.equal(f.host.children.length,0);assert.equal(f.calls.length,1);
});
test('R12 next explicit mutation uses newer accepted revision and exact original route',async t=>{
 const f=fixture(t);f.view.update(status(11,'paused'));f.receive(request=>Promise.resolve(ok(request.type==='PAIA_CONTEXT_CONNECTIONS_STATUS'?status(12,'revoked'):{changed:true})));await f.view.change(row,'revoke');
 assert.deepEqual(f.calls,[{type:'PAIA_CONTEXT_CONNECTIONS_CHANGE',options:{id:row.id,action:'revoke',expectedRevision:11}},{type:'PAIA_CONTEXT_CONNECTIONS_STATUS'}]);assert.deepEqual(f.permissions,[]);
});
test('R13 current action failure retains truthful unconfirmed wording and current CAS',async t=>{
 const f=fixture(t);f.receive(async()=>{throw new Error('synthetic write failure');});await f.view.change(row,'revoke');
 assert.match(f.view.feedback.textContent,/not durably confirmed/);assert.match(f.view.feedback.textContent,/does not confirm a pause or revocation/);assert.equal(f.view.status.connections[0].state,'connected');assert.equal(f.calls.length,1);
});
test('R14 pending permission cannot retarget pairing to newer parent revision or repair route',async t=>{
 const f=fixture(t),permission=held();chrome.permissions.request=request=>{f.permissions.push(request);return permission.promise;};f.view.ack.checked=true;
 const pending=f.view.pair();f.view.update(status(8,'revoked',{reason:'store_changed'}));permission.resolve(true);await pending;
 assert.equal(f.calls.length,0,'superseded permission continuation must not mutate a newer status basis');assert.equal(f.permissions.length,1);assert.equal(f.view.status.revision,8);
});
test('R15 close during permission wait prevents mutation after disposal',async t=>{
 const f=fixture(t),permission=held();chrome.permissions.request=request=>{f.permissions.push(request);return permission.promise;};f.view.ack.checked=true;
 const pending=f.view.pair();f.view.close();permission.resolve(true);await pending;assert.equal(f.calls.length,0);assert.equal(f.host.children.length,0);assert.equal(f.view.secret,null);
});
test('R16 closed view cannot acquire permission or dispatch pairing',async t=>{
 const f=fixture(t);f.view.ack.checked=true;f.view.close();await f.view.pair();assert.deepEqual(f.permissions,[]);assert.deepEqual(f.calls,[]);
});
test('R17 current pairing retains original route, revision, port, policy and one prompt/mutation',async t=>{
 const f=fixture(t,status(6,'paused',{reason:'store_changed',authorizationPolicy:{id:'synthetic-policy',authorizationLifetimeMs:86400000}})),permission=held();
 chrome.permissions.request=request=>{f.permissions.push(request);return permission.promise;};f.receive(async()=>ok({credential:'SYNTHETIC current credential',persistent:true,authorizationExpiresAt:1700000000000}));
 f.view.ack.checked=true;f.view.port.value='49321';const pending=f.view.pair();await f.view.pair();assert.equal(f.permissions.length,1);assert.equal(f.calls.length,0);
 permission.resolve(true);await pending;
 assert.deepEqual(f.calls,[{type:'PAIA_CONTEXT_CONNECTIONS_REPAIR',options:{expectedRevision:6,port:49321,authorizationPolicyId:'synthetic-policy'}}]);
 assert.equal(f.view.secret,'SYNTHETIC current credential');assert.equal(f.view.secretInput.type,'password');assert.deepEqual(f.copies,[]);
});
test('R18 parent snapshot during action readback outranks that pending readback',async t=>{
 const f=fixture(t),readback=held();f.receive(request=>request.type==='PAIA_CONTEXT_CONNECTIONS_CHANGE'?Promise.resolve(ok({changed:true})):readback.promise);
 const pending=f.view.change(row,'pause');await tick();assert.equal(f.calls.length,2);f.view.update(status(4,'revoked'));readback.resolve(ok(status(3,'paused')));await pending;
 assert.equal(f.view.status.revision,4);assert.equal(f.view.status.connections[0].state,'revoked');assert.equal(f.view.busy,false);assert.equal(f.calls.length,2);
});
test('R19 close of a pending action cannot alter replacement view in the same host',async t=>{
 const f=fixture(t),change=held();f.receive(()=>change.promise);const pending=f.view.change(row,'reconnect');f.view.close();
 const replacement=new ContextConnectionsView({host:f.host,status:status(9,'revoked')});t.after(()=>replacement.close());const before=f.host.textContent;
 change.resolve(ok({credential:'SYNTHETIC closed action credential'}));await pending;
 assert.equal(f.host.textContent,before);assert.equal(replacement.status.revision,9);assert.equal(f.view.secret,null);assert.equal(f.calls.length,1);
});
test('R20 parent update and repeated refresh never dispatch a second mutation',async t=>{
 const f=fixture(t),change=held();let reads=0;f.receive(request=>request.type==='PAIA_CONTEXT_CONNECTIONS_CHANGE'?change.promise:Promise.resolve(ok(status(3,'revoked'))));
 const pending=f.view.change(row,'revoke');f.view.update(status(3,'revoked'));await f.view.refresh();await f.view.change(row,'pause');change.resolve(ok({changed:true}));await pending;
 assert.equal(f.calls.filter(r=>r.type==='PAIA_CONTEXT_CONNECTIONS_CHANGE').length,1);assert.equal(f.view.status.revision,3);assert.deepEqual(f.permissions,[]);
});
test('R21 same-action parent notification must not discard a valid one-time credential',async t=>{
 const f=fixture(t),change=held();f.receive(()=>change.promise);const pending=f.view.change(row,'reconnect');
 f.view.update(status(3,'connected'));change.resolve(ok({id:row.id,revision:3,state:'enabled',credential:'SYNTHETIC current reconnect credential'}));await pending;
 assert.equal(f.view.secret,'SYNTHETIC current reconnect credential');assert.equal(f.view.status.revision,3);assert.equal(f.calls.length,1);assert.deepEqual(f.copies,[]);
});
test('R22 unchanged baseline parent snapshot cannot discard a newer durable credential result',async t=>{
 const f=fixture(t),change=held();f.receive(()=>change.promise);const pending=f.view.change(row,'reconnect');
 f.view.update(status(2,'connected'));change.resolve(ok({id:row.id,revision:3,state:'enabled',credential:'SYNTHETIC newer reconnect credential'}));await pending;
 assert.equal(f.view.secret,'SYNTHETIC newer reconnect credential');assert.equal(f.calls.length,1);assert.deepEqual(f.copies,[]);
});
