# Independent review: Context interrupted-delete composition

## Verdict

No blocking finding in the bounded pre-delete-admission fix. The exact source candidate is `dc140d5d37dedc874ecb3b00e753fc71214bcf31`, tree `d67e950c4f966ede06341350d9501c92a28d188b`, based on accepted `98761c8c627ee66445c20dee452959d644fcd634`.

This review covers synthetic actual-controller behavior, not native browser/IME/layout, real accounts, providers, installation, release, Full, protected 129-file group, original C or 100k qualification. Production files were read only by this reviewer. Reviewer-owned controls and evidence are outside the production worktree.

## Original contract and defect

- `extension/docs/consumer-product-v1/AI_CONTEXT_CARDS_V2_PLAN.md` lines 34, 43–45 and 53 preserve CTX4-02 inline autosave, undo, IME, failed drafts, delete/restore, editor selection, concurrency and leave protection.
- Its incorporated `AI_CONTEXT_CARDS_V2_PLAN_PRE_UI_2026-10-13.md` CTX4-02 lines 141–147 explicitly requires IME non-submission, concurrent saving, failure and retry.
- Actual `PlainTextSurface` suppresses its input callback while composing. Therefore an unfinished composition can change the visible field while `ContextItemEditor.local` still equals its saved body and `dirty()` remains false.
- Baseline `ContextCardsPage.remove()` checked target composition only before awaiting other editors. On resumption it could delete and dispose the target despite its newer unfinished composition.

## Independent first reproduction

`first-baseline-repro.log` is the first executed independent regression against exact accepted source. It failed 0/1 at the unchanged expected-zero-delete assertion, observing:

- one durable delete request;
- target removed from the live editor map, disconnected and disposed;
- target absent from the actual Context service snapshot;
- target composition still active.

The test invokes the actual Context page/editor controller, actual PlainTextSurface listeners, actual ContextCardsService and RecoveryDraftStore with fake IndexedDB and a synthetic presentation DOM. This is not native IME evidence.

## Final code review

The fix adds only original-owner checks in `context-cards.js` remove(): active state, captured open generation and card, same editor identity and non-disposed state. It revalidates these plus busy/composition after other-editor flush, after target pending-save resolution and immediately before delete admission. Fresh draft deletion revalidates after asynchronous draft clearing. No new navigation lock, writer, persistence schema, permission or cleanup owner is introduced.

The final dirty check deliberately preserves the original explicit-delete behavior for an empty saved editor. Nonempty dirty text still must successfully save first, and undo restores that last saved body. Fresh empty deletion remains a no-durable-delete operation. The prototype-only lifecycle fixture receives actual active/card/generation facts; its empty-delete assertions remain unchanged.

Post-dispatch delete ACK/lifecycle behavior is unchanged and outside the bounded interrupted-preflight claim. Whole-function safety or whole CTX4 completion is not certified here.

## Independent final execution

1. `repro.test.mjs` plus `matrix-v3.test.mjs`: **13/13 PASS**, zero fail/cancel/skip/todo, 883.181661 ms, on final runtime hash below.
2. Five complete existing owning files: **134/134 PASS**, zero fail/cancel/skip/todo, 3145.951973 ms:
   - context-cards-local-ui.test.mjs
   - context-navigation-lifecycle.test.mjs
   - context-draft-discard.test.mjs
   - context-item-receive-revision.test.mjs
   - editor-primitives.test.mjs
3. `node --check extension/ui/context-cards.js` and `git diff --check`: PASS.

The 13 independent controls cover successful and rejected other-item saves, target composition during its own held save, fresh composition during actual recovery clearing, close, close/reopen, same-generation editor rebuild, overlapping delete gestures, a newly busy page, normal delete/undo, intentional dirty save/delete/undo, and fresh blank no-write deletion. Composing controls preserve exact editor identity, visible text and durable Item, and verify the composition-end draft through RecoveryDraftStore.

## Preserved predecessor attempts

- First baseline reproduction: 0/1 PASS, 1 FAIL, retained unchanged.
- `baseline-matrix.log`: first matrix attempt interrupted while waiting for a fresh empty draft clear that correctly did not occur without a token. It is not a complete run or pass.
- `baseline-matrix-v2.log`: second diagnostic attempt ended after eight completed controls, 3 PASS / 5 FAIL. Its ninth case used an object-valued identity assertion and produced no completed result; no cause is claimed for that incomplete run. It is not a complete 12-control run. The original file and log are retained.
- `fresh-diagnostic.log`: bounded diagnostic confirmed real token-bearing fresh recovery clear. This is diagnostic, not acceptance evidence.
- `matrix-v3.test.mjs` keeps the same substantive assertions, but uses boolean identity comparisons to avoid serializing cyclic editor objects. Complete baseline result: **6/12 PASS, 6 FAIL**, 930.015495 ms. Complete candidate result: **12/12 PASS**, included in final 13-case run.
- Initial candidate runtime `e4388ee61ea622d6f508c67b18b1321d625b1f6b13643ae8a769f31467d51d41`: 13/13 PASS at 959.795336 ms. Final runtime was rerun after adding intermediate target-save revalidation; no result is relabeled across byte changes.
- The reproduction's diagnostic line retains its original literal label `observed baseline` even in candidate logs. The logged observations and the selected REVIEW_ROOT identify the actual source; the label does not identify a Git revision.
- Author's original 81/87 failing owning result and initial related 253/254 result are preserved in its work receipt. I inspected the fixture-only correction and original failure; I do not relabel those failed runs.

## Exact final identities

- Source commit: `dc140d5d37dedc874ecb3b00e753fc71214bcf31`
- Source tree: `d67e950c4f966ede06341350d9501c92a28d188b`
- `extension/ui/context-cards.js` SHA256: `5563eab2ccc20ab329525cb45a2703ec302d851cf5c7e651e51f5c2942309a2b`
- `extension/tests/context-cards-local-ui.test.mjs` SHA256: `44cce336b268db1f7fdd0b20d53e44cbc4d5f362362d3cb430a3d069e838a9ce`
- `extension/tests/context-edit-lifecycle.test.mjs` SHA256: `668a1d04601716757f8857d92ce1063622dfea7b9e6cf0b8762e7660fae95e1f`
- Independent first RED log SHA256: `257d9623d86333afa97651e95d86e422a16b60179d9675c8da7be59ebd622836`
- Independent final 13-case log SHA256: `aaba0f220ece2083471f15e0ce966b6a570bea1241c975dd4cb0f597395a2e85`
- Independent five-file log SHA256: `5ad91fec09d5db5b89400d7a11c057b5aa92514490c5a5c27662151f7b76afc5`
- Final reviewer matrix SHA256: `161fab2b175df08e75adbc9753d8835bbbabf72171dd7f03a89cc4660ff562b0`

## Final evidence successor

Independently read back final author head `e2a2198e50d303974a1e53b1f550d9be1ca82df7`, tree `26ebe426c8da184f3061fd5c87e465e997dcc683`. Receipt commit `c914b42182e4e249e78bf2e6075b4fd2f6b7953c` plus its final documentation-only successor add only the owning work report and logs. `git diff dc140d5... HEAD -- extension` is empty; final runtime remains SHA256 `5563eab2ccc20ab329525cb45a2703ec302d851cf5c7e651e51f5c2942309a2b`. No rerun is attributed to the documentation-only bytes. Author report SHA256 is `69642ea3b9c58bcb8cab31d6b7b424ce5b6f69f659406031cab351e3ae42e289`.

Final worktree status is clean. Author reports preservation of an existing missing historical sparse blob during authorized own-branch receipt creation; this reviewer did not fetch, repair or mutate Git state and makes no repository-object-completeness claim.
