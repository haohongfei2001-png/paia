import {test,assert,fixture,tick,deferred,put} from './fixture.mjs';
const deletionCalls=calls=>calls.filter(x=>x.type==='PAIA_CONTEXT_CARDS_CHANGE'&&x.change.kind==='delete');
const beginComposition=(editor,text)=>{editor.field.listeners.get('compositionstart')({});editor.field.textContent=text;editor.field.listeners.get('input')({isComposing:true});};
async function change(editor,text){editor.field.textContent=text;editor.changed();editor.autosave.cancel();if(editor.recovery.running)await editor.recovery.running;}
async function heldOther(f,body){
 const {c,makePage,transport,dispatch}=f;
 await c.change(put('rules',{body:'SYNTHETIC other Rules editor'}));
 const page=makePage();await page.open('rules');await tick();
 const [target,other]=[...page.editors.values()],held=deferred(),entered=deferred();
 await change(other,'SYNTHETIC other body after edit');
 transport.dispatch=async message=>{if(message.type==='PAIA_CONTEXT_CARDS_CHANGE'&&message.change.itemId===other.id){entered.resolve();await held.promise;}return dispatch(message);};
 const deleting=page.remove(target);await entered.promise;
 try{await body({...f,page,target,other,held,deleting});}finally{held.resolve();await deleting.catch(()=>{});}
}
for(const rejected of [false,true])test(`review target composition during other save (${rejected?'rejected':'successful'}) retains exact editor and durable item`,()=>fixture(f=>heldOther(f,async({c,recovery,calls,page,target,other,held,deleting})=>{
 const text='SYNTHETIC exact unfinished IME body';beginComposition(target,text);assert.equal(target.dirty(),false);
 if(rejected)held.reject(Object.assign(Error('SYNTHETIC other save rejected'),{code:'STORAGE_FAILED'}));else held.resolve();
 await deleting;
 assert.equal(deletionCalls(calls).length,0);assert.equal(page.editors.get(target.id)===target,true);assert.equal(target.root.isConnected,true);assert.equal(target.disposed,undefined);assert.equal(target.field.innerText,text);assert.equal(target.composing,true);
 assert.equal((await c.snapshot()).items.find(x=>x.id===target.id).body,target.saved.body);
 target.field.listeners.get('compositionend')({});target.autosave.cancel();if(target.recovery.running)await target.recovery.running;
 assert.equal((await recovery.load('context_item',target.id)).operation.change.body,text);
 assert.equal(other.failed,rejected);
})));
for(const lifecycle of ['close','close-reopen','same-generation-rebuild'])test(`review obsolete deletion cannot survive ${lifecycle} during another save`,()=>fixture(f=>heldOther(f,async({c,calls,page,target,held,deleting})=>{
 let replacement;
 if(lifecycle==='close')page.close();
 else if(lifecycle==='close-reopen'){page.close();await page.open('rules');replacement=page.editors.get(target.id);}
 else{await page.refresh({rebuild:true});replacement=page.editors.get(target.id);}
 if(replacement)assert.notEqual(replacement,target);
 held.resolve();await deleting;
 assert.equal(deletionCalls(calls).length,0);assert.ok((await c.snapshot()).items.some(x=>x.id===target.id));
 if(replacement){assert.equal(page.editors.get(target.id)===replacement,true);assert.equal(replacement.disposed,undefined);assert.equal(replacement.root.isConnected,true);}
})));
test('review two overlapping deletes awaiting the same other save issue only one delete',()=>fixture(f=>heldOther(f,async({calls,page,target,held,deleting})=>{
 const duplicate=page.remove(target);await tick();held.resolve();await Promise.all([deleting,duplicate]);
 assert.equal(deletionCalls(calls).length,1);assert.equal(page.editors.has(target.id),false);assert.equal(page.journal.undo.length,1);
})));
test('review another operation taking busy while delete awaits prevents stale admission',()=>fixture(f=>heldOther(f,async({c,calls,page,target,held,deleting})=>{
 page.busy=true;held.resolve();await deleting;
 assert.equal(deletionCalls(calls).length,0);assert.equal(page.busy,true);assert.equal(page.editors.get(target.id)===target,true);assert.ok((await c.snapshot()).items.some(x=>x.id===target.id));page.busy=false;
})));
test('review target composition during its own held save blocks deletion',()=>fixture(async({c,calls,makePage,transport,dispatch})=>{
 const page=makePage();await page.open('rules');await tick();const target=[...page.editors.values()][0];
 await change(target,'SYNTHETIC saved prefix');const held=deferred(),entered=deferred();
 transport.dispatch=async message=>{if(message.type==='PAIA_CONTEXT_CARDS_CHANGE'&&message.change.kind==='put'&&message.change.itemId===target.id){entered.resolve();await held.promise;}return dispatch(message);};
 const saving=target.flush();await entered.promise;const deleting=page.remove(target);await tick();beginComposition(target,'SYNTHETIC newer composing body');held.resolve();await Promise.all([saving,deleting]);
 assert.equal(deletionCalls(calls).length,0);assert.equal(page.editors.get(target.id)===target,true);assert.equal(target.field.innerText,'SYNTHETIC newer composing body');assert.equal((await c.snapshot()).items.find(x=>x.id===target.id).body,'SYNTHETIC saved prefix');
}));
test('review fresh blank editor is retained when composition starts during clearDraft await',()=>fixture(async({calls,makePage,transport,dispatch})=>{
 const page=makePage();await page.open('rules');await tick();await page.addItem();const target=[...page.editors.values()].find(x=>x.fresh);assert.ok(target);
 await change(target,'SYNTHETIC prior fresh draft');
 const held=deferred(),entered=deferred();
 transport.dispatch=async message=>{if(message.type==='PAIA_RECOVERY_DRAFT_CLEAR'&&message.draft.ownerId===target.id){entered.resolve();await held.promise;}return dispatch(message);};
 target.field.textContent='';target.changed();target.autosave.cancel();
 const deleting=page.remove(target);await entered.promise;beginComposition(target,'SYNTHETIC fresh composition');held.resolve();await deleting;
 assert.equal(deletionCalls(calls).length,0);assert.equal(page.editors.get(target.id)===target,true);assert.equal(target.root.isConnected,true);assert.equal(target.field.innerText,'SYNTHETIC fresh composition');
}));
test('review normal saved deletion and undo remain exact',()=>fixture(async({c,calls,makePage})=>{
 const page=makePage();await page.open('rules');await tick();const target=[...page.editors.values()][0],saved=structuredClone(target.saved);
 await page.remove(target);assert.equal(deletionCalls(calls).length,1);assert.equal(page.editors.has(target.id),false);assert.equal(page.journal.undo.length,1);await page.undoDelete();
 assert.equal((await c.snapshot()).items.find(x=>x.id===target.id).body,saved.body);assert.equal(page.editors.get(target.id).saved.body,saved.body);
}));
test('review initial dirty target is durably saved before delete and undo restores that body',()=>fixture(async({c,calls,makePage})=>{
 const page=makePage();await page.open('rules');await tick();const target=[...page.editors.values()][0];await change(target,'SYNTHETIC intentional pre-delete edit');await page.remove(target);
 const writes=calls.filter(x=>x.type==='PAIA_CONTEXT_CARDS_CHANGE'&&x.change.itemId===target.id).map(x=>x.change);assert.deepEqual(writes.map(x=>x.kind),['put','delete']);assert.equal(writes[1].expectedRevision,writes[0].expectedRevision+1);
 await page.undoDelete();assert.equal((await c.snapshot()).items.find(x=>x.id===target.id).body,'SYNTHETIC intentional pre-delete edit');
}));
test('review blank unsaved fresh deletion preserves original no-write behavior',()=>fixture(async({calls,makePage})=>{
 const page=makePage();await page.open('rules');await tick();await page.addItem();const target=[...page.editors.values()].find(x=>x.fresh);await page.remove(target);assert.equal(page.editors.has(target.id),false);assert.equal(deletionCalls(calls).length,0);
}));
