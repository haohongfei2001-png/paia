import {test,assert,fixture,tick,deferred,put} from './fixture.mjs';
test('independent first reproduction: target IME begins while another actual save is held',()=>fixture(async({c,makePage,transport,dispatch,calls})=>{
 await c.change(put('rules',{body:'SYNTHETIC other Rules editor'}));
 const page=makePage();await page.open('rules');await tick();
 const [target,other]=[...page.editors.values()],held=deferred(),entered=deferred();
 other.field.textContent='SYNTHETIC saved other body';other.changed();other.autosave.cancel();
 if(other.recovery.running)await other.recovery.running;
 transport.dispatch=async message=>{if(message.type==='PAIA_CONTEXT_CARDS_CHANGE'&&message.change.itemId===other.id){entered.resolve();await held.promise;}return dispatch(message);};
 const deleting=page.remove(target);await entered.promise;
 target.field.listeners.get('compositionstart')({});target.field.textContent='SYNTHETIC IME not committed';target.field.listeners.get('input')({isComposing:true});
 assert.equal(target.composing,true);assert.equal(target.dirty(),false);
 held.resolve();await deleting;
 const deletes=calls.filter(x=>x.type==='PAIA_CONTEXT_CARDS_CHANGE'&&x.change.kind==='delete');
 console.log(JSON.stringify({label:'observed baseline',deleteCalls:deletes.length,targetMounted:page.editors.get(target.id)===target,targetConnected:target.root.isConnected,targetDisposed:target.disposed||false,targetRetainedInSnapshot:(await c.snapshot()).items.some(x=>x.id===target.id),compositionStillActive:target.composing}));
 assert.equal(deletes.length,0,'must not submit deletion after target begins composing while another save is pending');
 assert.equal(page.editors.get(target.id),target);assert.equal(target.root.isConnected,true);
}));
