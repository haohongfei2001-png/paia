import {fixture,tick,deferred} from './fixture.mjs';
await fixture(async({calls,makePage,transport,dispatch})=>{
console.log('start');const page=makePage();await page.open('rules');await tick();console.log('opened');await page.addItem();console.log('added');const target=[...page.editors.values()].find(x=>x.fresh);target.field.textContent='SYNTHETIC prior fresh draft';target.changed();target.autosave.cancel();if(target.recovery.running)await target.recovery.running;console.log('draft',target.recovery.currentToken,JSON.stringify(calls.slice(-2)));
 const held=deferred(),entered=deferred();
 transport.dispatch=async message=>{console.log('request',message.type,message.draft?.ownerId);if(message.type==='PAIA_RECOVERY_DRAFT_CLEAR'&&message.draft.ownerId===target.id){console.log('entered');entered.resolve();await held.promise;}return dispatch(message);};
 target.field.textContent='';target.changed();target.autosave.cancel();console.log('cleared local',!!target.discarding);
 const deleting=page.remove(target);await entered.promise;console.log('release');held.resolve();await deleting;console.log('done');
});
