# Independent bounded Recovery/Saved runner review

Review date: 2026-10-24. Verdict: **No remaining blocking findings for PREPARATION ONLY. Native execution is NOT_READY.**

## Reviewed identity and scope

Author checkout: `/workspace/scratch/ff1c41bf9b29/paia-cloud-dev-20261024/bounded-native-harness-prep-20261024`.

Accepted base: `98761c8c627ee66445c20dee452959d644fcd634`, tree `b3b243627bf9ff117565d27d646f126a63e6c55b`.

Exactly nine added files under `extension/tests/cloud-components/bounded-native` were reviewed. The complete frozen hashes are in `reviewed-preparation-files.sha256`, which matches the author's `work/bounded-native-harness-prep-20261024/harness-SHA256SUMS` byte-for-byte. Pre-test and post-test hash inventories are identical. No tracked production, builder, workflow, existing fixture, dependency, threshold or permission changes existed at final review. The reviewer made no edits to the author checkout, commits or remote changes.

Scope is one proposed sandbox-enabled browser launch, two sequential fresh contexts (Source, then Release), and the fixed four Recovery/Saved case IDs in each context: eight variant-cases. Native execution, build, installation, download, workflow dispatch, real launcher, old Full/native/129/100k/C/cloud lanes and production edits were not performed.

## Verified findings

- The pinned Source manifest lists exactly 474 core/background modules and five standard builder/guard files. Every listed SHA256 matched current bytes, and independently computed Git blob identities matched the accepted base. The source manifest SHA256 is `798736cc88a97530c6270c5455b59ff3bd3a0d1cd258a9deee7a418a70c64b2a`.
- All four original component body strings and names are byte-identical to the old final preparation fixture (`f7f9e0ab8334141c203f95f3b23c2097ee6d24534142799c743738ea193f46fd`). Only imports, fixed IDs/order, response construction and cleanup wrapping changed. The original precharge of 4095 remains a near-limit refusal control, not end-to-end affordability evidence.
- Static inspection found no browser import, real launcher adapter, executable lookup, process/build invocation, shell input, environment-selected module, CLI or workflow dispatch in the nine-file preparation. The page module path and case IDs are fixed internally. Route fulfillment is restricted to the pinned same-variant inventory; there is no route continue/fallback path.
- Immutable served snapshots are constructed only after pinned hashes and Release correspondence checks. Mutating input buffers afterward does not change served strings. Release-like bytes used by unit tests are explicitly synthetic contract fixtures, not generated Release evidence.
- The fake-runner contract checks single launch, explicit sandbox flag, fixed sequential contexts, stop on first failure, no launch retry, network denial, fixed case responses, page errors and cleanup failure. These are contract tests, not evidence that real Chromium enforces these settings.
- The unconditional readiness refusal and explicit `RUNNER_UNIT_ONLY_NOT_NATIVE`, `CONTRACT_PASS`, `NOT_READY` and manifest-only provenance labels prevent the reported results from being represented as native qualification. The injected launcher API is a test seam, not a security boundary against a caller supplying real code; README now states that explicitly.

## Findings corrected during review

1. **First case failure could be lost during fixture cleanup.** The original wrapper returned a body failure from `catch`, but a repository close rejection from `finally` replaced that result. Final `recovery-saved-fixture.mjs:124-134` preserves the first body error/details, attempts each known close, records all close errors, turns body success into FAIL when cleanup fails, and poisons later case entry. A pure VM test exercises only the wrapper with fake callbacks; no component body is invoked.

2. **Timed-out acquisition lacked explicit unknown ownership/cleanup evidence.** A late browser/context Promise could resolve after the runner returned without an owned handle. Independent fake-only diagnostics preserved in `late-handle-pre-fix.tap` demonstrate both old cases with zero close calls. Final `runner.mjs:88-97,144-148` records the pending acquisition as `outcome: UNKNOWN, cleanup: UNCONFIRMED`; late resolution cannot upgrade that result or start later work. This is accepted only for preparation. Late-handle cleanup and hard termination are deliberately not implemented or claimed.

The original diagnostic tests asked whether best-effort late close occurred and remain failed historical diagnostics. They are not relabelled passed: the accepted correction is explicit unknown status, covered by the final suite, rather than an implementation of late close.

## Independent checks

- `review-pure-final.tap`: **17/17 PASS**, zero failures, skips, cancellations or todos; duration 473.61334 ms. SHA256 `603a076c922cadc27a0e21a215ec68b3be87c2ae0492b2075dbd449d7c87b6e2`.
- `final-syntax.log`: all six `.mjs` files pass `node --check`, without importing the browser fixture.
- `independent-static-01.json`: accepted base/tree, all 479 listed file hashes/Git blobs, original fixture identity and all four byte-exact bodies.
- `reviewed-preparation-files.sha256`: nine-file freeze, SHA256 `d7e3f6e8dcc53727d5ffb7cee66165505f9186b31c70ef7a5815e6bda123e905`; matching post-test inventory retained separately.
- Static literal-import inspection found no missing/outside route in a 320-file closure. This regex inspection is supplementary, not a complete parser or module execution. Its initial unanchored scan produced false positives from object fields named `from`; the initial and corrected outputs are both retained.
- `git diff --exit-code` and `git diff --check` passed for tracked files. This is not a claim that the added preparation files were already committed.

The author's first two failed pure-test logs are retained, including an explicit SIGKILL in `pure-runner-02.tap`. Later successful runs do not erase them. Replacing large Buffer assertion rendering with a boolean comparison preceded success; no unique cause of the earlier termination is established by this review.

## Explicit proof limits and future gates

No native component body ran. No genuine Release was built or verified. The proposed build/native/job budgets (30/120/300 seconds) lack an outer hard supervisor. Promise races and one-second best-effort close waits do not kill a process tree or enforce resource/network limits. Separate filesystem roots, non-symlink provenance, verified executable identity, native sandbox availability, OS-level network deny, real process ownership/termination, exact frozen harness binding and fresh explicit native authorization all remain required and NOT_READY.

The Source manifest is a pinned module-serving allowlist plus builder hashes, not a full-source-tree manifest. The Release validator checks supplied inventory consistency and expected module correspondence; it cannot establish that the unchanged standard builder emitted those bytes. No source-renamed or hand-built artifact can qualify as Release. Nothing here establishes Source/Release native success, actual affordability, broader Recovery/Saved/Working/Context/local-meta acceptance, a provider result, full-product qualification, installation or deployment.
