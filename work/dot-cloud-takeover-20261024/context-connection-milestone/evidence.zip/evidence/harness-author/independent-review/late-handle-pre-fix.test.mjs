// Independent pure reviewer repro against a preserved preparation snapshot.
// No product module, browser, build, network, provider or native API executes.
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {sha256,outputFingerprint,verifyArtifactSnapshots} from './pre-fix-snapshot/artifacts.mjs';
import {exercisePreparedRunner} from './pre-fix-snapshot/runner.mjs';
import {BUDGETS} from './pre-fix-snapshot/policy.mjs';
const sourceManifestBytes=await readFile(new URL('./pre-fix-snapshot/source-manifest.json',import.meta.url));
const manifest=JSON.parse(sourceManifestBytes);
const root=new URL('../bounded-native-harness-prep-20261024/extension/',import.meta.url);
const sourceFiles=Object.fromEntries(await Promise.all(Object.keys(manifest.files).map(async p=>[p,await readFile(new URL(p,root))])));
const releaseFiles={...sourceFiles,'background/service-worker.js':Buffer.from(sourceFiles['background/service-worker.js'].toString().replace("    case 'FILTER_DIAGNOSTICS': return store.filterDiagnostics();\n",''))};
const releaseManifest={schema:1,variant:'Release',sourceCommit:manifest.sourceCommit,sourceTree:manifest.sourceTree,sourceManifestSha256:sha256(sourceManifestBytes),files:Object.fromEntries(Object.entries(releaseFiles).map(([p,b])=>[p,sha256(b)])),build:{entrypoint:'scripts/build_current_release.py',builderFiles:manifest.builderFiles,exitCode:0,guardrails:'PASS',reused:false,elapsedMs:1,sourceFingerprint:'0'.repeat(64),outputFingerprint:outputFingerprint(releaseFiles),evidenceClass:'CONTRACT_FIXTURE_NOT_A_BUILD'}};
const artifacts=verifyArtifactSnapshots({sourceManifestBytes,sourceFiles,releaseManifest,releaseFiles,fixtureBytes:await readFile(new URL('./pre-fix-snapshot/recovery-saved-fixture.mjs',import.meta.url))});
for(const kind of ['browser','context']) test('late '+kind+' handle should get best-effort close after timeout',async()=>{
 let settle,fire,closed=0;
 const clock={setTimeout(fn,ms){if(ms===BUDGETS.nativeMs)fire=fn;return fn;},clearTimeout(){}};
 const handle={async close(){closed++;}};
 const pending=()=>new Promise(resolve=>{settle=resolve;});
 const launcher=kind==='browser'?pending:async()=>({newContext:pending,async close(){}});
 const running=exercisePreparedRunner({artifacts,launcher,clock});
 while(!settle)await Promise.resolve();
 fire();
 const receipt=await running;
 assert.equal(receipt.result,'CONTRACT_FAIL');
 settle(handle);
 for(let n=0;n<20;n++)await Promise.resolve();
 assert.equal(closed,1,'late '+kind+' handle was never closed');
});
