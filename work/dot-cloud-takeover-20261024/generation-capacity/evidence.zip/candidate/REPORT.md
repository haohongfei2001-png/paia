# Protected generation namespace read reuse

## Frozen candidate

- HEAD: `382742a4de38bbfd0eb5b2bde369ca1141806981`.
- Parent: independently reviewed linked composition `954943c4df255404dd8e488f8c038d724f45f0c6`.
- Tree: `3676cb8991d04a8f5204e05d589031fe874ad507`.
- Branch/worktree: `codex/dot-cloud-generation-capacity-20261024`, `worktree-generation-capacity`, clean and frozen. No push/main/PR action.
- Only `extension/core/browser-native-sync/group-checkpoint.js` and new direct owner test `extension/tests/generation-namespace-capacity.test.mjs` changed.
- Author verification: **215/215 PASS**,17554.547813ms,15 complete small owning files, zero fail/cancel/skip/todo. Independent review found no blocking findings; its two separate protected-group/R files passed62/62, with zero failures/skips. The disjoint author/reviewer total is277/277 small cases, not a Full/native acceptance aggregate.

This removes two genuine duplicate namespace body scans only from the **original protected generation writer with its original default checkpoint**. It does not optimize generic, debug or ordinary R recovery paths. It does not establish a cause or resolution of the automatic fresh-C failure, and neither that case nor its consumed phase diagnostic was rerun.

## Exact capacity semantics and owner binding

The original generation transaction installs a private scope-keyed budget record only after its original protected repository authority has bound the same actual transaction (`authority.scope === t`) and only with the fixed default checkpoint. The actual authority reader rechecks original Store/Core/method/property identities when deferral is requested and when the actual terminal rows are consumed. An unprotected repository wrapper, custom debug callback, substituted method or generic restore cannot acquire this path.

The original `requireStorageBudget` call site remains in place. For eligible protected group-stage/group-apply only, it records the exact two namespace ranges and, for apply, an isolated copy of the actual already-validated restore preimage. `generationTerminal` consumes only the meta rows it already physically read. The original generic/debug/nonqualified scan remains byte-for-byte unchanged apart from accepting the unused preimage argument.

Static equivalence proof:

1. Both namespaces are checked with `IDBKeyRange.bound(prefix,prefix+'\\uffff',false,true)`, exactly matching original primaryRangePage's inclusive lower/exclusive upper bounds. Overlapping/equal ranges retain original multiplicity. No startsWith-only approximation or body-free byte guess is used.
2. For group-stage, the old capacity check is after all namespace writes, followed only by the original `stage.get` and terminal capture. The same real rows are encoded and summed.
3. For group-apply, after the old check the fixed default tail writes the active pointer outside both namespaces and the restore successor. The terminal restore row must exactly equal `{...originalPreimage,phase:'activated'}`. Capacity adds `bytes(originalPreimage).length`, not the final row length, so even a future shorter phase cannot erase the original rejection. Missing or changed successor fails `BNS_RESTORE_STAGE_CHANGED`.
4. The original authenticated stage rejects consumer preference groups, so this eligible path cannot enter the cross-database publishing branch. `sealSavedWorkGroupActivation` and `requireCanonicalCheckpointProof` only read and register fences. Original repository finalizers write infrastructure/delta metadata outside both namespaces.
5. The capacity ceiling stays `CORE_LIMITS.batchBytes * 2` (8MiB); complete encoded physical protocol rows still count. The tighter actual transaction work meter remains4096refs/2MiB/30s and may refuse before that storage cap. No limit is raised or reset.
6. All existing complete terminal `get` and `count` fences are retained, without partitioning, replacement or excluded namespace rows. Actual terminal reads remain metered. Private budget records are released in the transaction's original finally.

Capacity evaluation now occurs after the original head/frontier validation, rather than before it. All writes remain provisional and the eligible default callback cannot observe that ordering; malformed input can report another existing validation error before the same capacity rejection. Accepted capacity sets and original rejection/rollback are not narrowed to make a test green. No 8MiB fixture was attempted under the tighter2MiB original work bound; exact capacity-input equivalence is established by the fixed original call path and code above, not by overriding that work bound.

## Actual bounded measurements, not automatic-C measurements

The passive fake-IDB observer invokes all original methods unchanged. The measured work receipts are read only after original native transaction completion; no counter is written. Same one-Source owner fixture, on parent and candidate:

- Parent stage:3 whole-namespace cursors,222refs,145397bytes,69 terminal gets,5 terminal counts.
- Candidate stage:1 whole-namespace cursor,204refs,130119bytes,69 terminal gets,5 terminal counts.
- Parent apply:3 whole-namespace cursors,934refs,319909bytes,141 terminal gets,45 terminal counts.
- Candidate apply:1 whole-namespace cursor,878refs,285636bytes,141 terminal gets,45 terminal counts.

One required collision/empty-target namespace cursor remains. The two removed cursors are the old capacity-only scans. These are actual successful small-fixture measurements only; timings are not used to claim a speedup or explain any other failure.

## Controls and preserved failures

New direct owner controls:

- Protected default group-stage and group-apply retain original owner output, protocol generation, terminal reads and successful work receipts while removing only capacity cursors.
- Unprotected default, custom debug and generic original admission each retain the original three namespace cursors.
- Actual protected activate→prepare-publication→seal→reserve→recover succeeds.
- A physical restore successor mismatch rejects the deferred preimage substitution and rolls all tables back.
- A physical namespace insertion after terminal capture is refused by the unchanged original terminal count fence and rolls all tables back.
- The unprotected original generation's terminal reads consume the same actual cumulative R ticket. The negative uses the original restriction-only charge function to exhaust its remaining references; it is synthetic budget exhaustion, not a performance measurement.
- Protected generation plus an ordinary R work window still rejects with `GENERATION_REPOSITORY_WRITE_DENIED` at the unchanged original repository guard. Neither authority is silently rebound.

Logs:

- `01-owning-first.log`:0/9 FAIL,1330.228742ms. Test fixture errors: protected generation was given LibraryFoundationStore rather than the required original LibraryDocumentsStore; the observer also counted kind-specific pending cursors as whole namespace cursors. Fixed test setup, not production guards.
- `02-owning-fixture-fixed.log`:8/9 PASS,2540.138454ms. Attempting the unsupported protected+ordinary-R combination correctly failed `GENERATION_REPOSITORY_WRITE_DENIED`, not the test's mistaken resource-limit expectation. Preserved and split into the two truthful controls above.
- `03-owning-complete.log`:10/10 PASS,2246.462368ms.
- `04-parent-read-count-red.log`:0/2 FAIL,844.453686ms, against untouched parent954943c. Both original owners completed successfully; the new no-duplicate-read assertion correctly failed3!==1. Exact committed work/terminal measurements accompany the failures. `parent-owning-red.test.mjs` only resolves imports to the untouched parent.
- `05-final-owning-combination.log`:215/215 PASS,17554.547813ms, including the new10 controls, previous linked28, H pending-search19, lifetime16 and all selected original owners. Final new work/terminal measurements are in this log.

Exact author command:

`node --test extension/tests/generation-namespace-capacity.test.mjs extension/tests/human-source-working-cold-composition.test.mjs extension/tests/working-application-lifetime.test.mjs extension/tests/browser-native-sync-input-working-receive.test.mjs extension/tests/source-working-restored-successor.test.mjs extension/tests/browser-native-sync-human-library-group.test.mjs extension/tests/browser-native-sync-saved-mixed.test.mjs extension/tests/consumer-preference-group-restore.test.mjs extension/tests/canonical-generation-owner-restore.test.mjs extension/tests/human-source-entry-plan.test.mjs extension/tests/human-source-placement.test.mjs extension/tests/human-graph-future-read-set.test.mjs extension/tests/human-scope-search-completeness.test.mjs extension/tests/context-mutation-description.test.mjs extension/tests/context-mutation-journal.test.mjs`

Independent reviewer separately ran the complete nonoverlapping `canonical-generation-protected-group.test.mjs` and `browser-native-sync-recovery-causal-tail.test.mjs`: **62/62 PASS**, exit0,12.69s, zero fail/skip. See `06-independent-protected-r-tail.log`. No automatic/phase/native/browser/large-group tests ran.

Both changed files pass node --check; git diff --check passes. Node24.19.0/Linux/fake-IDB synthetic owner evidence only. Original native-linked/export and application selection guards remain closed. No idb/recovery/Assist/Next/selection source changes, full suite, Actions, native/browser launch, original129-group/100k replay, capraise, account, paid service, installation or deployment.

## Failures outside this package remain open

Prior linked candidate473349ba's sole authorized phase diagnostic remains0/1 FAIL at fresh-C protected activation after B activation and cold-B publication. No current C refs/bytes, unique cause or completion has been established. Old four automatic FAIL and old3454refs/2099146bytes/237ms including1994bytes over2MiB remain their original historical observations, not this candidate's metrics. The current optimization is not automatic full-case acceptance and does not authorize another phase diagnostic or budget change.

## Final independent review

The reviewer verified clean382742a4 and the protected-only original authority binding, strict namespace ranges, actual terminal rows, exact restore preimage substitution and retained original final read fences. No blocking finding remained. Evaluation is deferred within the same uncommitted protected transaction, not identical error ordering. The ordinary R path retains its original scans and cannot be combined with protected writer authority. This is no claim of ordinary R improvement or completed automatic recovery.
