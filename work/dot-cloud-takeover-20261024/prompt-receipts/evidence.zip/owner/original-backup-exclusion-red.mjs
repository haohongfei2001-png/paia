import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
assert.ok(process.env.BASELINE_REPO,'explicit frozen baseline path required');
const {validateBackupItem}=await import(pathToFileURL(resolve(process.env.BASELINE_REPO,'extension/core/backup-format.js')));
assert.throws(()=>validateBackupItem({type:'item',section:'receipts',value:{id:'prompt-insertion-runtime:v1',namespace:'prompt-insertion',result:{kind:'synthetic-local-evidence'}}}),{code:'BACKUP_INVALID'},'original generic Backup admission must exclude reserved local insertion evidence');
