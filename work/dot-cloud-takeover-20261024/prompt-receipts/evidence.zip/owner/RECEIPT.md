# Original Prompt insertion owner, scoped implementation evidence

Base: `af560f6de7a478e3c45937d628581bb87def8c0a`.
Environment: authorized cloud workspace; Node v24.19.0; synthetic fake IndexedDB and original production owners. No browser/native/Full/C/129/100k/accounts/paid/install/deploy/external write.

## Owned manifest

- `extension/background/prompt-insertion-receipts.js` (new original Store-bound owner)
- `extension/core/backup-format.js` (ten-line reserved local receipt exclusion, separately approved extra lock)
- `extension/tests/prompt-insertion-receipts.test.mjs` (new direct owner controls)
- `extension/docs/consumer-product-v1/implementation/prompt/PROSPECTIVE-INSERTION-RECEIPTS-2026-10-24.md`
- This work directory (synthetic logs, exact original red executable, receipt)

The coordinated producer files were copied into this worktree only as test dependencies; they are not owned or included in this commit. The actual receiver/composer and runtime/UI/worker commits must be integrated separately. Original versions without the private producer brand deliberately cannot register with the new owner.

## Original red

```
BASELINE_REPO=<frozen af560f6 original repo> node work/prompt-insertion-receipts-20261024/original-pending-red.mjs
```

Exit 1, expected assertion `original physical transport requires prior committed PENDING receipt`, actual undefined. This uses the original unmodified manual command, PromptReuseService and OrganizerStore, observes exactly one synthetic physical send, and does not add the new owner to the old route. It is a deterministic original regression, not a parallel helper red.

A second deterministic original red, `original-backup-exclusion-red.mjs`, invokes only the frozen original `validateBackupItem` and fails its expected BACKUP_INVALID assertion because the reserved local insertion namespace/key was accepted as a generic receipt. Exit1, `Missing expected exception`. The new original Backup negatives pass in the final green below. Both baseline scripts are explicit synthetic controls, not production import actions.

## Final green

```
node --test extension/tests/prompt-insertion-receipts.test.mjs extension/tests/backup-current-version.test.mjs extension/tests/backup-v081.test.mjs
```

75 passed, zero failed/cancelled/skipped/todo, 12839.179977 ms. Direct owner file:51. Existing Backup files:24. `node --check extension/background/prompt-insertion-receipts.js`, `node --check extension/core/backup-format.js` and `git diff --check` passed.

Coverage includes PENDING-before-send; exact action/receiver/lane/domain/digest binding; actual native-ACK rather than public positive DTO; original callback requalification; invoked throw versus private no-dispatch; late ACK; unknown retention; read-only presentation; sibling atomic admission; cold stale-owner preclaim/pre-send/QUALIFY/cached and late-positive races; source migration/corruption/downgrade/foreign database refusal; actual production restore retaining immutable old evidence while admitting a new-domain intentional claim; lost retirement notice; forged absent reply with no ledger or native authority;500 retained pending capacity; known-continuation rollover refusal;502 healthy cold epochs and502 cold epochs with an old unknown gap; merged intervals; exact Backup result-shape/namespace/key negatives with ordinary text preserved.

The production Backup export entry points remain retired. The restore fixture uses the existing historical encoder to prepare compatible synthetic input, then actual production BackupService restore. No export activation is added.

## Frozen content identities

- Owner: `b1b39e0ffd526bc565f7f54444ecdf4e55c4a2064dd0cdea34e9cc72c8591195`
- Backup format: `f61a8f88613c1e4d50570afc38fb5290fcebd55b2b81cce26d0dea81b4576bc9`
- Direct owner test: `b95e012933e33b6554a3cd4df03d8df46c586e17422573597c2d16c7cd0e98eb`
- Final log: `b33b69c0e838d6f51ed0904522d03c689bdfbc3b401c887c2e016e769f6e0d89`

Temporary genuine producer dependencies in this exact run:
- manual: `ebed7abe17394b55698a7ce1f4c7ead6b684f9900cd8433484dce7b9bd64026b`
- Assist: `cc52ab7be2df428d096be8a7c4b463a283d0a91ac20b9d3a4247841fc4e5ebe9`
- Next: `2c1db39ecb478f75147cb798e3f778e50269338c1922ebce1afd0d3ead7f02f1`

## Preserved intermediate outcomes

First owner run31/32 exposed stale cached action during rotation. Second31/32 exposed origin-digest corruption admission. Third32/32 passed that earlier snapshot. Fourth failed module load during an incomplete local edit; no behavioral result. Fifth32/32 passed readonly transition. Sixth40/41 first called an intentionally retired Backup export entry point and failed FEATURE_UNAVAILABLE; corrected fixture encoding, not production gate. Seventh41/41 passed. Eighth48/48 and ninth74/74 passed their respective expanded snapshots. Logs retain exact failure identities and are not relabeled final evidence.

## Limits and consumer prerequisites

This is prospective insertion-only evidence. Legacy coverage remains unknown. Current source/publication/host tasks, unknown older operations, global quiescence and positive cold selection holds are not manufactured by these receipts. No action replay, composer Send, auto-send, DOM-equality recovery, PromptSyncJournal insertion authority or parallel content store exists. Existing activation remains closed and PREPARE read-only. Root owns integration, version identity, independent paired review and publication; no full/native/product completion is claimed.

## Boundedness and event-identity successor (authoritative over earlier snapshot)

The earlier75-pass owner snapshot was not accepted as final. Independent review found per-transaction budget resets, too many registration ACK scans, action-event misattribution under overlapping probes, missing strict local Sync inventory consumption, and dense unknown-gap pressure. All earlier logs remain facts about those earlier snapshots, not final acceptance.

Additional approved owned runtime lock: `extension/core/idb-repository.js`, solely the explicit `originalRestrictedRepositoryTransaction(repository,ticket,write,fn,stores)` restriction seam. It installs the existing opaque ordinary ticket before original prelude/native/finalizer work without ambient-tagging unrelated operations. It never supplies generation/selection authority. Same ticket scopes serialize. Foreign/forged/failed/expired/overlapping/ambient-ambiguous tickets refuse. Failed/unmeasured native work poisons the ticket, preventing fresh-budget readback or no-dispatch repair. The separate exact-completion test proves only outer response loss AFTER original successful native completion and same-ticket readback, not recovery of failed native commitment.

The cumulative receipt ticket covers all new receipt-owner native metadata/envelope phases through QUALIFY, direct ACK and UI fencing. Existing producer qualification methods retain their own unchanged authority/resource guards; their bytes are not aggregated into this ticket. Their promises remain tracked after deadline races. There is no claim of global/product resource accounting.

Prospective admission is128KiB under actual unchanged4096-reference/2MiB/30s cumulative work. Retained evidence still validates up to500 claims/512KiB; larger valid historical/unknown evidence is preserved and may refuse operations that cannot fit. The owner does not promise every large retained row is operable under every surrounding original prelude. Healthy byte pressure at120KiB uses a private original live-admission retirement certificate only after known continuations settle/are irreversibly fenced. Pending/UNKNOWN is never evicted or called terminal. Cold epochs require all physical claims terminal; only the same original owner can certify its own closed admission epoch.

One original opaque insertion context binds the earliest producer probe, both receiver probes and all later phases to the same action/deadline. PROBE challenges and REGISTER echoes exact recoveryToken; concurrent A/B events cannot share mutable per-tab action authority or consume one another's meters. Each event permits one batch of at most16 current-domain native terminal receipts in one row transaction. No automatic continuation occurs; remainder remains partial for a later genuine original event. Cold notifications group once and cap at16. Immediate receiver cache reclamation requires private native proof, exact settled:true, and settled local continuations; mandatory live QUALIFY and serial guards continue to prevent replay.

The shared strict pure-format module and exact original Sync local-meta consumers are separately owned by commit34c320cf2c6e8b1eccf58579402930d1d094bdd1. They are dependencies, not additional files owned by this commit. The local row remains in full raw source-cut comparisons, is excluded from canonical wire projection, and is retained as the target's own local state during restore. Validation grants no insertion authority. Current producer dependency isbbac1deb258d861c69df869e7dfe0adc11015af8; receiver runtime dependency is89c2b5dd3c8c06557288a50947787a0cd3436c03.

Intermediate bounded run51 cases passed50/51 because a failed native fence now intentionally retained pending instead of using a fresh no-dispatch write. First dense fixture missed the actual120KiB pressure threshold; its stricter fixture corrected that. The first full bounded run135 passed133/135: registration now correctly refused a foreign DB before the fixture reached inspect, and an overflow-negative test omitted its assert. These were test expectation/scope fixes, not weakened production guards. Subsequent0401 selected aggregate passed142/142 in84864.549979ms; log SHA256dbec2b2ca049e3c0c37ead64834b8937ab4c9acb78749ee0a4699df35d1aae1c. The final live-pressure successor has its own run below.

Immutable coordinator snapshot directories0352,0401,0411 were local coordination copies only and are not staged as alternate production source. Their production identities are recorded by hashes and the final commit.

### Final frozen successor evidence

Command:
```
node --test extension/tests/prompt-insertion-receipts.test.mjs extension/tests/repository-explicit-restriction.test.mjs extension/tests/repository-committed-work.test.mjs extension/tests/browser-native-sync-recovery-causal-tail.test.mjs extension/tests/backup-current-version.test.mjs extension/tests/backup-v081.test.mjs
```
Result:145/145 passed, zero failed/cancelled/skipped/todo,85349.932712ms. The direct owner file contains67 cases, new explicit restriction seam10; the remaining68 are unchanged original committed-work, causal-recovery and Backup controls. Log:`final-live-pressure-owner-core-backup.log` SHA256`5e22b1bb57254add51ca2a1e700f27fb53b31873a628c69d18e5fde849883d03`.

Final owned production identities:
- original receipt owner:`4536d26f473381371f829fa51583410b7c1a6042305b50f560c80b14f79b6306`
- original repository restriction seam:`b1831c9dac8f5bf3b7262a2bb37c554f63b7e9e233f7e15f215dbbeb93238d49`
- Backup format:`2a8d7d24c5ec859d68bd73e026efd02555caba0d9c67a3042f7b8460ab968a8d`
- direct owner tests:`a69574d28a292a6f0640ad4400ba2ccf915bba2d22b00b2fd215dc3dcaef3588`
- direct restriction tests:`75ddbd25418ed6009809bcff0084f0eb88b5f80407dad546fddba13932a6af6f`

Coordinated authors independently reran their original scopes against the exact0411 owner snapshot and producerbbac1deb:
- genuine producer/worker/UI regression405/405,8653.411378ms; log hash`99d72aef18959dc9ca41db8def93aa0627ebff2e8db69c579d1e8ec8423ba72d`;
- actual composer/content plus genuine owner/producer paired DOM-VM scope178/178,4.974s; log hash`275bf9ea9ffd0fcb1443b0abd4b35ffff028c1c01db2d56350598b2bfb92fb9a`;
- strict local Sync/checkpoint compatibility author37/37 on34c320cf, shared pure format hash`9a4e8c42da895c8a1a78c2b8081ad9c3a5f70f14e1a8611318413b853fa01a0e`.
These are separately scoped synthetic source receipts, not one combined native run. Independent read-only reviewer inspected final4536d26 owner and live-pressure tests/log with no remaining blocker; it did not rerun tests. Source and core syntax checks plus `git diff --check` passed. Original142-pass0401,405/178 earlier pins and all failures remain separate historical facts.

No overall application selection, cold/global closure, native/browser/Full acceptance, real account/provider operation, install, deployment or external publication is claimed. Root owns coherent integration and publication.
