const ROOT=process.env.REVIEW_ROOT||'/workspace/scratch/ff1c41bf9b29/paia-sync-settings-stop-controls-20261024T2044Z/tree';
const get=path=>import(pathToFileURL(ROOT+'/extension/'+path));
import test from 'node:test';
const {topicRootURL}=await get('core/topic-root-target.js');
import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir,mkdtemp,symlink,rm} from 'node:fs/promises';
import {join} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
const {IDBFactory,IDBKeyRange}=await get('tests/vendor/fake-indexeddb/build/esm/index.js');
const {LibraryDocumentsStore:LibraryFoundationStore}=await get('core/library-documents-store.js');
const {RecoverableCheckpointPublication}=await get('core/browser-native-sync/checkpoint-publication.js');
const {local,capture}=await get('tests/harness/thought-m1.mjs');
const {BrowserNativeSyncCore}=await get('core/browser-native-sync/core.js');
const {SourceBootstrapJournal}=await get('core/browser-native-sync/source-bootstrap-journal.js');
const {buildCheckpoint}=await get('core/browser-native-sync/checkpoints.js');
const {readSegmentDescriptor}=await get('core/browser-native-sync/segments.js');
const {GoogleDriveAppDataTransport,GOOGLE_APPDATA_SCOPE}=await get('core/browser-native-sync/providers/google-drive.js');
const {PreparedPublicationJournal}=await get('core/browser-native-sync/publications.js');
const {readSyncLifecycleConfiguration}=await get('background/sync-lifecycle-configuration.js');
const {createConfiguredSyncLifecycle,syncLifecycleError}=await get('background/sync-local-lifecycle.js');
const ROW='paia-sync-local-lifecycle:v1';
globalThis.IDBKeyRange=IDBKeyRange;
const encode=x=>new TextEncoder().encode(typeof x==='string'?x:JSON.stringify(x));
const binding={subject:'SYNTHETIC_google_subject',clientId:'000000000000-synthetic.apps.googleusercontent.com',generation:'SYNTHETIC_generation',scopes:[GOOGLE_APPDATA_SCOPE]};
const sender={id:'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',url:'chrome-extension://aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/ui/archive.html'};
const api=storage=>({runtime:{id:sender.id,getURL:p=>'chrome-extension://'+sender.id+'/'+p},storage:{local:storage}});
const command=(owner,type)=>owner.handle({type:'PAIA_SYNC_'+type},sender);
function fakeDrive(){
 const files=new Map(),requests=[];let next=0,lose=false;
 const request=async r=>{
  requests.push(r);const u=new URL(r.url);assert.equal(u.origin,'https://www.googleapis.com');assert.equal(r.binding.subject,binding.subject);assert.equal(r.headers.Authorization,undefined);assert.ok(r.maxResponseBytes<=262144||r.maxResponseBytes<=1024*1024);
  const respond=(body,status=200)=>({status,body:encode(body)});
  if(u.pathname==='/drive/v3/files/generateIds'){assert.equal(r.method,'GET');assert.equal(u.searchParams.get('space'),'appDataFolder');return respond({ids:[`SYNTHETIC_file_${++next}`]});}
  if(u.pathname==='/upload/drive/v3/files'){
   assert.equal(r.method,'POST');assert.equal(u.searchParams.get('uploadType'),'multipart');const boundary=r.headers['Content-Type'].split('boundary=')[1],text=new TextDecoder().decode(r.body),parts=text.split(`--${boundary}`);assert.equal(parts.length,4);
   const metadata=JSON.parse(parts[1].split('\r\n\r\n')[1].trim());assert.deepEqual(metadata.parents,['appDataFolder']);assert.equal(metadata.mimeType,'application/octet-stream');
   if(files.has(metadata.id))return respond({},409);
   const separator=encode('\r\n\r\n');let at=0,hits=0;for(;at<=r.body.length-separator.length;at++){if(separator.every((v,i)=>r.body[at+i]===v)&&++hits===2){at+=separator.length;break;}}
   const raw=r.body.slice(at,r.body.length-encode(`\r\n--${boundary}--\r\n`).length);files.set(metadata.id,{...metadata,spaces:['appDataFolder'],trashed:false,size:String(raw.length),raw});if(lose){lose=false;throw Error('SYNTHETIC lost POST response');}return respond({id:metadata.id});
  }
  if(u.pathname==='/drive/v3/files'){
   assert.equal(r.method,'GET');assert.equal(u.searchParams.get('spaces'),'appDataFolder');assert.equal(u.searchParams.has('orderBy'),false);const q=u.searchParams.get('q');assert.ok(q.includes('trashed = false'));
   let found=[...files.values()].filter(f=>f.appProperties?.paiaProtocol==='1');for(const match of q.matchAll(/key='([^']+)' and value='([^']+)'/g))found=found.filter(f=>f.appProperties[match[1]]===match[2]);
   const start=Number(u.searchParams.get('pageToken')||0),size=Number(u.searchParams.get('pageSize'));return respond({files:found.slice(start,start+size).map(({raw,...f})=>f),...(start+size<found.length?{nextPageToken:String(start+size)}:{})});
  }
  const id=u.pathname.slice('/drive/v3/files/'.length);assert.equal(r.method,'GET');assert.match(id,/^[A-Za-z0-9_-]+$/);const file=files.get(id);if(!file)return respond({},404);if(u.searchParams.get('alt')==='media')return {status:200,body:file.raw.slice()};const {raw,...metadata}=file;return respond(metadata);
 };
 return {files,requests,request,loseNextPost(){lose=true;}};
}
// Reuse the existing provider's synthetic HTTP model above. It never calls fetch.
// Only the disposable source configuration reads this private fixture binding;
// there is no production global setter, caller config parameter or RPC issuer.
async function configured(t,options={}){
 const work='/workspace/scratch/ff1c41bf9b29/sync-stop-independent-review-20261024/fixtures';await mkdir(work,{recursive:true});const path=await mkdtemp(join(work,'fixture-')),key='sync_fixture_'+crypto.randomUUID();
 await mkdir(join(path,'background'));await symlink(join(ROOT,'extension','core'),join(path,'core'),'dir');
 await writeFile(join(path,'package.json'),' {"type":"module"} ');
 await writeFile(join(path,'background','sync-local-lifecycle.js'),await readFile(join(ROOT,'extension/background/sync-local-lifecycle.js')));
 await writeFile(join(path,'background','sync-lifecycle-configuration.js'),`export function readSyncLifecycleConfiguration(){return globalThis[${JSON.stringify(key)}];}\n`);
 const cloud=options.cloud??fakeDrive(),storage=options.storage??local(),factory=options.factory??new IDBFactory();let active=true,identity=structuredClone(options.binding??binding);
 const conf={provider:options.provider??'google-drive',datasetId:'SYNTHETIC_google_data',deviceId:options.deviceId??'SYNTHETIC_device_A',binding:identity,request:r=>cloud.request(r),isCurrent:()=>active};globalThis[key]=conf;
 const {createConfiguredSyncLifecycle:create}=await import(pathToFileURL(join(path,'background/sync-local-lifecycle.js')));
 const stores=[],owners=[];
 async function open(){const store=new LibraryFoundationStore(storage,{indexedDB:factory});stores.push(store);if(options.consented!==false&&!(await store.status()).consented)await store.consent(true);await store.finishFoundation();const owner=await create(store,api(storage));owners.push(owner);return {store,owner,core:store.sourceBootstrapJournal.core};}
 t.after(async()=>{owners.forEach(x=>x.suspend());stores.forEach(x=>x.repository.db?.close());delete globalThis[key];await rm(path,{recursive:true,force:true});});
 return {cloud,storage,factory,conf,create,open,setCurrent:v=>active=v,setGeneration:g=>{conf.binding={...conf.binding,generation:g};},setSubject:s=>{conf.binding={...conf.binding,subject:s};}};
}
async function source(x){await x.store.capture(capture((await x.store.status()).epoch));return (await x.store.snapshot()).records;}
async function cold(f,x){x.owner.suspend();x.store.repository.db?.close();x.store.repository.db=null;return f.open();}
const row=f=>f.storage.get(ROW).then(x=>x[ROW]);
const posts=cloud=>cloud.requests.filter(x=>x.method==='POST');

const {PresentationNode}=await get('tests/harness/presentation-dom.mjs');
const {mountSettingsDetail}=await get('ui/settings-details.js');
const {mountSettingsSync}=await get('ui/settings-sync.js');
const tick=()=>new Promise(r=>setImmediate(r));
const uiState=(extra={})=>({version:1,state:'active',scope:'source-working-only',wholeArchiveComplete:false,purgeProtection:'original-journal-fail-closed',resumeAvailable:true,busy:false,task:null,error:null,productionActivation:false,...extra});
const choice=(extra={})=>({version:1,state:'not-prepared',productionActivation:false,canPrepare:true,reloadRequired:false,busy:false,...extra});
function fixture(t,send){
 const previous={document:globalThis.document,chrome:globalThis.chrome},body=new PresentationNode('body'),panel={hidden:false},calls=[];
 const make=tag=>{const n=new PresentationNode(tag);if(tag==='dialog'){n.showModal=()=>n.open=true;n.close=()=>{n.open=false;n.listeners.get('close')?.();};}return n;};
 globalThis.document={body,documentElement:{lang:'en'},getElementById:id=>id==='settings-panel'?panel:null,createElement:make,createElementNS:(_ns,tag)=>make(tag)};
 globalThis.chrome={runtime:{sendMessage:async message=>{calls.push(message);return send(message);}}};
 t.after(()=>{globalThis.document=previous.document;globalThis.chrome=previous.chrome;});
 const detail=mountSettingsSync({mountDetail:mountSettingsDetail,language:()=> 'en'});body.append(detail.row);
 const content=detail.dialog.children[1],button=command=>content.children.flatMap(x=>x.children??[]).find(x=>x.dataset.syncCommand===command);
 const press=command=>{const b=button(command);assert.ok(b&&!b.hidden&&!b.disabled,command+' must remain actionable');b.listeners.get('click')();};
 return {detail,content,calls,panel,button,press,open:async()=>{detail.row.listeners.get('click')();await tick();},click:async command=>{press(command);await tick();},force:command=>button(command).listeners.get('click')()};
}
const deferred=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});return {promise,resolve,reject};};
const ok=data=>({ok:true,data});
const until=async (f,message)=>{for(let n=0;n<150;n++){if(await f())return;await tick();}assert.fail(message);};
const mounted=(t,x)=>fixture(t,async request=>{try{return ok(await x.owner.handle(request,sender));}catch(error){return {ok:false,error:error.code||'SYNTHETIC_ERROR'};}});
for(const stop of ['PAUSE','DISCONNECT'])test('original owner direct '+stop+' fences held committed POST, exact task and future transfers',async t=>{
 const f=await configured(t),x=await f.open();await source(x);await command(x.owner,'RESUME');const held=deferred(),entered=deferred();let once=false;
 f.conf.request=async r=>{const response=await f.cloud.request(r);if(r.method==='POST'&&!once){once=true;entered.resolve();await held.promise;}return response;};
 const pending=command(x.owner,'NOW').then(value=>({value}),error=>({error}));t.after(()=>held.resolve());await entered.promise;const task=await row(f);assert.equal((await x.owner.snapshot()).busy,true);const stopped=await command(x.owner,stop);assert.equal(stopped.state,stop==='PAUSE'?'paused':'disconnected');const n=f.cloud.requests.length;held.resolve();const result=await pending;assert.ok(result.error);assert.equal((await row(f)).mode,stop==='PAUSE'?'paused':'disconnected');assert.equal((await row(f)).task.id,task.task.id);assert.equal((await row(f)).task.phase,'unknown');assert.equal(f.cloud.requests.length,n);await assert.rejects(command(x.owner,'NOW'),{code:'BNS_SYNC_PAUSED'});assert.equal(f.cloud.requests.length,n);
 if(stop==='DISCONNECT')await assert.rejects(command(x.owner,'RESUME'),{code:'BNS_SYNC_REAUTHORIZATION_REQUIRED'});
 else{await command(x.owner,'RESUME');await command(x.owner,'NOW');assert.equal((await row(f)).task.id,task.task.id);assert.equal(posts(f.cloud).length,f.cloud.files.size);}
});
for(const stop of ['PAUSE','DISCONNECT'])test('mounted actual owner '+stop+' during POST prevents late UI revival and extra uploads',async t=>{
 const f=await configured(t),x=await f.open();await source(x);await command(x.owner,'RESUME');const held=deferred(),entered=deferred();let once=false;
 f.conf.request=async r=>{const response=await f.cloud.request(r);if(r.method==='POST'&&!once){once=true;entered.resolve();await held.promise;}return response;};t.after(()=>held.resolve());
 const ui=mounted(t,x);await ui.open();await ui.click('NOW');await entered.promise;const before=await row(f);await ui.click(stop);const mode=stop==='PAUSE'?'paused':'disconnected';await until(async()=> (await row(f)).mode===mode,'original stop persisted');await until(()=>ui.content.dataset.syncState===mode,'mounted stop confirmed');const count=f.cloud.requests.length;held.resolve();await until(async()=>!(await x.owner.snapshot()).busy,'original operation finished');await tick();assert.equal(ui.content.dataset.syncState,mode);assert.doesNotMatch(ui.content.textContent,/undetermined/);assert.equal((await row(f)).task.id,before.task.id);assert.equal(f.cloud.requests.length,count);assert.equal(ui.calls.length,3);assert.ok(ui.calls.every(x=>Object.keys(x).length===1));
});
for(const stop of ['PAUSE','DISCONNECT'])test('mounted actual owner '+stop+' before checkpoint prepare preserves empty task and zero transfer',async t=>{
 const f=await configured(t),x=await f.open();await source(x);await command(x.owner,'RESUME');const held=deferred(),entered=deferred(),prepare=RecoverableCheckpointPublication.prototype.prepare;
 RecoverableCheckpointPublication.prototype.prepare=async function(...args){entered.resolve();await held.promise;return prepare.apply(this,args);};t.after(()=>{held.resolve();RecoverableCheckpointPublication.prototype.prepare=prepare;});
 const ui=mounted(t,x);await ui.open();await ui.click('NOW');await entered.promise;await ui.click(stop);const mode=stop==='PAUSE'?'paused':'disconnected';await until(async()=> (await row(f)).mode===mode,'original stop persisted');await until(()=>ui.content.dataset.syncState===mode,'mounted stop confirmed');held.resolve();await until(async()=>!(await x.owner.snapshot()).busy,'original preparation finished');await tick();assert.equal(ui.content.dataset.syncState,mode);assert.equal((await row(f)).task,null);assert.equal(f.cloud.requests.length,0);
});
for(const stop of ['PAUSE','DISCONNECT'])test('mounted actual owner '+stop+' during RESTORE discovery retains exact original identity',async t=>{
 const cloud=fakeDrive(),a=new LibraryFoundationStore(local(),{indexedDB:new IDBFactory()});t.after(()=>a.repository.db?.close());await a.consent(true);await a.finishFoundation();const core=new BrowserNativeSyncCore(a.repository,{datasetId:'SYNTHETIC_google_data',deviceId:'SYNTHETIC_sender'});a.sourceBootstrapJournal=new SourceBootstrapJournal(core);await a.capture(capture((await a.status()).epoch));await buildCheckpoint(core,new GoogleDriveAppDataTransport(core,{binding,request:cloud.request,isCurrent:()=>true}),{grouped:{store:a}});const initialPosts=posts(cloud).length;
 const f=await configured(t,{cloud,deviceId:'SYNTHETIC_receiver'}),x=await f.open();await command(x.owner,'RESUME');const held=deferred(),entered=deferred();let once=false;
 f.conf.request=async r=>{const response=await f.cloud.request(r);if(r.method==='GET'&&!once){once=true;entered.resolve();await held.promise;}return response;};t.after(()=>held.resolve());
 const ui=mounted(t,x);await ui.open();await ui.click('RESTORE');await entered.promise;const before=await row(f);assert.equal(before.task.kind,'restore');await ui.click(stop);const mode=stop==='PAUSE'?'paused':'disconnected';await until(async()=> (await row(f)).mode===mode,'original stop persisted');await until(()=>ui.content.dataset.syncState===mode,'mounted stop confirmed');const n=f.cloud.requests.length;held.resolve();await until(async()=>!(await x.owner.snapshot()).busy,'original restore finished');await tick();assert.equal(ui.content.dataset.syncState,mode);assert.equal((await row(f)).task.id,before.task.id);assert.equal((await row(f)).task.phase,'unknown');assert.equal(f.cloud.requests.length,n);assert.equal(posts(f.cloud).length,initialPosts);assert.equal((await x.store.snapshot()).records.length,0);
});
test('original owner consent and disconnect binding restrictions remain intact',async t=>{
 const f=await configured(t,{consented:false}),x=await f.open();await assert.rejects(command(x.owner,'RESUME'),{code:'CONSENT_REQUIRED'});await command(x.owner,'PAUSE');await command(x.owner,'DISCONNECT');assert.equal((await row(f)).mode,'disconnected');assert.equal(f.cloud.requests.length,0);assert.equal((await row(f)).task,null);
});
test('mounted failed original stop preserves uncertainty and suppresses future transfers',async t=>{
 const f=await configured(t),x=await f.open();await source(x);await command(x.owner,'RESUME');const held=deferred(),entered=deferred();let once=false;
 f.conf.request=async r=>{const response=await f.cloud.request(r);if(r.method==='POST'&&!once){once=true;entered.resolve();await held.promise;}return response;};t.after(()=>held.resolve());const ui=mounted(t,x);await ui.open();await ui.click('NOW');await entered.promise;
 const originalSet=f.storage.set.bind(f.storage);f.storage.set=async values=>{if(values[ROW]?.mode==='paused')throw Error('SYNTHETIC stop storage rejected');return originalSet(values);};t.after(()=>{f.storage.set=originalSet;});await ui.click('PAUSE');await until(()=>/undetermined/.test(ui.content.textContent),'stop storage uncertainty rendered');const n=f.cloud.requests.length;held.resolve();await until(async()=>!(await x.owner.snapshot()).busy,'prior task settled');await tick();assert.match(ui.content.textContent,/undetermined/);assert.equal(f.cloud.requests.length,n);assert.equal((await row(f)).mode,'active','uncertain stop must not falsely claim persisted pause');await ui.click('STATUS');assert.equal(ui.content.dataset.syncState,'settlement-unknown');for(const command of ['NOW','RESUME','RESTORE'])assert.ok(ui.button(command).hidden||ui.button(command).disabled);assert.equal(f.cloud.requests.length,n);
});
const {ConsumerPreferenceSyncJournal}=await get('core/browser-native-sync/consumer-preference-journal.js');
test('mounted original DISCONNECT interrupts initial enrollment without implied consent or transfer',async t=>{
 const f=await configured(t),x=await f.open(),held=deferred(),entered=deferred(),bootstrap=ConsumerPreferenceSyncJournal.prototype.bootstrap;
 ConsumerPreferenceSyncJournal.prototype.bootstrap=async function(...args){entered.resolve();await held.promise;return bootstrap.apply(this,args);};t.after(()=>{held.resolve();ConsumerPreferenceSyncJournal.prototype.bootstrap=bootstrap;});const ui=mounted(t,x);await ui.open();await ui.click('RESUME');await entered.promise;await ui.click('DISCONNECT');await until(async()=> (await row(f))?.mode==='disconnected','disconnect persisted');await until(()=>ui.content.dataset.syncState==='disconnected','disconnect rendered');held.resolve();await until(async()=>!(await x.owner.snapshot()).busy,'enrollment interrupted');await tick();assert.equal(ui.content.dataset.syncState,'disconnected');assert.equal((await row(f)).task,null);assert.equal(f.cloud.requests.length,0);await assert.rejects(command(x.owner,'RESUME'),{code:'BNS_SYNC_REAUTHORIZATION_REQUIRED'});
});
