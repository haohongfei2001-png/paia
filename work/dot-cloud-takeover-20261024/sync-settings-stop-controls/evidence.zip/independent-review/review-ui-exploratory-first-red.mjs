import test from 'node:test';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
const ROOT=process.env.REVIEW_ROOT||'/workspace/scratch/ff1c41bf9b29/paia-cloud-dev-20261024/repo';
const get=path=>import(pathToFileURL(ROOT+'/extension/'+path));
const {PresentationNode}=await get('tests/harness/presentation-dom.mjs');
const {mountSettingsDetail}=await get('ui/settings-details.js');
const {mountSettingsSync}=await get('ui/settings-sync.js');
const tick=()=>new Promise(r=>setImmediate(r));
const state=(extra={})=>({version:1,state:'active',scope:'source-working-only',wholeArchiveComplete:false,purgeProtection:'original-journal-fail-closed',resumeAvailable:true,busy:false,task:null,error:null,productionActivation:false,...extra});
const choice=(extra={})=>({version:1,state:'not-prepared',productionActivation:false,canPrepare:true,reloadRequired:false,busy:false,...extra});
function fixture(t,send){
 const previous={document:globalThis.document,chrome:globalThis.chrome},body=new PresentationNode('body'),panel={hidden:false},calls=[];
 const make=tag=>{const n=new PresentationNode(tag);if(tag==='dialog'){n.showModal=()=>n.open=true;n.close=()=>{n.open=false;n.listeners.get('close')?.();};}return n;};
 globalThis.document={body,documentElement:{lang:'en'},getElementById:id=>id==='settings-panel'?panel:null,createElement:make,createElementNS:(_ns,tag)=>make(tag)};
 globalThis.chrome={runtime:{sendMessage:async message=>{calls.push(message);return send(message);}}};
 t.after(()=>{globalThis.document=previous.document;globalThis.chrome=previous.chrome;});
 const detail=mountSettingsSync({mountDetail:mountSettingsDetail,language:()=> 'en'});body.append(detail.row);
 const content=detail.dialog.children[1],button=command=>content.children.flatMap(x=>x.children??[]).find(x=>x.dataset.syncCommand===command);
 const press=command=>{const b=button(command);assert.ok(b&&!b.hidden&&!b.disabled,command+' must remain actionable');b.listeners.get('click')();};
 return {detail,content,calls,panel,button,press,open:async()=>{detail.row.listeners.get('click')();await tick();},click:async command=>{press(command);await tick();},force:command=>button(command).listeners.get('click')()};
}
const deferred=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});return {promise,resolve,reject};};
const ok=data=>({ok:true,data});
for(const command of ['NOW','RESTORE','RESUME','STATUS','GENERATION_PREPARE'])for(const stop of ['PAUSE','DISCONNECT'])test('mounted '+stop+' is actionable during '+command+' and owns late completion',async t=>{
 const held=deferred();t.after(()=>held.resolve(ok(state())));
 const start=state({...(command==='RESUME'?{state:'not-started'}:{}),applicationSelection:choice()});
 let reads=0;
 const f=fixture(t,async({type})=>{if(type==='PAIA_SYNC_STATUS'&&++reads===1)return ok(start);if(type===(command.startsWith('GENERATION_')?'PAIA_':'PAIA_SYNC_')+command)return held.promise;if(type==='PAIA_SYNC_'+stop)return ok(state({state:stop==='PAUSE'?'paused':'disconnected',busy:true,resumeAvailable:false}));return ok(start);});
 await f.open();await f.click(command);assert.equal(f.calls.length,2);await f.click(stop);assert.equal(f.calls.at(-1).type,'PAIA_SYNC_'+stop);assert.match(f.content.textContent,stop==='PAUSE'?/Transfers are paused/:/device is disconnected/);
 const settledText=f.content.textContent;held.resolve(ok(command.startsWith('GENERATION_')?choice({state:'review-ready'}):state()));await tick();assert.equal(f.content.textContent,settledText,'late prior response must not overwrite confirmed stop');
 assert.equal(f.calls.length,3);assert.ok(f.calls.every(x=>Object.keys(x).length===1));
});
for(const stop of ['PAUSE','DISCONNECT'])test('mounted reopen with worker busy keeps '+stop+' actionable',async t=>{
 const f=fixture(t,async({type})=>ok(state(type==='PAIA_SYNC_'+stop?{state:stop==='PAUSE'?'paused':'disconnected',busy:true,resumeAvailable:false}:{busy:true,resumeAvailable:false,task:{kind:'checkpoint',phase:'running'}})));
 await f.open();for(const command of ['NOW','RESTORE','RESUME']){const b=f.button(command);assert.ok(b.hidden||b.disabled);f.force(command);}await f.click(stop);assert.equal(f.calls.length,2);
});
for(const ending of ['ack','error','invalid'])test('confirmed stop fences old '+ending+' and finally from newer status',async t=>{
 const old=deferred(),check=deferred();t.after(()=>{old.resolve(ok(state()));check.resolve(ok(state({state:'paused'})));});let reads=0;
 const f=fixture(t,async({type})=>type==='PAIA_SYNC_NOW'?old.promise:type==='PAIA_SYNC_PAUSE'?ok(state({state:'paused'})):++reads===1?ok(state()):check.promise);
 await f.open();await f.click('NOW');await f.click('PAUSE');await f.click('STATUS');const text=f.content.textContent;
 if(ending==='error')old.resolve({ok:false,error:'SYNTHETIC_INTERRUPTED'});else old.resolve(ok(ending==='invalid'?{}:state()));await tick();assert.equal(f.content.textContent,text);assert.equal(f.button('STATUS').disabled,true,'old finally must not release newer status');f.force('STATUS');assert.equal(f.calls.length,4);check.resolve(ok(state({state:'paused'})));await tick();assert.match(f.content.textContent,/Transfers are paused/);
});
test('failed stop remains uncertain through late old success until explicit status',async t=>{
 const old=deferred();t.after(()=>old.resolve(ok(state())));let reads=0;
 const f=fixture(t,async({type})=>type==='PAIA_SYNC_NOW'?old.promise:type==='PAIA_SYNC_PAUSE'?({ok:false,error:'BNS_SYNC_OUTCOME_UNKNOWN'}):ok(state(++reads>1?{state:'paused'}:{})));
 await f.open();await f.click('NOW');await f.click('PAUSE');assert.match(f.content.textContent,/undetermined/);old.resolve(ok(state()));await tick();assert.match(f.content.textContent,/undetermined/);for(const command of ['NOW','RESTORE','RESUME']){assert.ok(f.button(command).hidden||f.button(command).disabled);f.force(command);}assert.equal(f.calls.length,3);await f.click('STATUS');assert.match(f.content.textContent,/Transfers are paused/);assert.equal(f.calls.length,4);
});
test('repeat stop single-flight and unrelated mutation cannot bypass held stop',async t=>{
 const old=deferred(),stop=deferred();t.after(()=>{old.resolve(ok(state()));stop.resolve(ok(state({state:'paused'})));});
 const f=fixture(t,async({type})=>type==='PAIA_SYNC_NOW'?old.promise:type==='PAIA_SYNC_PAUSE'?stop.promise:ok(state()));await f.open();await f.click('NOW');await f.click('PAUSE');
 for(const command of ['PAUSE','DISCONNECT','NOW','RESTORE','RESUME','STATUS'])f.force(command);assert.equal(f.calls.length,3);stop.resolve(ok(state({state:'paused'})));await tick();old.resolve({ok:false,error:'SYNTHETIC_INTERRUPTED'});await tick();assert.match(f.content.textContent,/Transfers are paused/);assert.equal(f.calls.length,3);
});
test('close and Settings exit continue fencing old request and old stop',async t=>{
 const old=deferred(),stop=deferred();t.after(()=>{old.resolve(ok(state()));stop.resolve(ok(state({state:'paused'})));});let reads=0;
 const f=fixture(t,async({type})=>type==='PAIA_SYNC_NOW'?old.promise:type==='PAIA_SYNC_PAUSE'?stop.promise:ok(state(++reads===1?{}:{state:'disconnected'})));await f.open();await f.click('NOW');await f.click('PAUSE');f.detail.dialog.close();await f.open();old.resolve(ok(state()));stop.resolve(ok(state({state:'paused'})));await tick();assert.match(f.content.textContent,/device is disconnected/);assert.equal(f.calls.length,4);
});
