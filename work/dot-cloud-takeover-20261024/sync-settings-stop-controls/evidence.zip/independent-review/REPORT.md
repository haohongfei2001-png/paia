# Independent Settings Sync stop-control review

## Finding

No blocking finding remains in the scoped stop-control change. Final candidate is 995c577f217a6ad9a2480ef980089aa7a19f4245, tree a122b40cdb09222620f36b523fd699aa6f1e9f45, directly parented by 08d06a3c3a143bb8db42dfb3ff4f152a05b9722b. Exact committed UI/backend/test bytes match those independently tested; file digests are recorded in identity.json.

The original mounted UI denied a user’s existing PAUSE or DISCONNECT action while an ordinary command was pending or the worker reported busy. The original backend already admits the restrictions before transfer/consent busy checks. The candidate changes only the UI owner: ordinary mutation requests remain single-flight, restrictions supersede prior presentation work, and stale replies/errors/finally handlers cannot revive transfers or release a newer request.

## Exact evidence

- Accepted base: 08d06a3c3a143bb8db42dfb3ff4f152a05b9722b.
- Exact accepted UI plus coherent accepted owner: 30 reviewer cases, 4 pass and 26 expected first-red failures at the mounted actionability gate. Log: exact-accepted-first-red.log.
- Candidate: the same 30 reviewer cases pass, zero failures/skips/cancellations. Log: candidate-independent-30.log.
- Independent rerun of both complete owning files: 89/89 pass, zero failures/skips/cancellations, 28,557.554542 ms. Log: candidate-owning-files.log.
- Scoped git diff check passes. The production lifecycle backend remains byte-identical to the accepted base.

## Coverage

- Actual mounted Settings handlers, not extracted allowed() logic, under held NOW, RESTORE, active enrollment RESUME, and STATUS.
- PAUSE and DISCONNECT after reopening a busy worker; transfer/enrollment commands remain gated by worker busy.
- Original-owner synthetic committed POST held through stop: persisted restrictive mode, exact task identity, no future requests after stop, and no duplicate POST when explicit pause/resume reconciles the same task.
- Original checkpoint preparation held before transfer: stop persists, task remains absent, zero synthetic provider requests.
- Authenticated synthetic RESTORE discovery held: no late data application, no extra request, exact original durable reservation retained. Original bounded recovery reports uncertainty in its view rather than spending another durable-write budget.
- Failed original stop storage acknowledgment: UI remains uncertain, no false persisted pause claim, no transfer, and explicit STATUS exposes settlement-unknown.
- Initial enrollment interrupted by DISCONNECT: no new consent, no transfer, no task replacement, original reauthorization restriction retained.
- Repeated/contrary stop requests remain single-flight; stale ACK/error/invalid reply/finally cannot overwrite confirmed stop or release a newer STATUS/RESUME flight.
- Close/reopen fencing; unchanged generation-operation single-flight and protected selection phases; original active-only PAUSE eligibility; original consent and disconnect binding rules.

## Preserved failures and fixture corrections

All earlier logs remain. They are not current qualification:

1. first-red-ui.log was an exploratory matrix that also required PAUSE during not-started RESUME and concurrent GENERATION_PREPARE. Those broader eligibility expectations were removed rather than changing production to satisfy them. The preserved exploratory script is review-ui-exploratory-first-red.mjs.
2. first-red-owner.log and scoped-first-red-owner.log initially exercised shared repo HEAD 2f9250fe817dd9eebc0fc1373c05d01dcd7a0ed6, whose Settings UI matched accepted source but whose backend was older. They establish older-backend behavior only.
3. candidate-owner.log initially mixed older static helper imports with candidate backend imports. Its rejected constructor/module-identity results are fixture failures, not production defects. The preserved helper is review-owner-mixed-imports-preserved.mjs.
4. candidate-owner-corrected-imports.log passed 9/11 but expected the older backend’s durable unknown phase during RESTORE. Accepted bounded recovery intentionally retains its durable reserved task and exposes unknown only in the view. The expectation was corrected to assert the exact reservation plus unknown view; the previous helper is review-owner-legacy-phase-preserved.mjs.
5. A broad git diff stat read encountered a historical missing object in the author’s sparse materialization. No fetch, checkout expansion, root staging change, or bypass was attempted. Scoped source/test diff and executable owning tests were available.

The corrected final helpers resolve every production module from REVIEW_ROOT to the same physical candidate core. Exact first-red was rerun using accepted settings-sync.js with that coherent accepted core/backend. No product timeout, guard, backend behavior, assertion threshold, or gate was weakened.

## Scope and limits

Reviewer did not edit production or the shared repository root. Reviewer tests and logs reside outside that root. The author owns UI/tests/report changes. Tests use a minimal synthetic DOM, fake IndexedDB, disposable injected synthetic configuration, and an in-memory provider protocol model that never calls fetch. These are real production owner executions with synthetic fixtures, not native/browser acceptance or live-provider evidence.

No native browser, Full/C/129-group/100k run, network/provider/account action, upload, install, deployment, paid action, cloud task, remote, or local Codex was performed. Physical cancellation of already dispatched external I/O is not claimed; the proven guarantee is that later responses are fenced and no future transfers start. Original backend refusal/resource protections remain authoritative.

## Adjacent failure disclosure

The author’s final committed report preserves six adjacent files at 29/32, with the same three unchanged Prompt-worker failures reproduced using accepted UI in the complete Prompt file (1/4). These adjacent failures were not independently rerun by this reviewer and are not relabeled green. Parent is investigating them separately. This review approves only the scoped stop-control behavior and does not certify a clean broader gate, native behavior, release, or whole-programme completion.
