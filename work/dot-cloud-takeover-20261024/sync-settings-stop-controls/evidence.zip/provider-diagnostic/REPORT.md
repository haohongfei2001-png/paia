# Prompt Sync provider refusal diagnostic

## Result

Exactly one targeted diagnostic invocation executed the two existing full Google/OneDrive scenario definitions on published baseline `06910cd81d6a6176a10d1b78d759aa8802027554` (backend source equivalent to `08d06a3c3a143bb8db42dfb3ff4f152a05b9722b`). Both failed at **B RESUME** with the exact returned response:

`{"ok":false,"error":"CONTROL_PUBLICATION_CHANGED"}`

The diagnostic result is **0/2 pass, 2 failed, 0 cancelled, 0 skipped, 0 todo**, Node exit 1. TAP duration 2001.140104 ms; wall time 2.070945 seconds. Start 2026-10-24T21:02:14.701411+00:00; end 2026-10-24T21:02:16.772344+00:00. Outer ceiling remained 240 seconds. This is a targeted diagnostic, not a whole-file pass or a result added to the historical 151-file/3234 evidence.

Neither scenario reached B RESTORE. Later B edit/conflict/checkpoint and fresh C steps were retained unchanged but were naturally not reached after the failed assertion. No case was shortened or reduced. The cold lost-ACK third case and unsupported-preference fourth case were not selected and did not execute.

Complete output: `evidence/targeted-two-scenario.tap`.
SHA256: `4d3f135390273f75efb20ba1451f53ad58f44de75acf7fb765fc412a4d45d713`.

## Source-exact branch triage and limits

- Both returned codes are now established. They are local control-publication refusals, not evidence of a provider authentication, network or HTTP error. `background/sync-local-lifecycle.js:182–195` performs local preference enrollment, Prompt enrollment, Context enrollment and lifecycle save. It does not open a transport or initiate restore during RESUME. `service-worker.js:673` forwards this recognized code through `syncLifecycleError`; the assertion observed the returned reply only.
- Multiple existing local guards can emit this code. `core/indexed-store.js:210` rejects a changing control fence during a genuine Store.run prelude; `:247` rejects a mismatch between the current fence and the original control snapshot or migration identity. Preference bootstrap invokes qualification through `consumer-preference-journal.js:31–32,116–120`; Context empty enrollment invokes it through `context-mutation-journal-owner.js:42–55` and lifecycle `:146–156`.
- Context empty enrollment still directly performs its original readonly core transaction, using the store's existing control snapshot rather than opening a new control-read scope. That is a relevant source branch for the separately assigned cold composition repair, **not proof that this provider refusal has the same unique cause**. These fresh-B scenarios contain no simulated lost Settings ACK, whereas the separate cold case does. The diagnostic was intentionally not instrumented with an internal stack, guards, probes, timings, waits, extra status or extra Resume. A unique throw site or schedule is therefore not established.
- The earlier accepted-baseline Google B RESTORE `BNS_GROUP_RESOURCE_LIMIT` remains a separate unresolved observation. Parent also reports another unchanged baseline reached that code on both providers. This run did not enter B RESTORE and provides no basis to select its particular resource/identity/refusal branch, change accounting, or import an older queue-overlap explanation. Original 4096-reference / 2 MiB / 30-second limits remain byte-identical.
- Diagnosis stops here with the exact response codes established and internal causality still bounded as above. No automatic rerun, production fix, or green-status attempt occurred.

## Static safety and unchanged scope

The original test SHA256 is `3dd5ec79cf629643399d354cf4e05afc01fef484da03bd9d06e73be5aaaf525d`. The diagnostic test SHA256 is `f51261ca05350e630dda9913582601458713c5c423b8e8d80cee9c1cd0e42957`. The sole source difference stores the returned B RESUME response for its assertion message and prefixes the existing B RESTORE response message; both log only after their existing call returns. `evidence/diagnostic-test-only.patch` preserves the exact diff, and inversion of that replacement reproduced the entire original file.

Preflight statically traced 473 local executable imports, explicitly including the fixture's dynamically imported original worker. No unresolved imports or network/native Node modules were present. The only Node builtins were assert/strict, fs/promises, path, test and url. Existing fake-indexeddb supplies per-device IDBFactory; synthetic Chrome/DOM objects supply the UI/runtime surface; fixture local storage is an in-memory object. Both actual provider transports receive the existing Map-backed HTTP request functions and have no default fetch fallback. All unrelated AI service, identity endpoint and policy configuration modules return null. No global fetch reject guard existed in the original fixture, and none was added. Protocol URLs were handled only by the injected in-memory functions. No actual network route was found for the selected scenarios.

No production or harness code, data, case sizes, operations, budgets, clocks, sleeps, retries, additional STATUS/RESUME, permissions or authority was changed. No native/browser/old C/protected 129/100k/Full/provider account/remote/install/deploy/paid/local Codex action occurred.

## Exact source preparation and preservation

A first local full git archive failed before extraction or execution because a historical object was missing. Its stderr and incomplete archive are preserved as `archive-preparation-error.txt` and `baseline-extension.INCOMPLETE.tar`. This was a missing local object, not an access denial. No scenario had run.

The already materialized accepted-baseline tree was used only after each copied file was independently checked against the expected `06910cd` Git blob identity. Two unrelated owning-test files in that materialization differed and were restored from their exact existing local base blobs before the diagnostic delta was made. All **4,027 materialized files** match the baseline except the single permitted diagnostic test delta. Four unavailable historical documentation artifacts are named in `baseline-manifest.json`; none is executable or part of the complete import closure. Baseline executable code and tests are preserved in `baseline-exact-materialized-source.tar.gz`, SHA256 `3fd033210255fb8b9891fc8c6c22c0fe3f75abdde4bbaeeb01ba0f49a81bba81`.

Original prior FAIL logs, parent diagnostic conclusions, preflight, full import closure, command, full TAP, run receipt and before/after manifests remain under evidence. The source/test bytes were rechecked after execution; the temporary fixture copies were fully removed by the original cleanup.

Root checkout HEAD remains `2f9250fe817dd9eebc0fc1373c05d01dcd7a0ed6`; root HEAD, full porcelain status, working diff and staged binary diff were byte-identical before and after. Nothing was committed or published. No broader qualification is claimed.
