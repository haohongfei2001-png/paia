from pathlib import Path
import subprocess,hashlib,json
P=Path('/workspace/scratch/ff1c41bf9b29/paia-cloud-dev-20261024');R=P/'repo';W=P/'sync-stop-integration-20261024';E=P/'sync-stop-integration-evidence-20261024'
BASE='06910cd81d6a6176a10d1b78d759aa8802027554';AUTHOR='8e91200f90e24889932020d3de770484de93cc9d';AB='08d06a3c3a143bb8db42dfb3ff4f152a05b9722b';BR='codex/sync-stop-integration-20261024'
def g(*args,cwd=W,inp=None):return subprocess.check_output(['git','-C',str(cwd),*args],input=inp)
def sha(x):return hashlib.sha256(x).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
paths=g('diff','--name-only',AB,AUTHOR).decode().splitlines();assert len(paths)==12
assert g('rev-parse','HEAD').decode().strip()==BASE
assert set(g('diff','--cached','--name-only').decode().splitlines())==set(paths)
owned=[]
for p in paths:
 data=g('show',AUTHOR+':'+p);assert (W/p).read_bytes()==data
 owned.append({'path':p,'bytes':len(data),'sha256':sha(data),'blob':g('rev-parse',AUTHOR+':'+p).decode().strip()})
g('diff','--cached','--check','--','extension')
tree=g('write-tree','--missing-ok').decode().strip();commit=g('commit-tree',tree,'-p',BASE,'-p',AUTHOR,inp=b'Integrate reviewed Settings Sync stop-control UI with preserved adjacent failures\n').decode().strip()
g('update-ref','refs/heads/'+BR,commit,BASE)
assert not g('status','--porcelain=v1','--untracked-files=all').strip()
unchanged={}
for p in ['extension/core','extension/background','services']:
 assert g('rev-parse',BASE+':'+p)==g('rev-parse',commit+':'+p);unchanged[p]=g('rev-parse',commit+':'+p).decode().strip()
tests=['extension/tests/settings-sync.test.mjs','extension/tests/sync-local-lifecycle.test.mjs'];dump(E/'test-files.json',tests)
manifest={'base':BASE,'base_tree':g('rev-parse',BASE+'^{tree}').decode().strip(),'author':AUTHOR,'author_tree':g('rev-parse',AUTHOR+'^{tree}').decode().strip(),'author_base':AB,'source_commit':commit,'source_tree':tree,'worktree':str(W),'branch':'refs/heads/'+BR,'changed_paths':owned,'test_files':tests,'test_list_sha256':sha((E/'test-files.json').read_bytes()),'outer_timeout_seconds':240,'only_runtime_change':'extension/ui/settings-sync.js','unchanged_trees':unchanged,'adjacent_status':'FAIL: author 29/32; accepted UI Prompt file 1/4, same names but different Google failure step; separate cold control-snapshot composition defect identified by parent-owned read-only diagnosis, provider RESUME/refusal causes unresolved; not waived','previous_full_scope':'151 files / 3234 belongs historical published548 only; no current full claim','preparation_check':'Full diff --check exits2 for eight whitespace-only TAP lines in preserved adjacent FAIL logs. Source/test check passes. No evidence bytes rewritten.'}
dump(E/'frozen-integration-manifest.json',manifest);(E/'SOURCE.patch').write_bytes(g('diff','--binary',BASE,commit));print(json.dumps(manifest,indent=2))
