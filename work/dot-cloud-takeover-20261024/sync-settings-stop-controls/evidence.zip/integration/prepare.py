from pathlib import Path
import subprocess,hashlib,json,os
P=Path('/workspace/scratch/ff1c41bf9b29/paia-cloud-dev-20261024')
R=P/'repo'; W=P/'sync-stop-integration-20261024'; E=P/'sync-stop-integration-evidence-20261024'
BASE='06910cd81d6a6176a10d1b78d759aa8802027554'; AUTHOR='8e91200f90e24889932020d3de770484de93cc9d'; AB='08d06a3c3a143bb8db42dfb3ff4f152a05b9722b'; BR='codex/sync-stop-integration-20261024'
def g(*args,cwd=R,inp=None):return subprocess.check_output(['git','-C',str(cwd),*args],input=inp)
def sha(x):return hashlib.sha256(x).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
assert g('rev-parse',BASE+'^{tree}').decode().strip()=='d741676ec945be5aad7c383af5140e467ca7fdc6'
assert not W.exists()
paths=g('diff','--name-only',AB,AUTHOR).decode().splitlines()
assert len(paths)==12 and sum(p.startswith('extension/') for p in paths)==3
assert paths[:3]==['extension/tests/settings-sync.test.mjs','extension/tests/sync-local-lifecycle.test.mjs','extension/ui/settings-sync.js']
g('worktree','add','--no-checkout','-b',BR,str(W),BASE)
g('read-tree',BASE,cwd=W)
entries=[]
for row in g('ls-tree','-r','-z',BASE).split(b'\0'):
 if not row:continue
 header,p=row.split(b'\t');mode,kind,oid=header.decode().split();entries.append((mode,kind,oid,p.decode()))
g('update-index','--skip-worktree','--stdin',cwd=W,inp=''.join(p+'\n' for _,_,_,p in entries).encode())
chosen=[x for x in entries if (x[3].startswith('extension/') and not x[3].startswith('extension/work/')) or x[3] in ['package.json','.gitignore'] or x[3].startswith('work/dot-cloud-takeover-20261024/')]
proc=subprocess.Popen(['git','-C',str(R),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
materialized=[];missing=[]
for mode,kind,oid,p in chosen:
 proc.stdin.write((oid+'\n').encode());proc.stdin.flush();header=proc.stdout.readline().decode().strip()
 if header.endswith(' missing'):missing.append(p);continue
 _,typ,n=header.split();data=proc.stdout.read(int(n));assert proc.stdout.read(1)==b'\n';assert typ=='blob'
 target=W/p;target.parent.mkdir(parents=True,exist_ok=True)
 if mode=='120000':target.symlink_to(data.decode())
 else:target.write_bytes(data);target.chmod(0o755 if mode=='100755' else 0o644)
 materialized.append(p)
proc.stdin.close();assert proc.wait()==0
g('update-index','--no-skip-worktree','--stdin',cwd=W,inp=''.join(p+'\n' for p in materialized).encode())
owned=[]
for p in paths:
 data=g('show',AUTHOR+':'+p);target=W/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 owned.append({'path':p,'bytes':len(data),'sha256':sha(data),'blob':g('rev-parse',AUTHOR+':'+p).decode().strip()})
g('update-index','--no-skip-worktree','--stdin',cwd=W,inp=''.join(p+'\n' for p in paths if p in [x[3] for x in entries]).encode())
g('add','--sparse','--',*paths,cwd=W)
assert set(g('diff','--cached','--name-only',cwd=W).decode().splitlines())==set(paths)
g('diff','--cached','--check',cwd=W)
tree=g('write-tree','--missing-ok',cwd=W).decode().strip()
commit=g('commit-tree',tree,'-p',BASE,'-p',AUTHOR,inp=b'Integrate reviewed Settings Sync stop-control UI with preserved adjacent failures\n',cwd=W).decode().strip()
g('update-ref','refs/heads/'+BR,commit,BASE,cwd=W)
assert not g('status','--porcelain=v1','--untracked-files=all',cwd=W).strip()
for p in ['extension/core','extension/background','services']:
 assert g('rev-parse',BASE+':'+p)==g('rev-parse',commit+':'+p)
tests=['extension/tests/settings-sync.test.mjs','extension/tests/sync-local-lifecycle.test.mjs']
dump(E/'test-files.json',tests)
manifest={'base':BASE,'base_tree':g('rev-parse',BASE+'^{tree}').decode().strip(),'author':AUTHOR,'author_tree':g('rev-parse',AUTHOR+'^{tree}').decode().strip(),'author_base':AB,'source_commit':commit,'source_tree':tree,'worktree':str(W),'branch':'refs/heads/'+BR,'changed_paths':owned,'test_files':tests,'test_list_sha256':sha((E/'test-files.json').read_bytes()),'outer_timeout_seconds':240,'only_runtime_change':'extension/ui/settings-sync.js','backend_unchanged':True,'adjacent_status':'FAIL: author 29/32; accepted UI Prompt file 1/4, same names but different Google failure step; open separate product gap, no common-cause claim','previous_full_scope':'151 files / 3234 belongs historical published548 only; no current full claim','materialized':len(materialized),'known_sparse_missing':missing,'nonmaterialized_paths':len(entries)-len(materialized)}
dump(E/'frozen-integration-manifest.json',manifest)
(E/'SOURCE.patch').write_bytes(g('diff','--binary',BASE,commit))
print(json.dumps(manifest,indent=2))
