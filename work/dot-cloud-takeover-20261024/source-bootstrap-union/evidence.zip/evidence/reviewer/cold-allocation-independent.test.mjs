import test from 'node:test';
import assert from 'node:assert/strict';
import {IDBFactory,IDBKeyRange} from './vendor/fake-indexeddb/build/esm/index.js';
import {LibraryFoundationStore} from '../core/thought-store.js';
import {local,capture} from './harness/thought-m1.mjs';
import {BrowserNativeSyncCore} from '../core/browser-native-sync/core.js';
import {SourceBootstrapJournal} from '../core/browser-native-sync/source-bootstrap-journal.js';
import {buildGroupedCheckpoint,GroupedCheckpointRestore,requireActivatedSourceBootstrapUnion} from '../core/browser-native-sync/group-checkpoint.js';
import {prepareSourceBootstrapUnion,readSourceBootstrapUnionProof} from '../core/browser-native-sync/source-bootstrap-union.js';
import {createOriginalRecoveryWork,withOriginalRecoveryWork,finishOriginalRecoveryWork} from '../core/idb-repository.js';
import {assertCompletedGroupedRestoreControl} from '../core/browser-native-sync/completed-group-restore-control.js';
globalThis.IDBKeyRange=IDBKeyRange;
const datasetId='synthetic_union_restore';
const cloud=()=>{const rows=new Map();return {rows,async putImmutable(ref,body){rows.set(ref.id,body.slice());},async get(ref){return rows.get(ref.id)?.slice();}};};
async function fresh(device,storage=local(),indexedDB=new IDBFactory()){
 const store=new LibraryFoundationStore(storage,{indexedDB});await store.consent(true);await store.finishFoundation();const core=new BrowserNativeSyncCore(store.repository,{datasetId,deviceId:device});return {store,core,storage,indexedDB};
}
async function addSource(target,label,text='Synthetic '+label){target.store.sourceBootstrapJournal=new SourceBootstrapJournal(target.core);const request=capture((await target.store.status()).epoch,'union_message_'+label,text);request.chat={id:'union_chat_'+label,url:'https://chatgpt.com/c/union_chat_'+label,title:'Synthetic '+label};await target.store.capture(request);}
async function fixture(text){
 const transport=cloud(),ancestor=await fresh('union_ancestor');await addSource(ancestor,'ancestor',text);const base=await buildGroupedCheckpoint(ancestor.core,transport,{store:ancestor.store}),heads=[];
 for(const label of ['left','right']){const branch=await fresh('union_branch_'+label),restore=new GroupedCheckpointRestore(branch.core,{store:branch.store,restoreId:'union_branch_restore_'+label});await restore.stageCheckpoint(base.ref,r=>transport.get(r));await restore.activate();await addSource(branch,label,text);heads.push(await buildGroupedCheckpoint(branch.core,transport,{store:branch.store,parents:[base.ref.id]}));}
 return {transport,base,heads};
}
async function window(target,action,options){const ticket=createOriginalRecoveryWork(target.core.repository,options);try{return await withOriginalRecoveryWork(target.core.repository,ticket,()=>action(ticket));}finally{finishOriginalRecoveryWork(target.core.repository,ticket);}}
async function proofFor(target,f){return prepareSourceBootstrapUnion(target.core,{store:target.store,ancestorRef:f.base.ref,headRefs:f.heads.map(x=>x.ref),get:r=>f.transport.get(r)});}
const state=target=>target.store.repository.transaction(false,async t=>Object.fromEntries(await Promise.all([...t.tx.objectStoreNames].map(async name=>[name,await t.all(name)]))));
async function staged(f=undefined,checkpoint){f??=await fixture();const target=await fresh('union_receiver'),restoreId='union_restore_target',restore=new GroupedCheckpointRestore(target.core,{store:target.store,restoreId,...(checkpoint?{checkpoint}:{})});await window(target,async()=>restore.stageSourceBootstrapUnion(await proofFor(target,f)));return {...f,target,restoreId,restore};}
function freeze(x){if(x&&typeof x==='object'){Object.values(x).forEach(freeze);Object.freeze(x);}return x;}

for (const mutation of ['input-allocation','revision-allocation','thought-epoch','suppression-identity']) test('cold union rejects semantically relevant '+mutation+' change',async()=>{
 const x=await staged();await window(x.target,()=>x.restore.activate());
 await x.target.store.repository.transaction(true,async t=>{
  if(mutation==='input-allocation'){const row=(await t.all('inputStates'))[0];row.deltaSequence+=100;await t.put('inputStates',row);}
  else if(mutation==='revision-allocation'){const row=(await t.all('revisions'))[0];row.sequence+=100;row.listKey=[row.entityKey,row.sequence];row.documentList=[row.documentId,row.sequence];await t.put('revisions',row);}
  else if(mutation==='thought-epoch')await t.put('meta',{id:'thought-epoch',value:999});
  else{const row=await t.get('meta','thought-suppression-key');row.value[0]=(row.value[0]+1)%256;await t.put('meta',row);}
 });
 const before=await state(x.target);await assert.rejects(window(x.target,()=>requireActivatedSourceBootstrapUnion(x.target.core,{store:x.target.store})));assert.deepEqual(await state(x.target),before);
});
