# Independent Source-bootstrap union review

Status: bounded independent review clearance granted for exact corrected integration `d7604d8d1f7f22563734f0a5349493c8ffc55fab`, tree `c03a7069f9fbd730d3ee4cdc093ac52e04e542f4`, after 2931/2931 tests across 137 complete files. The failed first integration remains preserved separately. This is not publication, native-browser, real-provider, Full, general merge, or whole-programme acceptance.

## Exact reviewed components

Base: `2f9250fe817dd9eebc0fc1373c05d01dcd7a0ed6`.

- Proof: `e34166703d591a2cde0e001ceb1617cfe1de49af`.
- Atomic restore: `147c7a7e15f4e54e097df908b982c4019ff46cd9`.
- Consumer/lifecycle/publication: `98759679fe4a1a7ad11aea5cbda1bb05de1dff66`, successor of `f75635f18bad52e78866649f45c65400e689d481`.
- Actual worker RPC fixture: `599849fe0e1c8efb720298f7ea56965d2121ff24`.

Critical SHA-256 values:

- source-bootstrap-union.js: `c6358b200b76b91436fefe0d8079e481aecea8e703aa898acbea5066bbded50d`.
- group-checkpoint.js: `451accb77d7c09917893b79cee8daaf8f587f7b7e35d86e31426f7cadf70b82f`.
- source-purge-protocol-controls.js: `05b5fd49b37e40f572875d0206fe2c1965ecaa4fec50f1c107418ec152e8d8f2`.
- recovery-session.js: `52cd88ec00e85209dd6573dba4275681e7a70c8548a57794c614537336c4b10b`.
- checkpoint-publication.js: `b6548e3ebc7ff7f4677141c0ec2460d6187e650b696e40680439d19fc92bd8c8`.
- sync-local-lifecycle.js: `2dc7787fb596a02c2fbdb0ea472592772aed9a74e654481c497190fb9e781022`.
- sync-source-bootstrap-union-worker.test.mjs: `30f1c0da5ea97f388833f1b3a05ec8ebbc9e52536f5f6c200bfe16f2f479dc19`.

## Scope and boundary review

The admitted operation remains exactly two complete Source-bootstrap-only sibling heads sharing one exact direct parent, with complete byte-exact ancestor retention and independent identity/operation/sequence domains, into an empty canonical destination. The local selector is separately typed and versioned, never a protocol manifest or native selection grant. Proof readers expose frozen semantic data, not original branded plans or owner capabilities. Cold continuation reauthenticates retained original manifest encodings, item descriptors, operations and union digest on a new invocation ticket.

Reservation, discovery, compilation, staging, one original atomic activation, and confirmation share the original bounded invocation. Failure handling for typed unions or not-yet-classified recovery performs no new lifecycle storage IO. Existing authenticated ordinary/negative protocol-reference error behavior remains unchanged. Late local ACKs remain uncertain rather than being assumed rolled back; known committed activation and already-confirmed durable task phase are preserved.

Republication is restricted to the unchanged activated union. It uses the original encoder and authentic parent references, verifies retention against each original head, and refuses missing or advanced remote cuts whose operations are absent locally. No timestamp winner, synthetic remote manifest, fake Working owner, nonempty merge, protected/native grant, or unsupported-family expansion was introduced.

## Independent findings and corrections

1. The first replay-ID tamper test originally needed an artificial occupied target namespace to fail. Removing that unrelated occupant exposed acceptance of a substituted empty replay namespace. The final deterministic local replay identity binds restore ID, selector, physical database/device identity and exact original base.
2. Original FilterRunner activity advances backup-data-generation by three transactions without changing Source/Input/history owners. Exact base-plus-one was therefore a false rejection. Merely deleting it then accepted four physical metadata changes and three filter visibility changes. The final local receipt pins actual allocation/counter/identity state and stable filter intent, validates only original deterministic filter evaluation changes, and retains a safe monotone generation bound.
3. The earlier terminal fence omitted canonical metadata. Three independent after-activation metadata mutations committed. The final fence captures all tables/keys/values before hooks and predicts the unchanged original local finalizers using a private metered clone overlay. Its facade has only frozen store names, not a native transaction or capability. The real Repository still executes the real finalizers once and performs the exact final read fence before settlement. No metadata prefix is broadly ignored.
4. The initial lifecycle error catch performed one fresh unmetered storage write after each of two independent recovery failures. The final revision-bound private error view leaves the durable task/CAS preimage untouched and opens no replacement budget.

All first-failure logs remain separate and unchanged. They are not relabelled as passing evidence.

## Reviewer-run evidence

- Frozen proof module plus the complete original Source-bootstrap owner file: 51/51 pass, zero skipped (`proof-owner-frozen.log`).
- Four complete reviewer files against final restore bytes: 28/28 pass, zero skipped (`independent-exact-final.log`, SHA-256 `3f6888380125b6c50b727661dd6cd449e16758c8a89d96aa4f1e72ad3d5d62af`). This includes the unchanged independent replay-ID, physical-allocation, filter-intent and late-metadata controls.
- Unchanged independent lifecycle failure-write tests against final lifecycle bytes: 2/2 pass, zero skipped (`failure-bookkeeping-corrected.log`, SHA-256 `9c1396a382a345716647fe6d3c5f073052099a5b6e9809342c0cc1bf9e06fabe`).

These separate runs overlap other owning suites and must not be summed as unique tests. Authors separately report final restore 155/155 and runtime 222/222 complete-owner combinations; final integrated qualification is a separate result.

## Limits

All exercised storage/provider paths were small synthetic fake-IndexedDB and fake-provider fixtures. The actual worker RPC case explicitly invokes existing RESUME commands; it does not qualify a route without those enrollment steps. Positive native current-projection recovery, Full, real accounts/providers, installs, deployments, paid calls, prohibited scale diagnostics, and real remote publication were not exercised or authorized by this review. The reviewer changed no production files and encountered no denied or uncertain tool action.

## First integrated qualification and focused diagnosis

The exact integrated commit `a3b1187ffe1868cde926909faba5a5568f31cc66`, tree `f23e9c3565f5ad778a6cdc7dc909ff05eec58612`, contained the 15 reviewed changed paths with byte-exact author hashes. The 137-file list preserved all 128 original complete files in order and added the nine approved complete owners. No test-name filtering, case skips or prohibited standalone scale-owner file was used.

The first run failed at the unchanged 240-second outer ceiling: 2775 tests reported, 2767 passed, seven module-load failures, one cancellation, zero skipped, zero todo. Its immutable log SHA-256 is `a9b5635f011bbe18bb79689a6448572baa685afe1d989728727e5f99e0816849`. The seven errors were missing existing `pg` dependency imports in synthetic fixture owners. The integrator reports that reusing the parent-identified existing package tree through an isolated-only symlink, without an install or source edit, made the seven complete files pass 149/149. This does not retrospectively pass the first run.

The cancelled Assist private-session file has an independent fixture race: its original 25 ms deadline starts before an asynchronous final qualification read, but the test waits only for physical provider entry. The original production may correctly time out before entry, leaving the fixture's entry promise unresolved. Two reviewer-owned cases reproduce this with a controlled 60 ms qualification delay and a normal-entry cancellation counterfactual: 2/2 pass. The delayed case retains one original UNKNOWN/RESERVATION_RETAINED attempt, performs zero physical provider calls, and leaves the original fixture entry promise pending after the run has already rejected. This proves the mechanism, not uniquely the historical scheduler timing. Evidence: `assist-entry-race-independent.log` (SHA-256 `3a5429ea811ce3a3b31b18e350d8fdb699b2becced39d791bb4fb205648aa1fd`) and `assist-review/extension/tests/assist-entry-race-independent.test.mjs` (SHA-256 `77c9825669b6ce899246f5433544b5fa0ae2498d8585abc1240187e8ce0e0a18`). No original production or owning test was edited by the reviewer.

The parent-approved test-only correction preserves all 51 original Assist cases and their cancellation, UNKNOWN, reservation, late-result, insertion and cold-retry assertions. The eight post-entry cases now own both settlement and entry promises, mock only `setTimeout` after preparation, and advance the original unchanged 25 ms timer only after genuine provider entry. A separate 52nd case holds the actual final qualification, expires that same 25 ms timer before entry, and proves UNKNOWN, one retained reservation, zero physical calls/results and no late dispatch. No production file or timeout value changed. The reviewer independently ran the complete corrected file: 52/52 pass, zero skips/cancellations. Exact test SHA-256: `9c7c8c1e8074915a5a2e47ed8399a54c109bba6e8cb71ac40c87e081c17c088a`; reviewer log `assist-entry-race-corrected-owner.log` SHA-256: `ad64aae7e6e68f76f6be79ceb41605b1eca7ba021a640d6cc1d104969cb09b91`. Static clearance extends to this exact test-only correction; its final integrated outcome follows below.

## Final integrated outcome

The corrected exact integration `d7604d8d1f7f22563734f0a5349493c8ffc55fab`, tree `c03a7069f9fbd730d3ee4cdc093ac52e04e542f4`, passed **2931/2931 tests across the same 137 complete files**, with zero failures, cancellations, skips or todos, in 145163.628064 ms under the unchanged 240-second outer limit. The only code difference from the first integrated candidate was the independently reviewed test-only Assist fixture correction. No production edits were made after the reviewed author freezes.

The reviewer independently verified the finished result, exact command list, terminal log, unchanged failed-run hash, corrected log hash, and all 16 final changed paths against their frozen source commits, HEAD blobs and on-disk SHA-256 values. The only untracked worktree item was the approved isolated symlink to the already-existing `pg` dependency tree. Corrected log: `combined-137-source-union-corrected.log`, SHA-256 `4337d339f8f73eeeb55564c43b9e5cffdd257d8663578a4104d6f8d4d4bb7e64`; result: `combined-result.corrected.json` in the integration evidence directory. The original failed log remains SHA-256 `a9b5635f011bbe18bb79689a6448572baa685afe1d989728727e5f99e0816849`.

No unresolved blocker remains within the stated Source-bootstrap-only sibling recovery slice. Root retains all publication authority. This clearance does not expand to native/current-projection positive recovery, protected or nonempty recovery, general independent-head merge, subsequent local mutations, browser or real-provider validation, Full, forbidden scale lanes, or enrollment without the RPC fixture's explicit original RESUME commands.
