import {readFile,writeFile,mkdir,mkdtemp,symlink,rm} from 'node:fs/promises';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {fileURLToPath,pathToFileURL} from 'node:url';
import test from 'node:test';
import assert from 'node:assert/strict';
import {IDBFactory,IDBKeyRange} from './vendor/fake-indexeddb/build/esm/index.js';
import {LibraryDocumentsStore} from '../core/library-documents-store.js';
import {local,capture} from './harness/thought-m1.mjs';
import {BrowserNativeSyncCore} from '../core/browser-native-sync/core.js';
import {SourceBootstrapJournal} from '../core/browser-native-sync/source-bootstrap-journal.js';
import {buildCheckpoint,StagedSyncRestore} from '../core/browser-native-sync/checkpoints.js';
import {LocalSyncRecoverySession} from '../core/browser-native-sync/recovery-session.js';
import {RecoverableCheckpointPublication} from '../core/browser-native-sync/checkpoint-publication.js';
import {GoogleDriveAppDataTransport,GOOGLE_APPDATA_SCOPE} from '../core/browser-native-sync/providers/google-drive.js';
import {readObject} from '../core/browser-native-sync/segments.js';
import {fakeGoogleCheckpointHTTP} from './harness/checkpoint-publication-http.mjs';
globalThis.IDBKeyRange=IDBKeyRange;
const datasetId='SYNTHETIC_union_runtime',binding={subject:'SYNTHETIC_google_subject',clientId:'000000000000-synthetic.apps.googleusercontent.com',generation:'SYNTHETIC_generation',scopes:[GOOGLE_APPDATA_SCOPE]};
async function fresh(t,deviceId,{storage=local()}={}){const factory=new IDBFactory(),store=new LibraryDocumentsStore(storage,{indexedDB:factory});await store.consent(true);await store.finishFoundation();t.after(()=>store.repository.db?.close());const core=new BrowserNativeSyncCore(store.repository,{datasetId,deviceId});store.sourceBootstrapJournal=new SourceBootstrapJournal(core);return {store,core,storage,factory};}
async function reopen(t,f){const deviceId=f.core.deviceId;await f.store.repository.close();const store=new LibraryDocumentsStore(f.storage,{indexedDB:f.factory});await store.finishFoundation();t.after(()=>store.repository.db?.close());const core=new BrowserNativeSyncCore(store.repository,{datasetId,deviceId});store.sourceBootstrapJournal=new SourceBootstrapJournal(core);return {...f,store,core};}
async function source(f,name){const request=capture((await f.store.status()).epoch,'SYNTHETIC_message_'+name,'SYNTHETIC exact '+name+' 中文🙂');request.chat={id:'SYNTHETIC_chat_'+name,url:'https://chatgpt.com/c/SYNTHETIC_chat_'+name,title:'SYNTHETIC '+name};await f.store.capture(request);}
const transport=(f,cloud)=>new GoogleDriveAppDataTransport(f.core,{binding,request:cloud.request,isCurrent:()=>true});
const producer=(f,cloud)=>new RecoverableCheckpointPublication(f.core,{store:f.store,binding:{...binding,provider:'google-drive-appdata'},request:cloud.request,isCurrent:()=>true});
const recovery=(f,cloud,options={})=>new LocalSyncRecoverySession(f.core,{store:f.store,transport:transport(f,cloud),...options});
const canonical=f=>f.store.repository.transaction(false,async tx=>Object.fromEntries(await Promise.all([...tx.tx.objectStoreNames].filter(k=>k!=='meta').map(async k=>[k,await tx.all(k)]))));
const writes=cloud=>cloud.requests.filter(r=>['POST','PUT'].includes(r.method)).length;
async function fixture(t,{receiverStorage}={}){const cloud=fakeGoogleCheckpointHTTP(binding),seed=await fresh(t,'SYNTHETIC_seed');await source(seed,'ancestor');const ancestor=await buildCheckpoint(seed.core,transport(seed,cloud),{grouped:{store:seed.store}}),heads=[];
 for(const name of ['left','right']){const f=await fresh(t,'SYNTHETIC_'+name);const owner=new StagedSyncRestore(f.core,{grouped:{store:f.store}});await owner.stageCheckpoint(ancestor.ref,ref=>transport(f,cloud).get(ref));await owner.activate();await source(f,name);heads.push(await buildCheckpoint(f.core,transport(f,cloud),{grouped:{store:f.store},parents:[ancestor.ref.id]}));}
 return {cloud,seed,ancestor,heads,c:await fresh(t,'SYNTHETIC_receiver',receiverStorage?{storage:receiverStorage}:{})};}
const lifecycleRow='paia-sync-local-lifecycle:v1',sender={id:'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',url:'chrome-extension://aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/ui/archive.html'};
const lifecycleCommand=(owner,type)=>owner.handle({type:'PAIA_SYNC_'+type},sender);
async function lifecycle(t,cloud,storage){
 const path=await mkdtemp(join(tmpdir(),'paia-union-lifecycle-')),key='SYNTHETIC_union_lifecycle_'+crypto.randomUUID(),factory=new IDBFactory(),stores=[],owners=[];
 await mkdir(join(path,'background'));await symlink(fileURLToPath(new URL('../core',import.meta.url)),join(path,'core'),'dir');await writeFile(join(path,'package.json'),' {"type":"module"} ');await writeFile(join(path,'background','sync-local-lifecycle.js'),await readFile(new URL('../background/sync-local-lifecycle.js',import.meta.url)));await writeFile(join(path,'background','sync-lifecycle-configuration.js'),`export function readSyncLifecycleConfiguration(){return globalThis[${JSON.stringify(key)}];}\n`);
 globalThis[key]={provider:'google-drive',datasetId,deviceId:'SYNTHETIC_lifecycle_C',binding,request:cloud.request,isCurrent:()=>true};const {createConfiguredSyncLifecycle}=await import(pathToFileURL(join(path,'background','sync-local-lifecycle.js'))),api={runtime:{id:sender.id,getURL:p=>'chrome-extension://'+sender.id+'/'+p},storage:{local:storage}};
 async function open(){const store=new LibraryDocumentsStore(storage,{indexedDB:factory});stores.push(store);if(!(await store.status()).consented)await store.consent(true);await store.finishFoundation();const owner=await createConfiguredSyncLifecycle(store,api);owners.push(owner);return {store,owner,core:store.sourceBootstrapJournal.core};}
 t.after(async()=>{owners.forEach(owner=>owner.suspend());stores.forEach(store=>store.repository.db?.close());delete globalThis[key];await rm(path,{recursive:true,force:true});});return {open,async cold(x){x.owner.suspend();await x.store.repository.close();return open();}};
}
test('preclassification restore failure performs no unticketed failure write',async t=>{
 const f=await fixture(t),storage=local(),set=storage.set.bind(storage);let failureWrites=0;
 storage.set=async values=>{if(values[lifecycleRow]?.task?.phase==='unknown')failureWrites++;return set(values);};
 const broken={request:async()=>{throw Error('SYNTHETIC listing unavailable');}},service=await lifecycle(t,broken,storage),c=await service.open();await lifecycleCommand(c.owner,'RESUME');
 await assert.rejects(lifecycleCommand(c.owner,'RESTORE'));assert.equal(failureWrites,0);const row=(await storage.get(lifecycleRow))[lifecycleRow];assert.equal(row.task.phase,'reserved');
});
test('cold activated union refusal performs no unticketed failure write',async t=>{
 const f=await fixture(t),storage=local(),set=storage.set.bind(storage);let armed=false,lateWrites=0;
 storage.set=async values=>{if(armed&&values[lifecycleRow])lateWrites++;return set(values);};
 const service=await lifecycle(t,f.cloud,storage),c=await service.open();await lifecycleCommand(c.owner,'RESUME');await lifecycleCommand(c.owner,'RESTORE');const saved=(await storage.get(lifecycleRow))[lifecycleRow];
 await c.core.transaction(true,async tx=>{const row=(await tx.all('records'))[0];row.value.originalText='SYNTHETIC altered';await tx.put('records',row);});armed=true;
 await assert.rejects(lifecycleCommand(c.owner,'CONTINUE'));assert.equal(lateWrites,0);assert.deepEqual((await storage.get(lifecycleRow))[lifecycleRow],saved);
});
