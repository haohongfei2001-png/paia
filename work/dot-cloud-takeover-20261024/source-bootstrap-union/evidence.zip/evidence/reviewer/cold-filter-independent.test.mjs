import test from 'node:test';
import assert from 'node:assert/strict';
import {IDBFactory,IDBKeyRange} from './vendor/fake-indexeddb/build/esm/index.js';
import {LibraryFoundationStore} from '../core/thought-store.js';
import {local,capture} from './harness/thought-m1.mjs';
import {BrowserNativeSyncCore} from '../core/browser-native-sync/core.js';
import {SourceBootstrapJournal} from '../core/browser-native-sync/source-bootstrap-journal.js';
import {buildGroupedCheckpoint,GroupedCheckpointRestore,requireActivatedSourceBootstrapUnion} from '../core/browser-native-sync/group-checkpoint.js';
import {prepareSourceBootstrapUnion,readSourceBootstrapUnionProof} from '../core/browser-native-sync/source-bootstrap-union.js';
import {createOriginalRecoveryWork,withOriginalRecoveryWork,finishOriginalRecoveryWork} from '../core/idb-repository.js';
import {assertCompletedGroupedRestoreControl} from '../core/browser-native-sync/completed-group-restore-control.js';
globalThis.IDBKeyRange=IDBKeyRange;
const datasetId='synthetic_union_restore';
const cloud=()=>{const rows=new Map();return {rows,async putImmutable(ref,body){rows.set(ref.id,body.slice());},async get(ref){return rows.get(ref.id)?.slice();}};};
async function fresh(device,storage=local(),indexedDB=new IDBFactory()){
 const store=new LibraryFoundationStore(storage,{indexedDB});await store.consent(true);await store.finishFoundation();const core=new BrowserNativeSyncCore(store.repository,{datasetId,deviceId:device});return {store,core,storage,indexedDB};
}
async function addSource(target,label,text='Synthetic '+label){target.store.sourceBootstrapJournal=new SourceBootstrapJournal(target.core);const request=capture((await target.store.status()).epoch,'union_message_'+label,text);request.chat={id:'union_chat_'+label,url:'https://chatgpt.com/c/union_chat_'+label,title:'Synthetic '+label};await target.store.capture(request);}
async function fixture(text){
 const transport=cloud(),ancestor=await fresh('union_ancestor');await addSource(ancestor,'ancestor',text);const base=await buildGroupedCheckpoint(ancestor.core,transport,{store:ancestor.store}),heads=[];
 for(const label of ['left','right']){const branch=await fresh('union_branch_'+label),restore=new GroupedCheckpointRestore(branch.core,{store:branch.store,restoreId:'union_branch_restore_'+label});await restore.stageCheckpoint(base.ref,r=>transport.get(r));await restore.activate();await addSource(branch,label,text);heads.push(await buildGroupedCheckpoint(branch.core,transport,{store:branch.store,parents:[base.ref.id]}));}
 return {transport,base,heads};
}
async function window(target,action,options){const ticket=createOriginalRecoveryWork(target.core.repository,options);try{return await withOriginalRecoveryWork(target.core.repository,ticket,()=>action(ticket));}finally{finishOriginalRecoveryWork(target.core.repository,ticket);}}
async function proofFor(target,f){return prepareSourceBootstrapUnion(target.core,{store:target.store,ancestorRef:f.base.ref,headRefs:f.heads.map(x=>x.ref),get:r=>f.transport.get(r)});}
const state=target=>target.store.repository.transaction(false,async t=>Object.fromEntries(await Promise.all([...t.tx.objectStoreNames].map(async name=>[name,await t.all(name)]))));
async function staged(f=undefined,checkpoint){f??=await fixture();const target=await fresh('union_receiver'),restoreId='union_restore_target',restore=new GroupedCheckpointRestore(target.core,{store:target.store,restoreId,...(checkpoint?{checkpoint}:{})});await window(target,async()=>restore.stageSourceBootstrapUnion(await proofFor(target,f)));return {...f,target,restoreId,restore};}
function freeze(x){if(x&&typeof x==='object'){Object.values(x).forEach(freeze);Object.freeze(x);}return x;}

import {FilterRunner} from '../core/filter-runner.js';
test('original FilterRunner advances backup generation by three without changing exact Source owners',async()=>{
 const x=await staged();await window(x.target,()=>x.restore.activate());const before=await state(x.target);const base=before.meta.find(row=>row.id==='backup-data-generation').value;
 await new FilterRunner(x.target.store).wake();const after=await state(x.target);const next=after.meta.find(row=>row.id==='backup-data-generation').value;
 assert.equal(next,base+3);assert.deepEqual(after.records,before.records);assert.deepEqual(after.inputStates,before.inputStates);assert.deepEqual(after.revisions,before.revisions);await window(x.target,()=>requireActivatedSourceBootstrapUnion(x.target.core,{store:x.target.store}));
});
for(const mutation of ['filterOverride','userEdited','aiDecision'])test('cold union rejects changed filter visibility intent '+mutation,async()=>{
 const x=await staged();await window(x.target,()=>x.restore.activate());
 await x.target.store.repository.transaction(true,async t=>{const row=(await t.all('filterInputs'))[0];if(mutation==='filterOverride')row.filterOverride='keep';else if(mutation==='userEdited')row.userEdited=true;else row.aiDecision={decision:'filter',reason:'synthetic'};await t.put('filterInputs',row);});
 const before=await state(x.target);await assert.rejects(window(x.target,()=>requireActivatedSourceBootstrapUnion(x.target.core,{store:x.target.store})));assert.deepEqual(await state(x.target),before);
});
