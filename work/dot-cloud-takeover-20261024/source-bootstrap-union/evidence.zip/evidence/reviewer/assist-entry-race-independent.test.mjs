import test from 'node:test';
import assert from 'node:assert/strict';
import {setup} from './harness/thought-m1.mjs';
import {OrganizerStore} from '../core/organizer/store.js';
import {AssistReplyLease} from '../background/assist-reply-lease.js';
import {LocalAssistSession} from '../core/ai-usage/local-assist-session.js';
import {AssistResultController} from '../content/assist-result.js';
import {validateAssistResponse} from '../core/ai-usage/assist-response.js';
import {ContextCardsService} from '../core/context-cards.js';
import {readDomainCommitEvidence} from '../core/ai-usage/domain-commit-evidence.js';
import {invalidateSemanticJobs} from '../core/ai-usage/semantic-invalidation.js';
const authority=async(_t,r)=>({allowed:true,principalId:'synthetic',libraryId:'synthetic',consentEpoch:'synthetic',jobTypes:['AI_ASSIST'],scope:{evidenceKeys:r.evidenceKeys,coverage:r.coverage}});
const suggestion=JSON.stringify({version:1,kind:'SUGGESTION',text:'Explain the next step.',condition:''});
const all=s=>s.repository.transaction(false,async t=>Object.fromEntries(await Promise.all([...t.tx.objectStoreNames].map(async n=>[n,await t.all(n)]))));
async function fixture({ids=[],output=suggestion,unsubscribeError=null,interferingSubscriber=false,intent='explicit',automatic=false}={}){
 const {s}=await setup(OrganizerStore);await s.finishFoundation();let now=1000,calls=0;
 const sender={id:'synthetic-extension',tab:{id:1},frameId:0,documentId:'synthetic-document',documentLifecycle:'active',url:'https://chatgpt.com/c/synthetic'};
 const binding={url:sender.url,conversation:'/c/synthetic',cycle:1,replyId:'reply-one',revision:1};
 const snapshot={completed:true,text:'Synthetic current completed answer.',blocks:1,excluded:false};
 const live={binding,snapshot};
 const lease=new AssistReplyLease({runtimeId:sender.id,tabs:{get:async()=>({url:sender.url,incognito:false,active:true})},probe:async(_host,{snapshot:read})=>({ready:true,binding:structuredClone(live.binding),...(read?{snapshot:structuredClone(live.snapshot)}:{})}),current:(_host,b)=>JSON.stringify(b)===JSON.stringify(live.binding),clock:()=>now});
 lease.configure({replyAccess:true,remoteProcessing:true,automatic});
 const provider={describe:()=>({providerId:'synthetic',version:'1',executionKind:'fixture'}),execute:async()=>{calls++;return output;}};
 if(interferingSubscriber){const subscribe=lease.onInvalidate.bind(lease);let removeSession;subscribe(()=>removeSession?.());lease.onInvalidate=fn=>{removeSession=subscribe(fn);return removeSession;};}
 if(unsubscribeError){const subscribe=lease.onInvalidate.bind(lease);lease.onInvalidate=fn=>{const remove=subscribe(fn);return ()=>{remove();throw unsubscribeError;};};}
 const contextAbort=new AbortController(),contextExpires=Date.now()+600000,contextProcessing={resolve:async(_t,scope)=>({version:1,store:s,scope,epoch:'synthetic-context-processing',processing:true,expiresAt:contextExpires,revocationSignal:contextAbort.signal}),isCurrent:()=>!contextAbort.signal.aborted};
 const session=new LocalAssistSession(s,{lease,provider,intent,resolveAuthority:authority,contextSelector:()=>ids,contextProcessing,clock:()=>now});
 const cap=await lease.observe(sender);return {s,lease,session,cap,sender,live,provider,ids,contextProcessing,revokeContext:()=>contextAbort.abort(),calls:()=>calls,time:x=>now=x};
}

for (const delayFinalQualification of [false, true]) test('original bounded Assist '+(delayFinalQualification?'pre-entry timeout reproduces unowned entered promise':'provider-entry control settles after genuine cancellation'), async()=>{
 const f=await fixture();f.s.organizerBudget.limits.timeoutMs=25;
 let enter,release,physicalCalls=0,qualifiedReads=0,enteredFlag=false;
 const entered=new Promise(r=>enter=()=>{enteredFlag=true;r();}),held=new Promise(r=>release=r);
 f.provider.execute=()=>{physicalCalls++;enter();return held;};
 const handle=await f.session.prepare({lease:f.cap});
 const read=f.session.foundation.read.bind(f.session.foundation);
 f.session.foundation.read=async fn=>{
  if(fn.toString().includes('const job=await this.foundation.job(t,s.job.id)')){
   qualifiedReads++;
   if(delayFinalQualification&&qualifiedReads===3)await new Promise(r=>setTimeout(r,60));
  }
  return read(fn);
 };
 const running=f.session.run(handle).then(value=>({kind:'fulfilled',value}),error=>({kind:'rejected',error}));
 if(!delayFinalQualification){await Promise.race([entered,running.then(r=>assert.fail('unexpected pre-entry settlement '+r.error?.code))]);f.session.dispose();}
 const result=await running;
 assert.equal(result.kind,'rejected');
 assert.equal(result.error.code,delayFinalQualification?'OUTCOME_UNKNOWN':'STALE_BASE');
 const rows=await all(f.s);
 assert.equal(rows.organizerUsage[0].state,'OUTCOME_UNKNOWN');
 assert.equal(rows.organizerUsage[0].attemptCount,1);
 assert.equal(rows.organizerUsage[0].spendState,'RESERVATION_RETAINED');
 assert.equal(rows.organizerWorkItems.length,0);
 assert.equal(physicalCalls,delayFinalQualification?0:1);
 assert.equal(enteredFlag,!delayFinalQualification);
 if(delayFinalQualification){
  assert.equal(await Promise.race([entered.then(()=> 'entered'),Promise.resolve('pending')]),'pending','original owning fixture would remain waiting at await entered after run already rejected');
  await new Promise(r=>setTimeout(r,70));assert.equal(physicalCalls,0,'late qualified read cannot enter physical provider');
 }
 release(suggestion);f.session.dispose();
});
