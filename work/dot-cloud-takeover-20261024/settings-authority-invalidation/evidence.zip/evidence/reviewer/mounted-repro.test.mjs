import test from 'node:test';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
const source=process.env.REVIEW_SOURCE;
if(!source)throw Error('REVIEW_SOURCE required');
const {mountSettingsAssist}=await import(pathToFileURL(`${source}/extension/ui/settings-assist.js`));
const {PresentationNode}=await import(pathToFileURL(`${source}/extension/tests/harness/presentation-dom.mjs`));
const snapshot=(extra={})=>({replyAccess:false,remoteProcessing:false,serviceAvailable:true,generation:'g1',...extra});
const defer=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});return {promise,resolve,reject};};
const tick=()=>new Promise(r=>setImmediate(r));
async function fixture(body){
 const before=globalThis.document,created=[];
 const make=tag=>{const n=new PresentationNode(tag);created.push(n);n.getClientRects=()=>[{}];if(tag==='dialog'){n.showModal=()=>{n.open=true;};n.close=()=>{n.open=false;n.listeners.get('close')?.();};}return n;};
 globalThis.document={body:make('body'),createElement:make};
 try{await body({make,get:id=>created.find(n=>n.id===id)});}finally{if(before)globalThis.document=before;else delete globalThis.document;}
}
for(const event of ['storage','runtime'])for(const field of ['replyAccess','remoteProcessing'])test(`reviewer mounted ${event} event invalidates old ${field} immediately`,async()=>fixture(async({make,get})=>{
 const held=defer(),calls=[];let reads=0,storage,runtime;
 const host=make('section');document.body.append(host);
 const owner=mountSettingsAssist(host,{language:()=> 'en',storage:{onChanged:{addListener:f=>{storage=f;}}},runtime:{onMessage:{addListener:f=>{runtime=f;}}},send:async(type,fields)=>{calls.push({type,fields});if(type.endsWith('CONFIGURE'))return snapshot({[field]:false,generation:'unexpected-write'});return ++reads===1?snapshot({[field]:true}):held.promise;}});
 await tick();assert.equal(owner.state.editable,true);
 try{
  if(event==='storage')storage({promptAssistAutomaticPreferenceV2:{newValue:{generation:'g2'}}},'local');else runtime({type:'PAIA_PROMPT_ASSIST_CHANGED'});
  assert.equal(owner.state.editable,false,'an explicit authority event must synchronously fence old acknowledged g1');
  assert.equal(get('settings-assist-replyAccess').disabled,true);
  assert.equal(get('settings-assist-remoteProcessing').disabled,true);
  assert.equal(await owner.state.configure(field,false),false);
  assert.equal(calls.filter(x=>x.type.endsWith('CONFIGURE')).length,0);
 }finally{held.resolve(snapshot({generation:'g2-revoked'}));await tick();}
 assert.equal(owner.state.value.generation,'g2-revoked');assert.equal(owner.state.editable,true);
}));
