import test from 'node:test';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
const source=process.env.REVIEW_SOURCE;
if(!source)throw Error('REVIEW_SOURCE required');
const {mountSettingsAssist}=await import(pathToFileURL(`${source}/extension/ui/settings-assist.js`));
const {PresentationNode}=await import(pathToFileURL(`${source}/extension/tests/harness/presentation-dom.mjs`));
const snapshot=(extra={})=>({replyAccess:false,remoteProcessing:false,serviceAvailable:true,generation:'g1',...extra});
const defer=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});return {promise,resolve,reject};};
const tick=()=>new Promise(r=>setImmediate(r));
async function fixture(body){
 const before=globalThis.document,created=[],reads=[],writes=[];let runtime,storage;
 const make=tag=>{const n=new PresentationNode(tag);created.push(n);n.getClientRects=()=>[{}];if(tag==='dialog'){n.showModal=()=>{n.open=true;};n.close=()=>{n.open=false;n.listeners.get('close')?.();};}return n;};
 globalThis.document={body:make('body'),createElement:make};const host=make('section');document.body.append(host);
 const owner=mountSettingsAssist(host,{language:()=> 'en',storage:{onChanged:{addListener:f=>{storage=f;}}},runtime:{onMessage:{addListener:f=>{runtime=f;}}},send:(type,fields)=>{const held=defer();(type.endsWith('STATUS')?reads:writes).push({held,fields});return held.promise;}});
 try{reads[0].held.resolve(snapshot());await tick();await body({owner,reads,writes,host,make,get:id=>created.find(n=>n.id===id),runtime:()=>runtime({type:'PAIA_PROMPT_ASSIST_CHANGED'}),storage:()=>storage({promptAssistAutomaticPreferenceV2:{}},'local')});}
 finally{for(const x of [...reads,...writes])x.held.resolve(snapshot());await tick();if(before)globalThis.document=before;else delete globalThis.document;}
}
test('reviewer old plain read cannot unlock explicit authority event, and its late rejection is inert',async()=>fixture(async({owner,reads,writes,runtime})=>{
 const old=owner.refresh();runtime();assert.equal(owner.state.editable,false);
 assert.equal(reads.length,3);reads[2].held.resolve(snapshot({generation:'g2-revoked'}));await tick();assert.equal(owner.state.editable,true);assert.equal(owner.state.value.generation,'g2-revoked');
 reads[1].held.reject(Error('old refresh denied'));await old;assert.equal(owner.state.error,false);assert.equal(owner.state.value.generation,'g2-revoked');assert.equal(writes.length,0);
}));
test('reviewer pre-event plain success while authority read is held remains noneditable',async()=>fixture(async({owner,reads,writes,storage})=>{
 const old=owner.refresh();storage();reads[1].held.resolve(snapshot({replyAccess:true,generation:'old-plain'}));await old;
 assert.equal(owner.state.editable,false);assert.notEqual(owner.state.value.generation,'old-plain');assert.equal(await owner.state.configure('replyAccess',true),false);assert.equal(writes.length,0);
 reads[2].held.resolve(snapshot({generation:'g2-revoked'}));await tick();assert.equal(owner.state.value.generation,'g2-revoked');assert.equal(owner.state.editable,true);
}));
test('reviewer already-open consent cannot write during authority settlement',async()=>fixture(async({owner,reads,writes,runtime,get,make})=>{
 const control=get('settings-assist-remoteProcessing'),dialog=get('settings-assist-consent'),confirm=get('settings-assist-confirm');control.checked=true;control.listeners.get('change')({isTrusted:true});assert.equal(dialog.open,true);
 const draft=make('textarea');draft.value='A synthetic unsent draft';draft.selectionStart=2;draft.selectionEnd=7;document.body.append(draft);draft.focus();
 runtime();confirm.listeners.get('click')({isTrusted:true});assert.equal(writes.length,0);assert.equal(owner.state.editable,false);
 reads[1].held.resolve(snapshot({generation:'g2-revoked'}));await tick();assert.equal(writes.length,0);assert.equal(draft.value,'A synthetic unsent draft');assert.equal(draft.selectionStart,2);assert.equal(draft.selectionEnd,7);assert.equal(document.activeElement,draft);
}));
test('reviewer authority event from synchronous settled-read observer cannot expose an editable intermediate',async()=>fixture(async({owner,reads,writes,runtime,storage})=>{
 const original=owner.state.changed,attempts=[],exposed=[];let renewed=false;
 owner.state.changed=state=>{original(state);if(state.value?.generation==='intermediate'&&!renewed){renewed=true;storage();attempts.push(state.configure('replyAccess',true));}if(state.editable)exposed.push(state.value?.generation);};
 runtime();reads[1].held.resolve(snapshot({replyAccess:true,generation:'intermediate'}));await tick();assert.equal(renewed,true);assert.equal(owner.state.editable,false);assert.equal(reads.length,3);assert.deepEqual(await Promise.all(attempts),[false]);assert.equal(writes.length,0);assert.equal(exposed.includes('intermediate'),false);
 reads[2].held.resolve(snapshot({generation:'final-revoked'}));await tick();assert.equal(owner.state.editable,true);assert.equal(owner.state.value.generation,'final-revoked');
}));
for(const response of ['deny','malformed'])test(`reviewer ${response} authority read holds admission closed across a later pending refresh`,async()=>fixture(async({owner,reads,writes,runtime})=>{
 runtime();if(response==='deny')reads[1].held.reject(Error('ACCESS_DENIED'));else reads[1].held.resolve({replyAccess:false});await tick();assert.equal(owner.state.editable,false);assert.equal(owner.state.error,true);
 const recovery=owner.refresh();assert.equal(owner.state.editable,false);assert.equal(await owner.state.configure('replyAccess',true),false);assert.equal(writes.length,0);reads[2].held.resolve(snapshot({generation:'explicit-recovery'}));assert.equal(await recovery,true);assert.equal(owner.state.editable,true);assert.equal(owner.state.value.generation,'explicit-recovery');
}));
test('reviewer admitted save ACK remains fenced until a later authority revocation read settles',async()=>fixture(async({owner,reads,writes,runtime,storage})=>{
 const save=owner.state.configure('replyAccess',true);runtime();writes[0].held.resolve(snapshot({replyAccess:true,generation:'save-ack'}));await tick();assert.equal(owner.state.editable,false);assert.equal(reads.length,2);
 storage();reads[1].held.resolve(snapshot({replyAccess:true,generation:'pre-revoke'}));await tick();assert.equal(reads.length,3);assert.equal(owner.state.editable,false);assert.equal(await owner.state.configure('remoteProcessing',true),false);assert.equal(writes.length,1);
 reads[2].held.resolve(snapshot({generation:'finally-revoked'}));assert.equal(await save,true);assert.equal(owner.state.value.generation,'finally-revoked');assert.equal(owner.state.value.replyAccess,false);assert.equal(owner.state.editable,true);
}));
