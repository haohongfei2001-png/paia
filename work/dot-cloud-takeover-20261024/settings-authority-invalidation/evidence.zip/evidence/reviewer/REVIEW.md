# Settings Assist authority invalidation: independent review

Result: PASS, no blocking findings in the frozen runtime and test patch.

Base: d7604d8d1f7f22563734f0a5349493c8ffc55fab.
Author worktree: ../settings-authority-invalidation-20261024.
Review completed 2026-10-24 UTC. This review made no production, root, or author-test edits.

## Reproduction and validation

- Independently reproduced the gap through the actual mounted storage and runtime callbacks in the existing synthetic PresentationNode fixture. Four combinations of listener and permission all failed immediately on the exact base: acknowledged g1 remained editable after an explicit authority change while its STATUS response was held. Preserve baseline-first-failure.log as a failure, not passing evidence.
- Reused the same four reviewer controls unchanged on the fixed patch. All passed.
- Final exact-byte run passed 47/47, with zero failures, cancellations, skips or todos: unchanged original 17 Settings Assist tests, author 19 added authority-invalidation tests, and reviewer 11 tests. This is one overlapping combined suite, not additive to the author's 53-test suite.
- The seven other reviewer controls exercise stale ordinary-read success and rejection, already-open consent, a synchronous settled-read observer raising a newer authority event, denied and malformed reads through pending explicit recovery, and an old admitted save ACK followed by two revocations.
- Static inspection verified the original load/configure admission and CAS payload are unchanged; backend AssistConsent generation and stored-row CAS remain unchanged. The new invalidation route increments the existing read epoch, immediately marks the owner busy before emitting, coalesces pending reads, and keeps both switches and confirmation nonactionable until current authority settles. Rejected or malformed current reads keep error=true and editability false. Ordinary load remains intentionally supersedable by a newer configure ACK.
- Source hashes matched the author freeze before and after the final run. git diff --check passed. The new test file is automatically discovered by scripts/test.mjs.

## Exact frozen source hashes

- extension/ui/settings-assist-state.js: 317d4ccce00fd5c9c378fa826ad67006c7f953b3a43b5f0aeb225b22e564db18
- extension/ui/settings-assist.js: 608cb002a536d273689b74bc7ed3403491423faedf80406f30d3a354b24733b2
- extension/tests/settings-assist-authority-invalidation.test.mjs: e26a397e4cae6b7e8fb7f65f48de461ab1d24cd6dbba133b7296e02de3e226db
- Unchanged extension/tests/settings-assist-state.test.mjs: 0a6b67f609f9cef965bc39b325061fe738b365dd334902b654f5ab0db0c02a2a
- frozen-runtime.patch: e42b9e2b68c6d6c7b026951d6309612aad26c7e12e6363e135f798452bfdf6c4

## Preserved independent evidence

- mounted-repro.test.mjs: c9db1e642883e76a83096da09c269add43d2ccfcf22d42a31993f589693b34bc
- ordering-controls.test.mjs: 4d2c5ed8e0578bdea7dfeff88e4386fa091a2f9e33e98cf5fa6a2e281450353d
- baseline-first-failure.log: 8383d6a2ff316728d867bcd03d4bacbccc3761d7548d9e01fda2263caa3ad066 (0 PASS, 4 FAIL, Node exit 1)
- candidate-exploratory-first.log: 02d2ee004049b44e34546a80361019ba559054f8fe1d08805125895e06269d0e (11 PASS, Node exit 0; exploratory, not final)
- final-exact-review.tap: de9eca494844dc9e09bff1fc0042f46ff8085e636ad9057e74de46312bd30ed0 (47 PASS, Node exit 0)
- final-source.before.sha256 and final-source.after.sha256 are identical: 49672be04d731f40c5cae8c96bf312286c604818e113aff92da7291944d7cf19.

The author's separately preserved first-red.tap is b275d6e9b515612c1d702dcd55fec947c421407420d21414e64f0a99b3975509. Its first two mounted-listener failures remain failures. Author-reported final-related.tap (53 PASS) and static package check are retained under the author worktree; this reviewer independently executed only the 47-test exact-byte combination above.

## Limits

This is production-function and mounted-listener behavior under a synthetic presentation fixture. It is not actual browser DOM, visual, native, installed, provider, exact-main, or Full certification. No network, account, paid, activation, Sync, browser, installation, deployment, remote, 129-group, 100k or old-C work was performed. No denied or uncertain action occurred. Further release or integration acceptance remains with its existing owner.
