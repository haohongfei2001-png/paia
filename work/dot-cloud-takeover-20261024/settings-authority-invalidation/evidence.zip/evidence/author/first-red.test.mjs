import test from 'node:test';
import assert from 'node:assert/strict';
import {mountSettingsAssist} from '../ui/settings-assist.js';
import {PresentationNode} from './harness/presentation-dom.mjs';

const snapshot=(fields={})=>({replyAccess:false,remoteProcessing:false,serviceAvailable:true,generation:'g1',...fields});
const deferred=()=>{let resolve,reject;const promise=new Promise((yes,no)=>{resolve=yes;reject=no;});return {promise,resolve,reject};};
const tick=()=>new Promise(resolve=>setImmediate(resolve));
function mount(send){
 const previous=globalThis.document,created=[],make=tag=>{const node=new PresentationNode(tag);created.push(node);node.getClientRects=()=>[{}];if(tag==='dialog'){node.showModal=()=>{node.open=true;};node.close=()=>{node.open=false;node.listeners.get('close')?.();};}return node;};
 const body=make('body');globalThis.document={body,createElement:make};const host=make('section'),draft=make('textarea');draft.value='Unsent human draft';draft.selectionStart=3;draft.selectionEnd=8;body.append(host,draft);let storageChanged,runtimeChanged;
 const owner=mountSettingsAssist(host,{send,language:()=> 'en',storage:{onChanged:{addListener:fn=>{storageChanged=fn;}}},runtime:{onMessage:{addListener:fn=>{runtimeChanged=fn;}}}});
 const get=id=>created.find(node=>node.id===id),reply=get('settings-assist-replyAccess'),remote=get('settings-assist-remoteProcessing');
 return {owner,draft,reply,remote,get,storage:(changes={promptAssistAutomaticPreferenceV2:{}},area='local')=>storageChanged(changes,area),runtime:(message={type:'PAIA_PROMPT_ASSIST_CHANGED'})=>runtimeChanged(message),close:()=>{globalThis.document=previous;}};
}
function assertLocked(ui){
 for(const control of [ui.reply,ui.remote]){assert.equal(control.disabled,true,'an external authority change must immediately disable both original switches');assert.equal(control.getAttribute('aria-busy'),'true');}
 assert.equal(ui.owner.state.editable,false);
}
function assertDraft(ui){assert.equal(ui.draft.value,'Unsent human draft');assert.equal(ui.draft.selectionStart,3);assert.equal(ui.draft.selectionEnd,8);assert.equal(document.activeElement,ui.draft);}

for(const source of ['storage','runtime'])test(`idle ${source} authority notification fences the real mounted switches before its deferred read settles`,async()=>{
 const held=deferred(),calls=[];let reads=0;const ui=mount(async(type,fields)=>{calls.push({type,fields});if(type.endsWith('CONFIGURE'))return snapshot({generation:'unexpected-write'});return ++reads===1?snapshot({replyAccess:true,remoteProcessing:true}):held.promise;});
 try{
  await tick();assert.equal(ui.reply.disabled,false);ui.draft.focus();ui[source]();
  assert.equal(reads,2,'the actual listener must reach the production STATUS read');assertLocked(ui);assert.equal(ui.owner.state.value.generation,'g1');
  for(const control of [ui.reply,ui.remote]){control.checked=false;control.listeners.get('change')({isTrusted:true});assert.equal(control.checked,true,'retain the acknowledged display while authority is unknown');}
  assert.equal(await ui.owner.state.configure('replyAccess',false),false);assert.equal(calls.filter(call=>call.type.endsWith('CONFIGURE')).length,0);assertDraft(ui);
  held.resolve(snapshot({generation:'revoked'}));await tick();assert.equal(ui.owner.state.value.generation,'revoked');assert.equal(ui.reply.checked,false);assert.equal(ui.remote.checked,false);assert.equal(ui.reply.disabled,false);assert.equal(ui.remote.disabled,false);assert.equal(ui.reply.getAttribute('aria-busy'),'false');assertDraft(ui);
 }finally{held.resolve(snapshot({generation:'cleanup'}));await tick();ui.close();}
});
