import {ArchiveError} from '../core/constants.js';
import {originalRestrictedRepositoryTransaction,createOriginalRecoveryWork,checkOriginalRecoveryWork,chargeOriginalRecoveryWork} from '../core/idb-repository.js';
import {requireOriginalLibraryDocumentsGenerationMethods} from '../core/library-documents-owner.js';
import {PromptReuseCommands} from './prompt-reuse-commands.js';
import {AssistPromptCommands} from './prompt-assist.js';
import {NextPromptCommands} from './prompt-next.js';
import {PROMPT_INSERTION_RUNTIME,PROMPT_INSERTION_LIMITS,promptInsertionEncoding,validPromptInsertionEnvelope,validatePromptInsertionRuntimeRow as validateRow} from '../core/prompt-insertion-runtime-format.js';
export {PROMPT_INSERTION_RUNTIME,PROMPT_INSERTION_LIMITS,promptInsertionEncoding,validPromptInsertionEnvelope} from '../core/prompt-insertion-runtime-format.js';

// Nonportable original-operation evidence, not content, a replay queue, a grant,
// a cold absence proof or application-selection authority.
const prototypes={manual:PromptReuseCommands.prototype,assist:AssistPromptCommands.prototype,next:NextPromptCommands.prototype};
const sourceMethods=Object.fromEntries(Object.entries(prototypes).map(([lane,p])=>[lane,p.insertionReceiptSourceIs]));
const uuid=v=>typeof v==='string'&&/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/.test(v);
const hash=v=>typeof v==='string'&&/^[a-f0-9]{64}$/.test(v);
const integer=v=>Number.isSafeInteger(v)&&v>=0;
const id=v=>typeof v==='string'&&v.length>0&&v.length<=128;
const fail=(code='PROMPT_INSERTION_STALE')=>{throw new ArchiveError(code);};
const exact=(v,keys)=>v&&Object.getPrototypeOf(v)===Object.prototype&&Reflect.ownKeys(v).length===keys.length&&keys.every(k=>Object.hasOwn(Object.getOwnPropertyDescriptors(v)[k]??{},'value'));
const same=(a,b)=>promptInsertionEncoding(a)===promptInsertionEncoding(b);
export async function promptInsertionDigest(v){const bytes=new TextEncoder().encode(promptInsertionEncoding(v));if(bytes.length>1024*1024)fail('RESOURCE_LIMIT');return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),x=>x.toString(16).padStart(2,'0')).join('');}
const receiverKeys=['tabId','windowId','documentId','nonce'];
const validReceiver=r=>exact(r,receiverKeys)&&integer(r.tabId)&&integer(r.windowId)&&id(r.documentId)&&uuid(r.nonce);
const actionKeys=['version','actionId','operationId','receiptEpoch'];
const validAction=a=>exact(a,actionKeys)&&a.version===1&&[a.actionId,a.operationId,a.receiptEpoch].every(uuid);
const validAck=a=>exact(a,['version','envelope','outcome'])&&a.version===1&&validPromptInsertionEnvelope(a.envelope)&&['inserted','not_inserted','unknown'].includes(a.outcome);
const claimTerminal=c=>c.state!=='pending';
function retired(row,epoch){return epoch<=row.retiredEpochFloor||row.retiredRanges.some(r=>epoch>=r.start&&epoch<=r.end);}
function retire(row,numbers){const ranges=[...row.retiredRanges,...numbers.map(epoch=>({start:epoch,end:epoch}))].sort((a,b)=>a.start-b.start),merged=[];for(const r of ranges){const prior=merged.at(-1);if(prior&&r.start<=prior.end+1)prior.end=Math.max(prior.end,r.end);else merged.push({...r});}row.epochs=row.epochs.filter(e=>!numbers.includes(e.epoch));while(merged[0]?.start===row.retiredEpochFloor+1)row.retiredEpochFloor=merged.shift().end;row.retiredRanges=merged;row.claims=row.claims.filter(c=>!claimTerminal(c)||!retired(row,c.envelope.epoch));}
const site=url=>{try{const u=new URL(url);return u.origin==='https://chatgpt.com';}catch{return false;}};
const budgetClock=globalThis.performance.now.bind(globalThis.performance);
const OriginalPromise=Promise,originalThen=Promise.prototype.then,originalResolve=Promise.resolve,originalApply=Reflect.apply;
const originalObserve=(promise,resolve,reject)=>originalApply(originalThen,promise,[resolve,reject]);
const originalResolveValue=value=>originalApply(originalResolve,OriginalPromise,[value]);
const originalNext=(promise,fn)=>new OriginalPromise((resolve,reject)=>{try{originalObserve(promise,()=>{try{originalObserve(originalResolveValue(fn()),resolve,reject);}catch(error){reject(error);}},reject);}catch(error){reject(error);}});
const originalIgnore=promise=>new OriginalPromise(resolve=>{try{originalObserve(promise,resolve,resolve);}catch{resolve();}});
const originalRace=tasks=>new OriginalPromise((resolve,reject)=>{for(const task of tasks)try{originalObserve(task,resolve,reject);}catch(error){reject(error);}});
const originalAllSettled=tasks=>new OriginalPromise(resolve=>{let remaining=tasks.length;if(!remaining)return resolve();for(const task of tasks){const done=()=>{if(--remaining===0)resolve();};try{originalObserve(task,done,done);}catch{done();}}});
const messageTypes={manual:'PAIA_PROMPT_INSERT_SELECTED',assist:'PAIA_PROMPT_ASSIST_INSERT',next:'PAIA_PROMPT_NEXT_INSERT'};
function probeCurrentPromptTopDocument(){return {origin:location.origin,top:globalThis.top===globalThis};}
export class PromptInsertionReceipts {
 #store;#repository;#database;#databaseId;#api;#tabs;#runtime;#send;#get;#runtimeId;#restoreEpoch;#domainDigest;#bindingTask=null;#birthGeneration=null;#origin=null;#disposed=false;#rotating=false;#receiptEpoch=crypto.randomUUID();#epoch=0;#epochTask=null;#liveRetirement=null;#producers=new Map();#caps=new WeakMap();#actions=new Map();#events=new WeakMap();#receivers=new Map();#tasks=new Set();#tail=originalResolveValue();#selectionHold=null;#trackingUnknown=false;#receiverVersion=0;#knownDocumentHold=null;#topDocumentHold=null;#inventorySource=null;#topologyVersion=0;
 constructor(store,api){requireOriginalLibraryDocumentsGenerationMethods(store);if(!store.repository?.db||typeof api?.tabs?.sendMessage!=='function'||typeof api?.tabs?.get!=='function'||!id(api?.runtime?.id))fail('PROMPT_INSERTION_CAPABILITY');this.#store=store;this.#repository=store.repository;this.#database=store.repository.db;this.#databaseId=store.databaseId;this.#api=api;this.#tabs=api.tabs;this.#runtime=api.runtime;this.#send=api.tabs.sendMessage;this.#get=api.tabs.get;this.#runtimeId=api.runtime.id;this.#inventoryInstall();void this.#initializeBinding().catch(()=>{});}
 #identity(){requireOriginalLibraryDocumentsGenerationMethods(this.#store);if(this.#disposed||this.#store.repository!==this.#repository||this.#repository.db!==this.#database||this.#store.databaseId!==this.#databaseId||this.#api.tabs!==this.#tabs||this.#api.runtime!==this.#runtime||this.#api.tabs.sendMessage!==this.#send||this.#api.tabs.get!==this.#get||this.#api.runtime.id!==this.#runtimeId)fail();}
 #producer(cap){this.#identity();const p=this.#caps.get(cap),method=p&&sourceMethods[p.lane];if(!p||Object.getPrototypeOf(p.owner)!==prototypes[p.lane]||typeof method!=='function'||originalApply(method,p.owner,[this,this.#store])!==true)fail('PROMPT_INSERTION_CAPABILITY');return p;}
 registerProducer(lane,owner){this.#admit();const method=sourceMethods[lane];if(!Object.hasOwn(prototypes,lane)||typeof method!=='function'||Object.getPrototypeOf(owner)!==prototypes[lane]||originalApply(method,owner,[this,this.#store])!==true||this.#producers.has(lane))fail('PROMPT_INSERTION_CAPABILITY');const cap=Object.freeze(Object.create(null)),p={lane,owner,cap};this.#producers.set(lane,p);this.#caps.set(cap,p);return cap;}
 admissionEpoch(cap){this.#admit();this.#producer(cap);if(this.#rotating)fail();return this.#receiptEpoch;}
 digest(value){return promptInsertionDigest(value);}
 #track(promise){const task=new OriginalPromise((resolve,reject)=>{try{originalObserve(promise,resolve,reject);}catch(error){this.#trackingUnknown=true;reject(error);}});this.#tasks.add(task);originalObserve(task,()=>this.#tasks.delete(task),()=>this.#tasks.delete(task));return task;}
 #admit(settlement=false){this.#identity();if(this.#selectionHold&&(!settlement||this.#selectionHold.ready||!this.#selectionHold.valid))fail('PROMPT_INSERTION_HELD');}
 #entry(fn,settlement=false,enrollment=null){if(enrollment)this.#topCheck(enrollment.d);else this.#admit(settlement);let resolve,reject;const pending=new OriginalPromise((a,b)=>{resolve=a;reject=b;}),task=this.#track(pending);try{originalObserve((async()=>fn(task))(),resolve,reject);}catch(error){reject(error);}return task;}
 applicationSelectionSourceIs(store,api=this.#api){try{this.#identity();return this.#original()&&this.#store===store&&this.#api===api;}catch{return false;}}
 #original(){if(Object.getPrototypeOf(this)!==originalReceiptPrototype)return false;for(const [name,expected]of originalReceiptMethods){if(Object.hasOwn(this,name)||Object.getOwnPropertyDescriptor(originalReceiptPrototype,name)?.value!==expected)return false;}return true;}

 trackContinuation(cap,promise,receiptEpoch){this.#producer(cap);if(!uuid(receiptEpoch)||!promise||typeof promise.then!=='function')fail();const task=this.#track(promise);originalObserve(task,()=>{},()=>{this.#trackingUnknown=true;});if(this.#selectionHold?.ready){this.#selectionHold.ready=false;this.#selectionHold.valid=false;this.#selectionHold.error=new ArchiveError('OUTCOME_UNKNOWN');}return task;}
 #serial(fn){const task=originalNext(this.#tail,fn);this.#tail=originalIgnore(task);return task;}
 async #read(t){this.#identity();const migration=await t.get('meta','migration'),epoch=(await t.get('meta','recovery-restore-epoch'))?.value??null;if(migration?.phase!=='active'||migration.databaseId!==this.#databaseId||!(epoch===null||id(epoch)))fail();if(this.#restoreEpoch===undefined)this.#restoreEpoch=epoch;if(this.#restoreEpoch!==epoch)fail();const r=await t.get('meta',PROMPT_INSERTION_RUNTIME);if(r!==undefined){validateRow(r);if(r.databaseId!==this.#databaseId||this.#origin&&!same({databaseId:r.databaseId,restoreEpoch:r.restoreEpoch,domainDigest:r.domainDigest},this.#origin))fail();}this.#identity();return r??null;}
 #work(){this.#identity();const deadline=budgetClock()+30000;return {ticket:createOriginalRecoveryWork(this.#repository,{isCurrent:()=>{this.#identity();return true;}}),deadline,failed:false,tail:originalResolveValue()};}
 #checkWork(work){if(work.failed||budgetClock()>=work.deadline)fail('BNS_GROUP_RESOURCE_LIMIT');checkOriginalRecoveryWork(this.#repository,work.ticket);return work.deadline-budgetClock();}
 #charge(work,bytes,references){this.#checkWork(work);chargeOriginalRecoveryWork(this.#repository,work.ticket,bytes,references);this.#checkWork(work);}
 async #wait(work,promise){const ms=this.#checkWork(work);let timer;try{return await originalRace([promise,new OriginalPromise((_,reject)=>{timer=setTimeout(()=>reject(new ArchiveError('BNS_GROUP_RESOURCE_LIMIT')),ms);})]);}finally{clearTimeout(timer);}}
 #source(work,fn){this.#checkWork(work);return this.#wait(work,this.#track(originalNext(originalResolveValue(),()=>{this.#checkWork(work);return fn();})));}
 #tx(write,fn,work=this.#work()){const run=async()=>{this.#checkWork(work);try{return await originalRestrictedRepositoryTransaction(this.#repository,work.ticket,write,fn,['meta']);}catch(error){work.failed=true;throw error;}};const task=this.#track(originalNext(work.tail,run));work.tail=originalIgnore(task);return task;}
 async inspect(){await this.#initializeBinding();const r=await this.#tx(false,t=>this.#read(t));return {version:1,legacyCoverageUnknown:true,knownOperations:r?.claims.length??0,pendingOperations:r?.claims.filter(c=>c.state==='pending').length??0,productionActivation:false};}
 async #initializeBinding(){if(!this.#bindingTask)this.#bindingTask=this.#track((async()=>{const row=await this.#tx(false,t=>this.#read(t)),domainDigest=await promptInsertionDigest({domain:'paia-prompt-insertion-source-v1',databaseId:this.#databaseId,restoreEpoch:this.#restoreEpoch});this.#identity();if(row&&row.domainDigest!==await promptInsertionDigest({domain:'paia-prompt-insertion-source-v1',databaseId:row.databaseId,restoreEpoch:row.restoreEpoch}))fail();this.#identity();this.#birthGeneration=row?.nextEpoch??0;this.#domainDigest=domainDigest;this.#origin=row?{databaseId:row.databaseId,restoreEpoch:row.restoreEpoch,domainDigest:row.domainDigest}:{databaseId:this.#databaseId,restoreEpoch:this.#restoreEpoch,domainDigest};})());return this.#bindingTask;}
 async #change(fn,work=this.#work()){await this.#initializeBinding();return this.#serial(async()=>{let proposed;try{await this.#tx(true,async t=>{const row=await this.#read(t),base=row??{id:PROMPT_INSERTION_RUNTIME,version:1,databaseId:this.#databaseId,restoreEpoch:this.#restoreEpoch,revision:0,nextEpoch:0,retiredEpochFloor:0,legacyCoverageUnknown:true,domainDigest:this.#domainDigest,retiredRanges:[],epochs:[],claims:[]};proposed=await fn(structuredClone(base),row);if(!proposed)return;if(base.revision>=Number.MAX_SAFE_INTEGER)fail('RESOURCE_LIMIT');proposed.revision=base.revision+1;validateRow(proposed);await t.put('meta',proposed);this.#identity();},work);}catch(error){if(!proposed)throw error;const actual=await this.#tx(false,t=>this.#read(t),work);if(!actual||!same(actual,proposed))throw error;}this.#identity();return proposed;});}
 #sourceSender(sender,receiver=null){if(sender?.id!==this.#runtimeId||sender.tab?.incognito||sender.frameId!==0||!id(sender.documentId)||sender.documentLifecycle!=='active'||!site(sender.url)||!integer(sender.tab?.id)||!integer(sender.tab?.windowId))fail('FORBIDDEN');if(receiver&&(sender.tab.id!==receiver.tabId||sender.tab.windowId!==receiver.windowId||sender.documentId!==receiver.documentId))fail('FORBIDDEN');}
 #recoveryEvent(receiver,token){const known=this.#receivers.get(receiver.tabId);if(!known||!same(known.receiver,receiver))fail();const d=this.#topDocumentHold,e=d?.enrollment;if(e&&d.phase==='enrolling'&&token===e.token&&receiver.tabId===e.tab.id&&receiver.windowId===e.tab.windowId&&receiver.documentId===e.tab.documentId){this.#topCheck(d);return e.event;}if(token===this.#receiptEpoch){if(known.initialEvent?.token!==token)known.initialEvent={token,work:null,consumed:false};return known.initialEvent;}const a=this.#actions.get(token);if(!a||!a.work||!same(a.receiver,receiver))fail();this.#current(a);this.#checkWork(a.work);return a.recoveryEvent;}
 async registerReceiver(request,sender){const enrollment=this.#topRegistration(request,sender);return this.#entry(()=>this.#registerReceiver(request,sender,enrollment),false,enrollment);}
 async #registerReceiver(request,sender,enrollment=null){this.#identity();await this.#initializeBinding();if(!(exact(request,['type','version','nonce'])||exact(request,['type','version','nonce','recoveryToken']))||request.type!=='PAIA_PROMPT_INSERTION_RECEIVER_REGISTER'||request.version!==1||!uuid(request.nonce)||Object.hasOwn(request,'recoveryToken')&&!uuid(request.recoveryToken))fail('INVALID_REQUEST');this.#sourceSender(sender);const prior=this.#receivers.get(sender.tab.id),tab=enrollment?await this.#topCall(enrollment.d,this.#tabs,this.#get,[sender.tab.id]):await originalApply(this.#get,this.#tabs,[sender.tab.id]);this.#identity();if(enrollment){const d=this.#topRegistrationCurrent(enrollment,request,sender);this.#topCharge(d,{request,receiver:{tabId:sender.tab.id,windowId:sender.tab.windowId,documentId:sender.documentId,url:sender.url}});this.#topTab(d,tab);}else if(this.#knownDocumentHold||this.#topDocumentHold)this.#admit();if(this.#receivers.get(sender.tab.id)!==prior||tab.incognito||tab.discarded||!site(tab.url)||tab.windowId!==sender.tab.windowId)fail();const receiver={tabId:tab.id,windowId:tab.windowId,documentId:sender.documentId,nonce:request.nonce};if(prior&&prior.receiver.documentId===receiver.documentId&&prior.receiver.nonce!==receiver.nonce)fail();if(!prior&&this.#receivers.size>=PROMPT_INSERTION_LIMITS.receivers)fail('RESOURCE_LIMIT');const token=request.recoveryToken??this.#receiptEpoch;if(enrollment){this.#topRegistrationCurrent(enrollment,request,sender);}else if(token!==this.#receiptEpoch){const a=this.#actions.get(token);if(!a||!a.work||!same(a.receiver,receiver))fail();this.#current(a);this.#checkWork(a.work);}if(this.#receiverVersion>=Number.MAX_SAFE_INTEGER)fail('RESOURCE_LIMIT');if(!prior||!same(prior.receiver,receiver))this.#receivers.set(tab.id,{receiver,url:tab.url});else if(prior.url!==tab.url)this.#receivers.set(tab.id,{...prior,url:tab.url});this.#receiverVersion++;const event=this.#recoveryEvent(receiver,token);if(enrollment)event.work=enrollment.d.hold.work;return {registered:true,version:1,ownerToken:this.#receiptEpoch,recoveryToken:token,domainDigest:this.#domainDigest,receiver:structuredClone(receiver)};}
 async resolveReceiver(tabId,url,expectedDocumentId=null,eventContext=null){return this.#entry(()=>this.#resolveReceiver(tabId,url,expectedDocumentId,eventContext),false);}
 async #resolveReceiver(tabId,url,expectedDocumentId=null,eventContext=null){this.#identity();if(!integer(tabId)||!site(url)||expectedDocumentId!==null&&!id(expectedDocumentId))fail('INVALID_REQUEST');const a=eventContext===null?null:this.#events.get(eventContext);if(eventContext!==null&&!a)fail('PROMPT_INSERTION_CAPABILITY');if(a){this.#current(a);if(a.receiver.tabId!==tabId||expectedDocumentId!==null&&a.receiver.documentId!==expectedDocumentId)fail();}const work=a?.work??this.#work(),token=a?.action.actionId??this.#receiptEpoch,check=()=>{this.#checkWork(work);this.#identity();if(a)this.#current(a);else if(token!==this.#receiptEpoch)fail();};return this.#source(work,async()=>{check();const tab=await originalApply(this.#get,this.#tabs,[tabId]);check();if(tab.incognito||tab.discarded||tab.url!==url)fail();const probe={type:'PAIA_PROMPT_INSERTION_RECEIVER_PROBE',version:1,recoveryToken:token},top=await originalApply(this.#send,this.#tabs,[tabId,probe,{frameId:0}]);check();const known=this.#receivers.get(tabId);if(!exact(top,['version','nonce','profile'])||top.version!==1||top.profile!=='receipt-only-v1')fail('PROMPT_PAGE_REFRESH_REQUIRED');if(!known||known.url!==url||known.receiver.nonce!==top.nonce||known.receiver.windowId!==tab.windowId||expectedDocumentId!==null&&known.receiver.documentId!==expectedDocumentId)fail();const exactProbe=await originalApply(this.#send,this.#tabs,[tabId,probe,{documentId:known.receiver.documentId}]),latest=await originalApply(this.#get,this.#tabs,[tabId]);check();if(!exact(exactProbe,['version','nonce','profile'])||exactProbe.version!==1||exactProbe.profile!=='receipt-only-v1')fail('PROMPT_PAGE_REFRESH_REQUIRED');if(!same(exactProbe,top)||this.#receivers.get(tabId)!==known||latest.incognito||latest.discarded||latest.url!==url||latest.windowId!==known.receiver.windowId)fail();return structuredClone(known.receiver);});}
 removeTab(tabId){if(this.#receiverVersion>=Number.MAX_SAFE_INTEGER){this.#trackingUnknown=true;}else this.#receiverVersion++;this.#receivers.delete(tabId);for(const a of this.#actions.values())if(a.receiver.tabId===tabId)a.valid=false;}
 #binding(d){if(!exact(d,['receiptEpoch','sourceDigest','authorizationDigest','initiatorDigest','receiver'])||!uuid(d.receiptEpoch)||![d.sourceDigest,d.authorizationDigest,d.initiatorDigest].every(hash)||!validReceiver(d.receiver))fail('INVALID_REQUEST');return d;}
 async issueAction(cap,descriptor){return this.#entry(task=>this.#issueAction(cap,descriptor,task),false);}
 async #issueAction(cap,descriptor,entryTask){const p=this.#producer(cap),d=structuredClone(this.#binding(descriptor));if(this.#rotating||d.receiptEpoch!==this.#receiptEpoch)fail();await this.#initializeBinding();const row=await this.#tx(false,t=>this.#read(t));this.#admit();this.#producer(cap);if(this.#rotating||d.receiptEpoch!==this.#receiptEpoch)fail();const current=row?.nextEpoch??0,own=row?.epochs.find(e=>e.epoch===this.#birthGeneration+1&&e.receiptEpoch===this.#receiptEpoch&&e.state==='open');if(current!==this.#birthGeneration&&!(current===this.#birthGeneration+1&&own))fail();
  // Issuance stays entirely readonly. Only retire transient capabilities here;
  // the next genuine action will CAS its fixed proposal during dispatch.
  if(this.#actions.size>=PROMPT_INSERTION_LIMITS.claims||own&&new TextEncoder().encode(promptInsertionEncoding(row)).length>=120*1024){if([...this.#tasks].some(task=>task!==entryTask))fail('RESOURCE_LIMIT');for(const a of this.#actions.values())a.valid=false;this.#actions.clear();if(own&&current===own.epoch){this.#liveRetirement=Object.freeze({epoch:own.epoch,receiptEpoch:own.receiptEpoch,parentGeneration:current});this.#birthGeneration=current;}this.#receiptEpoch=crypto.randomUUID();this.#epoch=0;fail();}
  const known=this.#receivers.get(d.receiver.tabId);if(!known||!same(known.receiver,d.receiver))fail();if(this.#birthGeneration>=Number.MAX_SAFE_INTEGER)fail('RESOURCE_LIMIT');const action=Object.freeze({version:1,actionId:crypto.randomUUID(),operationId:crypto.randomUUID(),receiptEpoch:d.receiptEpoch});this.#actions.set(action.actionId,{...d,action,p,parentGeneration:this.#birthGeneration,epoch:this.#birthGeneration+1,valid:true,task:null,envelope:null,invoked:false});return {...action};}
 #current(a){this.#producer(a.p.cap);if(this.#rotating||!a.valid||a.action.receiptEpoch!==this.#receiptEpoch||this.#actions.get(a.action.actionId)!==a||!same(this.#receivers.get(a.receiver.tabId)?.receiver??null,a.receiver))fail();}
 beginInsertion(cap,action){this.#admit();const p=this.#producer(cap);if(!validAction(action))fail('INVALID_REQUEST');const a=this.#actions.get(action.actionId);if(!a||a.p!==p||!same(a.action,action))fail();this.#current(a);if(!a.work){a.work=this.#work();a.eventContext=Object.freeze(Object.create(null));a.recoveryEvent={token:a.action.actionId,work:a.work,consumed:false};this.#events.set(a.eventContext,a);}else this.#checkWork(a.work);return a.eventContext;}
 dispatch(cap,request,assertCurrent){this.#admit();const p=this.#producer(cap);if(!exact(request,['action','sourceDigest','authorizationDigest','initiatorDigest','receiver','message'])||!validAction(request.action)||typeof assertCurrent!=='function')fail('INVALID_REQUEST');const a=this.#actions.get(request.action.actionId);if(!a||a.p!==p||!same(a.action,request.action)||!same(a.receiver,request.receiver)||['sourceDigest','authorizationDigest','initiatorDigest'].some(k=>a[k]!==request[k]))fail();if(!request.message||Object.getPrototypeOf(request.message)!==Object.prototype||request.message.type!==messageTypes[p.lane]||request.message.operationId!==a.action.operationId||Object.hasOwn(request.message,'insertionReceipt'))fail('INVALID_REQUEST');const message=structuredClone(request.message);this.#current(a);if(a.task){if(!same(a.message,message))fail('INVALID_REQUEST');return this.#cached(a);}this.#current(a);this.beginInsertion(cap,a.action);a.message=message;a.assertCurrent=assertCurrent;a.completed=false;const original=this.#dispatch(a,message,assertCurrent);a.task=this.#track(original);originalObserve(original,()=>{a.completed=true;},()=>{a.completed=true;});return a.task;}
 async #assertCurrentEpoch(a,work=a.work??this.#work()){this.#current(a);await this.#tx(false,async t=>{const row=await this.#read(t);if(!row||row.nextEpoch!==a.epoch||!row.epochs.some(e=>e.epoch===a.epoch&&e.receiptEpoch===a.action.receiptEpoch&&e.state==='open'))fail();this.#current(a);},work);}
 async #cached(a){await this.#assertCurrentEpoch(a,this.#work());return a.task;}
 async #announceRetired(claims,epochs,row,work){const groups=new Map();for(const c of claims){const e=c.envelope,key=promptInsertionEncoding([e.epoch,e.receiptEpoch,e.domainDigest,e.receiver]);let g=groups.get(key);if(!g)groups.set(key,g={envelope:e,ids:[]});g.ids.push(e.claimId);}let sent=0;for(const {envelope:e,ids}of groups.values()){if(sent++>=16)break;this.#checkWork(work);const notice={type:'PAIA_PROMPT_INSERTION_EPOCH_RETIRE',version:1,receiptEpoch:e.receiptEpoch,epoch:e.epoch,domainDigest:e.domainDigest,retiredEpochFloor:row.retiredEpochFloor,settledClaimIds:ids};this.#charge(work,new TextEncoder().encode(promptInsertionEncoding(notice)).length,1);try{await this.#wait(work,this.#track(originalApply(this.#send,this.#tabs,[e.receiver.tabId,notice,{documentId:e.receiver.documentId}])));}catch{this.#checkWork(work);/* Bounded best effort only; later genuine recovery may reconcile. */}}}
 async #dispatch(a,message,assertCurrent){let pending=false;const work=a.work;try{this.#checkWork(work);await this.#source(work,assertCurrent);this.#checkWork(work);this.#current(a);await this.#initializeBinding();const epoch=a.epoch;this.#current(a);const initial=this.#receivers.get(a.receiver.tabId);if(!same(await this.#source(work,()=>this.resolveReceiver(a.receiver.tabId,initial.url,a.receiver.documentId,a.eventContext)),a.receiver))fail();this.#current(a);
  // Hash only transient already-qualified material before opening a native IDB
  // transaction. Crypto promises must never extend a transaction's lifetime.
  const base={version:1,claimId:crypto.randomUUID(),actionId:a.action.actionId,operationId:a.action.operationId,receiptEpoch:a.action.receiptEpoch,epoch,lane:a.p.lane,receiver:structuredClone(a.receiver),sourceDigest:a.sourceDigest,authorizationDigest:a.authorizationDigest,initiatorDigest:a.initiatorDigest,domainDigest:this.#domainDigest};
  const digestInput={domain:'paia-prompt-insertion-v1',envelope:base,message};this.#charge(work,new TextEncoder().encode(promptInsertionEncoding(digestInput)).length,1);const envelope={...base,digest:await promptInsertionDigest(digestInput)};this.#current(a);
  const coldClaims=[],coldEpochs=[],live=this.#liveRetirement;let liveRetired=false;const pendingRow=await this.#change(row=>{this.#current(a);
   if(row.nextEpoch===a.parentGeneration){
    if(live&&(live.epoch!==a.parentGeneration||live.parentGeneration!==a.parentGeneration||!row.epochs.some(e=>e.epoch===live.epoch&&e.receiptEpoch===live.receiptEpoch&&e.state==='open')))fail();const terminal=row.epochs.filter(e=>live&&e.epoch===live.epoch&&e.receiptEpoch===live.receiptEpoch||row.claims.filter(c=>c.envelope.epoch===e.epoch).every(claimTerminal));liveRetired=!!live;coldEpochs.push(...structuredClone(terminal));coldClaims.push(...structuredClone(row.claims.filter(c=>claimTerminal(c)&&terminal.some(e=>e.epoch===c.envelope.epoch))));retire(row,terminal.map(e=>e.epoch));
    if(row.epochs.length>=PROMPT_INSERTION_LIMITS.epochs)fail('RESOURCE_LIMIT');row.nextEpoch=epoch;row.epochs.push({epoch,receiptEpoch:a.action.receiptEpoch,state:'open'});
   }else if(row.nextEpoch!==epoch||!row.epochs.some(e=>e.epoch===epoch&&e.receiptEpoch===a.action.receiptEpoch&&e.state==='open'))fail();
   row.claims=row.claims.filter(c=>!claimTerminal(c)||!retired(row,c.envelope.epoch));
   if(row.claims.length>=PROMPT_INSERTION_LIMITS.claims||row.claims.some(c=>c.envelope.operationId===a.action.operationId))fail('RESOURCE_LIMIT');row.claims.push({envelope,state:'pending'});if(new TextEncoder().encode(promptInsertionEncoding(row)).length>PROMPT_INSERTION_LIMITS.admissionBytes)fail('RESOURCE_LIMIT');return row;},work);pending=true;a.envelope=envelope;if(liveRetired&&this.#liveRetirement===live)this.#liveRetirement=null;if(a.action.receiptEpoch===this.#receiptEpoch)this.#epoch=epoch;
  await this.#announceRetired(coldClaims,coldEpochs,pendingRow,work);
  await this.#source(work,assertCurrent);this.#checkWork(work);this.#current(a);const known=this.#receivers.get(a.receiver.tabId);const receiver=await this.#source(work,()=>this.resolveReceiver(a.receiver.tabId,known?.url??'',a.receiver.documentId,a.eventContext));if(!same(receiver,a.receiver))fail();await this.#source(work,assertCurrent);this.#checkWork(work);this.#current(a);
  let sent;await this.#tx(false,async t=>{const row=await this.#read(t),claim=row?.claims.find(c=>c.envelope.claimId===envelope.claimId);if(!claim||row.nextEpoch!==envelope.epoch||claim.state!=='pending'||!same(claim.envelope,envelope)||!row.epochs.some(e=>e.epoch===envelope.epoch&&e.receiptEpoch===envelope.receiptEpoch&&e.state==='open'))fail();this.#current(a);this.#checkWork(work);a.invoked=true;sent=this.#track(originalApply(this.#send,this.#tabs,[a.receiver.tabId,{...message,insertionReceipt:structuredClone(envelope)},{documentId:a.receiver.documentId}]));},work);
  const result=await this.#wait(work,sent);if(!validAck(result?.insertionAck)||!same(result.insertionAck.envelope,envelope))return {status:'uncertain',reason:'readback_unconfirmed'};await this.#settle(result.insertionAck,false,work);const ack=result.insertionAck;if(ack.outcome==='inserted'){try{await this.#source(work,assertCurrent);this.#checkWork(work);await this.#assertCurrentEpoch(a,work);}catch{return {status:'uncertain',reason:'readback_unconfirmed'};}return {status:'inserted',verified:true,...(result.replayed===true?{replayed:true}:{})};}if(ack.outcome==='not_inserted')return {status:'failed',reason:typeof result.reason==='string'?result.reason:'insertion_unavailable'};return {status:'uncertain',reason:'readback_unconfirmed'};
 }catch(error){if(pending&&error?.code==='PROMPT_PAGE_REFRESH_REQUIRED')fail('OUTCOME_UNKNOWN');if(pending&&!a.invoked)try{await this.#notDispatched(a.envelope,work);}catch{/* Uncertain evidence is retained. */}throw error;}}
 async #notDispatched(envelope,work){if(!envelope)return;await this.#change(row=>{const c=row.claims.find(c=>c.envelope.claimId===envelope.claimId);if(!c||!same(c.envelope,envelope)||c.state!=='pending')fail();c.state='not_dispatched';return row;},work);}
 async #settle(ack,allowRetired=false,work=this.#work()){if(!validAck(ack))fail('INVALID_REQUEST');await this.#initializeBinding();if(ack.envelope.domainDigest!==this.#domainDigest)fail();if(ack.outcome==='unknown')return false;let retiredReply=false;await this.#change(row=>{const c=row.claims.find(c=>c.envelope.claimId===ack.envelope.claimId);if(!c&&allowRetired&&retired(row,ack.envelope.epoch)){retiredReply=true;return null;}if(!c||!same(c.envelope,ack.envelope)||c.state!=='pending'&&c.state!==ack.outcome)fail();if(c.state===ack.outcome)return null;c.state=ack.outcome;return row;},work);return retiredReply?'retired':true;}
 async handleAck(request,sender){return this.#entry(()=>this.#handleAck(request,sender),true);}
 async #handleAck(request,sender){this.#identity();if(!exact(request,['type','ack'])||request.type!=='PAIA_PROMPT_INSERTION_ACK'||!validAck(request.ack))fail('INVALID_REQUEST');this.#sourceSender(sender,request.ack.envelope.receiver);const known=this.#receivers.get(sender.tab.id);if(!known||!same(known.receiver,request.ack.envelope.receiver))fail();const a=this.#actions.get(request.ack.envelope.actionId),work=a&&!a.completed&&same(a.envelope,request.ack.envelope)?a.work:this.#work();const result=await this.#track(this.#settle(request.ack,true,work));return result==='retired'?{settled:false,retired:true}:{settled:result};}
 async handleReconcile(request,sender){return this.#entry(()=>this.#handleReconcile(request,sender),true);}
 async #handleReconcile(request,sender){this.#identity();if(!exact(request,['type','version','ownerToken','recoveryToken','acks'])||request.type!=='PAIA_PROMPT_INSERTION_RECONCILE'||request.version!==1||request.ownerToken!==this.#receiptEpoch||!uuid(request.recoveryToken)||!Array.isArray(request.acks)||request.acks.length>16)fail('INVALID_REQUEST');this.#sourceSender(sender);const known=this.#receivers.get(sender.tab.id);if(!known)fail();const event=this.#recoveryEvent(known.receiver,request.recoveryToken);if(event.consumed)fail();const ids=new Set();for(const ack of request.acks){if(!validAck(ack)||ack.outcome==='unknown'||!same(ack.envelope.receiver,known.receiver)||ids.has(ack.envelope.claimId))fail('INVALID_REQUEST');this.#sourceSender(sender,ack.envelope.receiver);ids.add(ack.envelope.claimId);}event.consumed=true;const work=event.work??this.#work();event.work=work;this.#charge(work,new TextEncoder().encode(promptInsertionEncoding(request)).length,1);await this.#initializeBinding();if(request.acks.some(a=>a.envelope.domainDigest!==this.#domainDigest))fail();let results,retirementSummary;await this.#track(this.#change(row=>{if(this.#receivers.get(sender.tab.id)!==known||request.ownerToken!==this.#receiptEpoch||this.#recoveryEvent(known.receiver,request.recoveryToken)!==event)fail();const claims=new Map(row.claims.map(c=>[c.envelope.claimId,c]));let changed=false;results=[];for(const ack of request.acks){const c=claims.get(ack.envelope.claimId);if(c){if(!same(c.envelope,ack.envelope)||c.state!=='pending'&&c.state!==ack.outcome)fail();if(c.state==='pending'){c.state=ack.outcome;changed=true;}results.push({claimId:ack.envelope.claimId,settled:true});}else if(retired(row,ack.envelope.epoch))results.push({claimId:ack.envelope.claimId,settled:false,retired:true});else fail();}retirementSummary={domainDigest:this.#domainDigest,retiredEpochFloor:row.retiredEpochFloor,retiredRanges:structuredClone(row.retiredRanges)};return changed?row:null;},work));return {ownerToken:this.#receiptEpoch,recoveryToken:request.recoveryToken,results,retirementSummary};}
 async handleQualify(request,sender){return this.#entry(()=>this.#handleQualify(request,sender),false);}
 async #handleQualify(request,sender){this.#identity();if(!exact(request,['type','version','envelope'])||request.type!=='PAIA_PROMPT_INSERTION_QUALIFY'||request.version!==1||!validPromptInsertionEnvelope(request.envelope))fail('INVALID_REQUEST');this.#sourceSender(sender,request.envelope.receiver);const a=this.#actions.get(request.envelope.actionId);if(!a||!a.invoked||!a.envelope||!same(a.envelope,request.envelope))fail();this.#current(a);const work=a.work;await this.#source(work,a.assertCurrent);this.#checkWork(work);this.#current(a);await this.#tx(false,async t=>{const row=await this.#read(t),c=row?.claims.find(c=>c.envelope.claimId===request.envelope.claimId);if(!c||row.nextEpoch!==request.envelope.epoch||c.state!=='pending'||!same(c.envelope,request.envelope))fail();this.#current(a);},work);return {qualified:true,remainingMs:this.#checkWork(work)};}
 async rotateEpoch(cap){this.#admit();return this.#rotateEpoch(cap);}
 async #rotateEpoch(cap){this.#producer(cap);if(this.#rotating)fail();this.#rotating=true;const work=this.#work(),receiptEpoch=this.#receiptEpoch,settled=[];let epoch;for(const a of this.#actions.values())a.valid=false;try{for(;;){this.#identity();const tasks=[...this.#tasks];if(tasks.length){await this.#wait(work,originalAllSettled(tasks));continue;}await originalResolveValue();if(!this.#tasks.size)break;}await this.#tail;epoch=this.#epoch;let final=null;if(epoch>0)final=await this.#change(row=>{const e=row.epochs.find(e=>e.epoch===epoch&&e.receiptEpoch===receiptEpoch);if(row.nextEpoch!==epoch||!e||e.state!=='open')fail();for(const c of row.claims)if(c.envelope.epoch===epoch&&claimTerminal(c))settled.push(structuredClone(c));retire(row,[epoch]);return row;},work);
  if(epoch>0)await this.#announceRetired(settled,[{epoch,receiptEpoch}],final,work);
  this.#identity();this.#actions.clear();this.#receiptEpoch=crypto.randomUUID();this.#epoch=0;this.#epochTask=null;if(final)this.#birthGeneration=final.nextEpoch;return {retired:true,epoch};
 }finally{this.#rotating=false;}}
 // Warm owner only. A drained task set is not evidence that historical or
 // unacknowledged external insertion ended. Retained pending claims refuse.
 #held(hold){try{this.#identity();return this.#selectionHold===hold&&hold.valid&&this.#original()&&hold.receiptEpoch===this.#receiptEpoch&&budgetClock()<hold.deadline;}catch{return false;}}
 async #drain(hold){for(;;){if(!this.#held(hold))fail('OUTCOME_UNKNOWN');const tasks=[...this.#tasks];if(tasks.length){await originalAllSettled(tasks);continue;}await new OriginalPromise(resolve=>resolve());if(!this.#tasks.size)return;}}
 #holdSnapshot(work){return this.#tx(false,async t=>{const ledger=await this.#read(t);return {ledger,gate:(await t.get('meta','gate'))??null,restoreEpoch:(await t.get('meta','recovery-restore-epoch'))??null,generation:(await t.get('meta','backup-data-generation'))??null};},work);}
 async holdForApplicationSelection(){
  this.#admit();if(!this.#original()||this.#rotating)fail('PROMPT_INSERTION_CAPABILITY');
  const hold={token:Object.freeze(Object.create(null)),valid:true,ready:false,deadline:budgetClock()+30000,receiptEpoch:this.#receiptEpoch,work:this.#work(),snapshot:null,error:null};this.#selectionHold=hold;
  for(const action of this.#actions.values())if(!action.invoked)action.valid=false;
  let timer;const acquire=(async()=>{await this.#drain(hold);const snapshot=await this.#holdSnapshot(hold.work);if(!this.#held(hold)||this.#tasks.size||this.#trackingUnknown||snapshot.ledger?.claims.some(claim=>claim.state==='pending'))fail('OUTCOME_UNKNOWN');hold.snapshot=snapshot;hold.ready=true;return hold.token;})();
  try{return await originalRace([acquire,new OriginalPromise((_,reject)=>{timer=setTimeout(()=>{hold.valid=false;reject(new ArchiveError('OUTCOME_UNKNOWN'));},Math.max(0,hold.deadline-budgetClock()));})]);}
  catch(error){hold.valid=false;hold.error=error;throw error;}finally{clearTimeout(timer);}
 }
 applicationSelectionHeld(token){const hold=this.#selectionHold;return !!hold&&hold.token===token&&hold.ready&&this.#held(hold)&&!this.#tasks.size&&!this.#trackingUnknown;}
 async fenceApplicationSelection(token){const hold=this.#selectionHold;if(!this.applicationSelectionHeld(token))fail();try{if(!same(await this.#holdSnapshot(hold.work),hold.snapshot)||!this.applicationSelectionHeld(token))fail();return true;}catch(error){hold.valid=false;hold.error=error;throw error;}}
 releaseApplicationSelection(token){const hold=this.#selectionHold;if(!hold||hold.token!==token)return false;hold.valid=false;this.#selectionHold=null;return true;}
 releaseFailedApplicationSelection(error){const hold=this.#selectionHold;if(!hold||hold.valid||hold.error!==error||!error)return false;this.#selectionHold=null;return true;}

 // Prospective, nonempty known-document subset only. This is not global host coverage.
 #knownCurrent(d){try{return this.#knownDocumentHold===d&&this.#held(d.hold)&&!d.cleaning&&!d.failed&&d.version===this.#receiverVersion&&this.#receivers.size===d.entries.length&&d.entries.every(e=>this.#receivers.get(e.receiver.tabId)===e.original&&same(e.original.receiver,e.receiver)&&e.original.url===e.url);}catch{return false;}}
 #knownCheck(d){if(!this.#knownCurrent(d))fail('OUTCOME_UNKNOWN');this.#checkWork(d.hold.work);}
 async #knownTab(d,e){this.#knownCheck(d);this.#charge(d.hold.work,0,1);const tab=await this.#wait(d.hold.work,this.#track(originalApply(this.#get,this.#tabs,[e.receiver.tabId])));this.#knownCheck(d);this.#charge(d.hold.work,new TextEncoder().encode(promptInsertionEncoding({id:tab?.id??null,windowId:tab?.windowId??null,url:tab?.url??null,incognito:tab?.incognito??null,discarded:tab?.discarded??null})).length,0);if(tab?.id!==e.receiver.tabId||tab.windowId!==e.receiver.windowId||tab.incognito||tab.discarded||tab.url!==e.url||!site(tab.url))fail('OUTCOME_UNKNOWN');}
 #knownMessage(d,e,kind){return {type:'PAIA_PROMPT_INSERTION_DOCUMENT_'+kind,version:1,receiver:structuredClone(e.receiver),ownerToken:d.hold.receiptEpoch,domainDigest:d.domainDigest,challenge:e.challenge};}
 #knownProof(d,e,result){this.#knownCheck(d);if(!exact(result,['version','profile','held','challenge','receiver','ownerToken','domainDigest','remainingMs'])||result.version!==1||result.profile!=='receipt-only-v1'||result.held!==true||result.challenge!==e.challenge||!same(result.receiver,e.receiver)||result.ownerToken!==d.hold.receiptEpoch||result.domainDigest!==d.domainDigest||!Number.isFinite(result.remainingMs)||result.remainingMs<=0||result.remainingMs>30000)fail('OUTCOME_UNKNOWN');this.#charge(d.hold.work,1024,1);}
 #knownCleanupEntry(d,e){
  if(!d.cleaning||!e.attempted||!e.settled||e.cleanupStarted)return;e.cleanupStarted=true;
  // Cleanup was charged before HOLD dispatch. No new authority/budget or retries.
  let raw;try{raw=this.#track(originalApply(this.#send,this.#tabs,[e.receiver.tabId,this.#knownMessage(d,e,'RELEASE'),{documentId:e.receiver.documentId}]));}catch{e.cleanupUnknown=true;return;}
  e.cleanupTask=raw;originalObserve(raw,result=>{e.released=exact(result,['version','released','challenge'])&&result.version===1&&result.released===true&&result.challenge===e.challenge;if(!e.released)e.cleanupUnknown=true;},()=>{e.cleanupUnknown=true;});
 }
 #knownStartCleanup(d){d.cleaning=true;d.hold.valid=false;for(const e of d.entries)this.#knownCleanupEntry(d,e);}
 async #knownCleanup(d){
  this.#knownStartCleanup(d);
  const waiting=d.entries.flatMap(e=>e.attempted?[e.raw,e.cleanupTask].filter(Boolean):[]);
  try{if(waiting.length)await this.#wait(d.hold.work,originalAllSettled(waiting));for(const e of d.entries)this.#knownCleanupEntry(d,e);const cleanup=d.entries.map(e=>e.cleanupTask).filter(Boolean);if(cleanup.length)await this.#wait(d.hold.work,originalAllSettled(cleanup));}catch{return false;}
  if(this.#trackingUnknown||d.entries.some(e=>e.attempted&&(!e.settled||!e.released||e.cleanupUnknown)))return false;
  if(this.#knownDocumentHold!==d||this.#selectionHold!==d.hold)return false;this.#knownDocumentHold=null;this.#selectionHold=null;return true;
 }
 async #knownAcquire(d,e){
  await this.#knownTab(d,e);const request=this.#knownMessage(d,e,'HOLD'),release=this.#knownMessage(d,e,'RELEASE');
  this.#charge(d.hold.work,new TextEncoder().encode(promptInsertionEncoding([request,release])).length+1024,3);this.#knownCheck(d);e.attempted=true;
  try{e.transport=originalApply(this.#send,this.#tabs,[e.receiver.tabId,request,{documentId:e.receiver.documentId}]);}
  catch(error){this.#trackingUnknown=true;throw error;}
  // Only observation of the original SDK Promise proves settlement. A local
  // tracking/observation failure cannot cause an early RELEASE of a late HOLD.
  const observed=new OriginalPromise((resolve,reject)=>{const settled=()=>{e.settled=true;this.#knownCleanupEntry(d,e);};try{originalObserve(e.transport,value=>{settled();resolve(value);},error=>{settled();reject(error);});}catch(error){this.#trackingUnknown=true;reject(error);}});
  e.raw=this.#track(observed);
  const result=await this.#wait(d.hold.work,e.raw);this.#knownProof(d,e,result);await this.#knownTab(d,e);
 }
 async #knownFence(d){for(const e of d.entries){await this.#knownTab(d,e);const request=this.#knownMessage(d,e,'FENCE');this.#charge(d.hold.work,new TextEncoder().encode(promptInsertionEncoding(request)).length,1);const result=await this.#wait(d.hold.work,this.#track(originalApply(this.#send,this.#tabs,[e.receiver.tabId,request,{documentId:e.receiver.documentId}])));this.#knownProof(d,e,result);await this.#knownTab(d,e);}}
 async holdKnownDocumentsForApplicationSelection(){
  this.#admit();if(!this.#original()||this.#rotating||this.#knownDocumentHold||!this.#receivers.size)fail('PROMPT_INSERTION_CAPABILITY');
  const work=this.#work(),deadline=budgetClock()+30000;work.deadline=Math.min(work.deadline,deadline);
  const hold={token:Object.freeze(Object.create(null)),valid:true,ready:false,deadline:work.deadline,receiptEpoch:this.#receiptEpoch,work,snapshot:null,error:null};
  const d={token:Object.freeze(Object.create(null)),hold,version:this.#receiverVersion,domainDigest:this.#domainDigest,entries:[...this.#receivers.values()].map(original=>({original,receiver:structuredClone(original.receiver),url:original.url,challenge:crypto.randomUUID(),attempted:false,settled:false,released:false,cleanupStarted:false})),failed:false,cleaning:false,error:null};
  for(const e of d.entries)this.#charge(work,new TextEncoder().encode(promptInsertionEncoding({receiver:e.receiver,url:e.url})).length,1);
  this.#selectionHold=hold;this.#knownDocumentHold=d;for(const action of this.#actions.values())if(!action.invoked)action.valid=false;
  const acquire=(async()=>{for(const e of d.entries)await this.#knownAcquire(d,e);await this.#drain(hold);this.#knownCheck(d);const before=await this.#holdSnapshot(work);if(this.#trackingUnknown||before.ledger?.claims.some(c=>c.state==='pending'))fail('OUTCOME_UNKNOWN');await this.#knownFence(d);const after=await this.#holdSnapshot(work);this.#knownCheck(d);if(this.#tasks.size||!same(before,after))fail('OUTCOME_UNKNOWN');hold.snapshot=after;hold.ready=true;return d.token;})();
  try{return await this.#wait(work,acquire);}catch(error){if(error?.code==='BNS_GROUP_RESOURCE_LIMIT')work.failed=true;d.failed=true;d.error=error;hold.valid=false;hold.error=new ArchiveError('OUTCOME_UNKNOWN');this.#knownStartCleanup(d);throw error;}
 }
 #knownHeld(d){return !!d&&d.hold.ready&&this.#knownCurrent(d)&&!this.#tasks.size&&!this.#trackingUnknown;}
 knownDocumentsHeldForApplicationSelection(token){const d=this.#knownDocumentHold;return d!==this.#topDocumentHold&&d?.token===token&&this.#knownHeld(d);}
 async fenceKnownDocumentsForApplicationSelection(token){const d=this.#knownDocumentHold;if(!this.knownDocumentsHeldForApplicationSelection(token))fail('OUTCOME_UNKNOWN');try{await this.#knownFence(d);const snapshot=await this.#holdSnapshot(d.hold.work);if(!same(snapshot,d.hold.snapshot)||!this.knownDocumentsHeldForApplicationSelection(token))fail('OUTCOME_UNKNOWN');return true;}catch(error){if(error?.code==='BNS_GROUP_RESOURCE_LIMIT')d.hold.work.failed=true;d.failed=true;d.error=error;d.hold.valid=false;this.#knownStartCleanup(d);throw error;}}
 releaseKnownDocumentsForApplicationSelection(token){const d=this.#knownDocumentHold;return d!==this.#topDocumentHold&&d?.token===token?this.#knownCleanup(d):originalResolveValue(false);}
 releaseFailedKnownDocumentsForApplicationSelection(error){const d=this.#knownDocumentHold;return d!==this.#topDocumentHold&&d?.failed&&d.error===error&&error?this.#knownCleanup(d):originalResolveValue(false);}
 // Fixed origin/top-document metadata only; no capture repair or page content.
 #inventoryInstall(){
  const api=this.#api,tabs=this.#tabs,scripting=api.scripting;
  if(typeof tabs.query!=='function'||typeof scripting?.executeScript!=='function')return;
  const events=['onCreated','onRemoved','onReplaced','onUpdated'].map(key=>({key,event:tabs[key],add:tabs[key]?.addListener,remove:tabs[key]?.removeListener}));
  if(events.some(e=>typeof e.add!=='function'||typeof e.remove!=='function'))return;
  const source={scripting,execute:scripting.executeScript,query:tabs.query,events,installed:[]};
  const changed=()=>{if(this.#topologyVersion<Number.MAX_SAFE_INTEGER)this.#topologyVersion++;else source.invalid=true;const d=this.#topDocumentHold;if(d){d.failed=true;d.hold.valid=false;this.#knownStartCleanup(d);}};
  try{for(const e of events){originalApply(e.add,e.event,[changed]);source.installed.push({...e,listener:changed});}this.#inventorySource=source;}
  catch{for(const e of source.installed)try{originalApply(e.remove,e.event,[e.listener]);}catch{};}
 }
 #inventoryIdentity(){
  this.#identity();const s=this.#inventorySource;
  if(!s||s.invalid||this.#api.scripting!==s.scripting||s.scripting.executeScript!==s.execute||this.#tabs.query!==s.query||s.events.some(e=>this.#tabs[e.key]!==e.event||e.event.addListener!==e.add||e.event.removeListener!==e.remove))fail('PROMPT_INSERTION_CAPABILITY');
  return s;
 }
 #topCheck(d){this.#inventoryIdentity();if(this.#topDocumentHold!==d||d.failed||d.cleaning||d.topology!==this.#topologyVersion||!this.#held(d.hold))fail('OUTCOME_UNKNOWN');this.#checkWork(d.hold.work);}
 #topRegistration(request,sender){
  const d=this.#topDocumentHold,e=d?.enrollment;
  if(!e||d.phase!=='enrolling'||request?.type!=='PAIA_PROMPT_INSERTION_RECEIVER_REGISTER'||request.recoveryToken!==e.token)return null;
  this.#topCheck(d);this.#sourceSender(sender);if(sender.tab.id!==e.tab.id||sender.tab.windowId!==e.tab.windowId||sender.documentId!==e.tab.documentId||sender.url!==e.tab.url)fail('PROMPT_INSERTION_HELD');
  return {d,e};
 }
 #topRegistrationCurrent(enrollment,request,sender){
  const {d,e}=enrollment;this.#topCheck(d);
  if(d.phase!=='enrolling'||d.enrollment!==e||this.#topRegistration(request,sender)?.e!==e)fail('PROMPT_INSERTION_HELD');
  return d;
 }
 #topCharge(d,value,refs=1){this.#topCheck(d);this.#charge(d.hold.work,new TextEncoder().encode(promptInsertionEncoding(value)).length,refs);}
 async #topCall(d,owner,method,args){
  this.#topCheck(d);const parameters=method===this.#inventorySource?.execute?args.map(value=>({target:value.target,world:value.world,probe:'original-current-prompt-top-v1'})):args;this.#topCharge(d,parameters);let raw;
  try{raw=originalApply(method,owner,args);}catch(error){this.#trackingUnknown=true;throw error;}
  const result=await this.#wait(d.hold.work,this.#track(raw));this.#topCheck(d);return result;
 }
 #topTab(d,tab){
  const value={id:tab?.id??null,windowId:tab?.windowId??null,url:tab?.url??null,incognito:tab?.incognito??null,discarded:tab?.discarded??null,frozen:tab?.frozen??false};this.#topCharge(d,value);
  if(!integer(value.id)||!integer(value.windowId)||!site(value.url)||value.incognito!==false||value.discarded!==false||value.frozen!==false)fail('OUTCOME_UNKNOWN');return value;
 }
 async #topInventory(d){
  const s=this.#inventoryIdentity();const raw=await this.#topCall(d,this.#tabs,s.query,[{url:['https://chatgpt.com/*']}]);
  if(!Array.isArray(raw)||!raw.length||raw.length>PROMPT_INSERTION_LIMITS.receivers)fail('OUTCOME_UNKNOWN');
  const tabs=raw.map(tab=>this.#topTab(d,tab)).sort((a,b)=>a.id-b.id);if(new Set(tabs.map(t=>t.id)).size!==tabs.length)fail('OUTCOME_UNKNOWN');
  const result=[];
  for(const tab of tabs){
   const get=async()=>this.#topTab(d,await this.#topCall(d,this.#tabs,this.#get,[tab.id]));
   if(!same(await get(),tab))fail('OUTCOME_UNKNOWN');
   const probe=async target=>{const rows=await this.#topCall(d,s.scripting,s.execute,[{target,world:'ISOLATED',func:probeCurrentPromptTopDocument}]);if(!Array.isArray(rows)||rows.length!==1)fail('OUTCOME_UNKNOWN');const row=rows[0];this.#topCharge(d,{frameId:row?.frameId??null,documentId:row?.documentId??null,result:row?.result??null,error:row?.error?true:false});if(row?.frameId!==0||!id(row.documentId)||row.error||!exact(row.result,['origin','top'])||row.result.origin!=='https://chatgpt.com'||row.result.top!==true)fail('OUTCOME_UNKNOWN');return row.documentId;};
   const documentId=await probe({tabId:tab.id,frameIds:[0]});if(await probe({tabId:tab.id,documentIds:[documentId]})!==documentId||!same(await get(),tab))fail('OUTCOME_UNKNOWN');result.push({...tab,documentId});
  }
  this.#topCheck(d);return result;
 }
 async #topEnroll(d,tab){
  const e={tab,token:crypto.randomUUID(),event:{work:d.hold.work,consumed:false}};d.enrollment=e;
  try{
   const message={type:'PAIA_PROMPT_INSERTION_RECEIVER_PROBE',version:1,recoveryToken:e.token};
   const top=await this.#topCall(d,this.#tabs,this.#send,[tab.id,message,{frameId:0}]);
   this.#topCharge(d,top);if(!exact(top,['version','nonce','profile'])||top.version!==1||top.profile!=='receipt-only-v1')fail('PROMPT_PAGE_REFRESH_REQUIRED');
   const known=this.#receivers.get(tab.id);if(!known||known.url!==tab.url||known.receiver.windowId!==tab.windowId||known.receiver.documentId!==tab.documentId||known.receiver.nonce!==top.nonce)fail('OUTCOME_UNKNOWN');
   const exactProbe=await this.#topCall(d,this.#tabs,this.#send,[tab.id,message,{documentId:tab.documentId}]);
   this.#topCharge(d,exactProbe);if(!same(top,exactProbe)||this.#receivers.get(tab.id)!==known)fail('OUTCOME_UNKNOWN');
  }finally{if(d.enrollment===e)d.enrollment=null;}
 }
 async holdCurrentTopDocumentsForApplicationSelection(){
  this.#admit();this.#inventoryIdentity();if(!this.#original()||this.#rotating||this.#knownDocumentHold||this.#topDocumentHold)fail('PROMPT_INSERTION_CAPABILITY');
  const work=this.#work(),hold={token:Object.freeze(Object.create(null)),valid:true,ready:false,deadline:work.deadline,receiptEpoch:this.#receiptEpoch,work,snapshot:null,error:null};
  const d={token:Object.freeze(Object.create(null)),hold,version:null,domainDigest:null,entries:[],failed:false,cleaning:false,error:null,topology:this.#topologyVersion,phase:'enumerating',enrollment:null,inventory:null};
  this.#selectionHold=hold;this.#topDocumentHold=d;for(const a of this.#actions.values())if(!a.invoked)a.valid=false;
  const acquire=(async()=>{
   await this.#initializeBinding();this.#topCheck(d);d.domainDigest=this.#domainDigest;d.inventory=await this.#topInventory(d);d.phase='enrolling';
   for(const tab of d.inventory)await this.#topEnroll(d,tab);
   this.#topCheck(d);if(this.#receivers.size!==d.inventory.length)fail('OUTCOME_UNKNOWN');
   for(const tab of d.inventory){const original=this.#receivers.get(tab.id);if(!original||original.url!==tab.url||original.receiver.documentId!==tab.documentId||original.receiver.windowId!==tab.windowId)fail('OUTCOME_UNKNOWN');const e={original,receiver:structuredClone(original.receiver),url:original.url,challenge:crypto.randomUUID(),attempted:false,settled:false,released:false,cleanupStarted:false};this.#topCharge(d,{receiver:e.receiver,url:e.url});d.entries.push(e);}
   d.phase='holding';d.version=this.#receiverVersion;this.#knownDocumentHold=d;
   for(const e of d.entries)await this.#knownAcquire(d,e);
   await this.#drain(hold);this.#knownCheck(d);this.#topCheck(d);const before=await this.#holdSnapshot(work);if(this.#trackingUnknown||before.ledger?.claims.some(c=>c.state==='pending'))fail('OUTCOME_UNKNOWN');
   await this.#knownFence(d);const finalInventory=await this.#topInventory(d);this.#topCharge(d,d.inventory);if(!same(finalInventory,d.inventory))fail('OUTCOME_UNKNOWN');
   const after=await this.#holdSnapshot(work);this.#knownCheck(d);this.#topCheck(d);if(this.#tasks.size||!same(before,after))fail('OUTCOME_UNKNOWN');hold.snapshot=after;hold.ready=true;d.phase='ready';return d.token;
  })();
  try{return await this.#wait(work,acquire);}catch(error){if(error?.code==='BNS_GROUP_RESOURCE_LIMIT')work.failed=true;d.failed=true;d.error=error;hold.valid=false;hold.error=new ArchiveError('OUTCOME_UNKNOWN');this.#knownStartCleanup(d);throw error;}
 }
 currentTopDocumentsHeldForApplicationSelection(token){const d=this.#topDocumentHold;try{return !!d&&d.token===token&&d.phase==='ready'&&(this.#topCheck(d),this.#knownHeld(d));}catch{return false;}}
 async fenceCurrentTopDocumentsForApplicationSelection(token){
  const d=this.#topDocumentHold;if(!this.currentTopDocumentsHeldForApplicationSelection(token))fail('OUTCOME_UNKNOWN');
  try{await this.#knownFence(d);const inventory=await this.#topInventory(d);this.#topCharge(d,d.inventory);if(!same(inventory,d.inventory))fail('OUTCOME_UNKNOWN');const snapshot=await this.#holdSnapshot(d.hold.work);if(!same(snapshot,d.hold.snapshot)||!this.currentTopDocumentsHeldForApplicationSelection(token))fail('OUTCOME_UNKNOWN');return true;}
  catch(error){if(error?.code==='BNS_GROUP_RESOURCE_LIMIT')d.hold.work.failed=true;d.failed=true;d.error=error;d.hold.valid=false;this.#knownStartCleanup(d);throw error;}
 }
 async #topCleanup(d){
  const known=this.#knownDocumentHold===d;
  this.#knownStartCleanup(d);
  // Known-stage RELEASE tasks belong to the original cleanup and must be
  // awaited there, not mistaken for unfinished early enumeration. With no
  // HOLD yet, timeout or unobserved original SDK work still cannot reopen.
  if(!known&&(d.hold.work.failed||budgetClock()>=d.hold.deadline||this.#trackingUnknown||this.#tasks.size))return false;
  if(!known)this.#knownDocumentHold=d;
  const released=await this.#knownCleanup(d);if(released&&this.#topDocumentHold===d)this.#topDocumentHold=null;return released;
 }
 releaseCurrentTopDocumentsForApplicationSelection(token){const d=this.#topDocumentHold;return d?.token===token?this.#topCleanup(d):originalResolveValue(false);}
 releaseFailedCurrentTopDocumentsForApplicationSelection(error){const d=this.#topDocumentHold;return d?.failed&&d.error===error&&error?this.#topCleanup(d):originalResolveValue(false);}

 dispose(){if(this.#topDocumentHold){this.#topDocumentHold.failed=true;this.#knownStartCleanup(this.#topDocumentHold);}for(const e of this.#inventorySource?.installed??[])try{originalApply(e.remove,e.event,[e.listener]);}catch{}if(this.#knownDocumentHold)this.#knownStartCleanup(this.#knownDocumentHold);if(this.#receiverVersion<Number.MAX_SAFE_INTEGER)this.#receiverVersion++;if(this.#selectionHold)this.#selectionHold.valid=false;this.#disposed=true;for(const a of this.#actions.values())a.valid=false;this.#receivers.clear();}
}

const originalReceiptPrototype=PromptInsertionReceipts.prototype;
const originalReceiptMethods=Object.getOwnPropertyNames(originalReceiptPrototype).filter(name=>name!=='constructor').map(name=>[name,Object.getOwnPropertyDescriptor(originalReceiptPrototype,name).value]);
