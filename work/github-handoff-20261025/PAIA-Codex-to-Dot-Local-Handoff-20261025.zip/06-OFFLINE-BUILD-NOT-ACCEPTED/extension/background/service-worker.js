import {createApplicationEditorGuard} from './application-editor-guard.js';
import {createApplicationWorkerCoordination} from './application-worker-coordination.js';
import {createApplicationLocalToolsCoordination} from './application-local-tools-coordination.js';
import {createApplicationTransportCoordination} from './application-transport-coordination.js';
import {createApplicationSelectionCommands,assertApplicationWorkerAdmission,createApplicationWorkerActivity} from './application-selection-commands.js';
import {createConfiguredSyncLifecycle,syncLifecycleError} from './sync-local-lifecycle.js';
import {MaintenanceProcessingCommands,configureMaintenanceProcessingSource} from './maintenance-processing-commands.js';
import {createAIFilterRuntime} from './ai-filter-commands.js';
import {readAIFilterPolicyConfiguration} from './ai-filter-policy-configuration.js';
import {readMaintenanceServiceConfiguration} from '../core/ai-usage/maintenance-service-configuration.js';
import {readMaintenanceIdentityCurrentnessEndpoint} from '../core/ai-usage/maintenance-identity-currentness-configuration.js';
import {AssistPromptCommands} from './prompt-assist.js';
import {createMaintenanceRunner,readMaintenanceRunnerSession} from '../core/ai-usage/maintenance-runner.js';
import {ContextReadService} from '../core/context-read.js';
import {ContextConnections} from './context-connections.js';
import {installContextConnectionLifecycle} from './context-connection-lifecycle.js';
import {TopicSectionPromotionCommands} from './topic-section-promotion-commands.js';
import {installToolbarEntry} from './toolbar-entry.js';
import {createConfiguredHistoricalCandidateSession} from '../core/ai-usage/configured-historical-session.js';
import {ArchiveArrival} from './archive-arrival.js';
import {NextPromptCommands} from './prompt-next.js';
import {readSettingsUpdateStatus} from '../core/settings-update-status.js';
import {isAIStyleOnlyRequest} from '../core/ai-organize-style-preference.js';
import {ContextCardsService} from '../core/context-cards.js';
import {ThoughtLibraryReadModel} from '../core/thought-library-read-model.js';
import {prepareTopicRootActivity} from '../core/organizer/topic-root-activity.js';
import {ThoughtSectionReading} from '../core/thought-section-reading.js';
import {topicRootTarget} from '../core/topic-root-target.js';
import {ContextTopicAccessService} from '../core/context-topic-access.js';
import {PromptSurfaceCommands} from './prompt-surface.js';
import {PromptReuseService} from '../core/prompt-reuse-service.js';
import {PromptReuseCommands} from './prompt-reuse-commands.js';
import {PromptInsertionReceipts} from './prompt-insertion-receipts.js';
import {ArchiveOriginalQuery} from '../core/archive-original-query.js';
import {installCaptureRecovery} from './capture-recovery.js';
import {ArchiveNavigationQuery} from '../core/archive-navigation-query.js';
import {MemoryService} from '../core/memory/service.js';
import {PassportService} from '../core/passport.js';
import {RevisitService} from '../core/revisit.js';
import {ReaderStateService} from '../core/reader-state.js';
import {OnboardingService} from '../core/onboarding.js';
import {IntegrityChecker} from '../core/integrity-checker.js';
import {BackupService} from '../core/backup-service.js';
import {LegacyUsageRecords} from '../core/legacy-usage-records.js';
import {assertFeatureAvailable} from '../core/feature-availability.js';
import {BoundedOrganizerWorkflow} from '../core/organizer/bounded-workflow.js';
import {createConfiguredOrganizeRunner} from '../core/organizer/configured-organize-runner.js';
import {readOrganizeServiceConfiguration} from '../core/ai-usage/organize-service-configuration.js';
import {createOrganizeActionSource} from './organize-action-source.js';
import {LibraryRunner} from '../core/library-runner.js';
import {FilterRunner} from '../core/filter-runner.js';
import {ImportHandler} from './import-handler.js';
import {safeImportError} from '../core/import/errors.js';
import {selectOriginalApplicationStore} from './application-store-selection.js';
import {createApplicationStartupEvents} from './application-startup-events.js';
import {SafetyRunner} from '../core/thought-runner.js';
import { ADAPTER_VERSION, ArchiveError, safeErrorCode } from '../core/constants.js';
import { canonicalChat } from '../core/validation.js';
import {canonicalProjectChat,canonicalPlainChat} from '../core/project-route-validation.js';
import {SourceStructureStore} from '../core/source-structure-store.js';
import {subjectRef,sourceStructureSnapshot} from '../core/source-structure-model.js';
import {admitChatGPTSourceStructureBatch,CHATGPT_PROJECT_STRUCTURE_POLICY} from '../core/source-structure-admission.js';
import {ArchiveOrderPreferenceService,SourceOrderRegistry,unavailableSourceOrderProvider} from '../core/source-ordering.js';
import {unavailableAIProvider,unavailableAICredentials} from '../core/organizer/unavailable-service.js';
import {SimpleOriginalOrganizerRunner} from '../core/organizer/original-simple.js';
import {RecoveryDraftStore} from '../core/recovery-draft.js';

let syncSuspended=false;
let applicationWorkerCoordination,applicationTransportCoordination,applicationLocalToolsCoordination;
let store,promptInsertionReceipts,syncLifecycle,maintenanceProcessing,maintenanceConfiguration,maintenanceRunner,contextConnections,localScopePreviewCapability,contextScopePreview,thoughtLibraryRead,sectionPromotion,thoughtSectionReading,promptReuse,archiveArrival,promptSurface,promptNext,promptAssist,legacyUsage,passport,revisit,readerState,sourceStructure,archiveNavigation,archiveOriginal,archiveOrderPreference,sourceOrderRegistry,originalOrganizer,organizeConfiguration,organizeActionSource,aiOrganizer,boundedOrganizer,onboarding,integrity,memory,contextTopics,contextCards,backups,imports,runner,safety,libraryRunner;
const startupEvents=createApplicationStartupEvents(chrome);
const aiFilterRuntime=createAIFilterRuntime(chrome,{getStore:()=>store,policy:readAIFilterPolicyConfiguration()});
async function initializeApplicationServices(){
store=await selectOriginalApplicationStore(chrome.storage.local,{aiFilterAuthority:aiFilterRuntime.authority});
// Default selection returns the original unopened Store. Recover its original
// publication, then establish its real database/control identity before any
// owner captures an immutable birth binding. Never refresh an owner's binding
// after construction to adopt a replacement generation.
await store.recoverControlPublication();
await store.status();
promptInsertionReceipts=new PromptInsertionReceipts(store,chrome);
maintenanceProcessing=new MaintenanceProcessingCommands(store,startupEvents);
maintenanceConfiguration=aiFilterRuntime.configureService(configureMaintenanceProcessingSource(maintenanceProcessing,store,readMaintenanceServiceConfiguration(store)),readMaintenanceIdentityCurrentnessEndpoint());
maintenanceRunner=createMaintenanceRunner(store,maintenanceConfiguration);
contextConnections=new ContextConnections(store,startupEvents);
localScopePreviewCapability=Object.freeze({});
contextScopePreview=new ContextReadService(store,{localPreviewCapability:localScopePreviewCapability});
thoughtLibraryRead=new ThoughtLibraryReadModel(store);
sectionPromotion=new TopicSectionPromotionCommands(store,chrome,{promotionSession:readMaintenanceRunnerSession(maintenanceRunner,store),checkpointStorage:{session:chrome.storage.session||null}});
thoughtSectionReading=new ThoughtSectionReading(thoughtLibraryRead);
promptReuse= new PromptReuseCommands(new PromptReuseService(store,{historyCandidates:createConfiguredHistoricalCandidateSession(store)}),chrome,{insertionReceipts:promptInsertionReceipts});
archiveArrival= new ArchiveArrival(promptReuse.service,chrome);
promptSurface= new PromptSurfaceCommands(promptReuse,chrome,{openArchiveArrival:(descriptor,source)=>archiveArrival.open(descriptor,source)});
promptNext= new NextPromptCommands(promptReuse.service,chrome,promptSurface,{insertionReceipts:promptInsertionReceipts});
promptSurface.next=promptNext;
promptAssist=new AssistPromptCommands(store,startupEvents,{surface:promptSurface,insertionReceipts:promptInsertionReceipts});
promptSurface.assist=promptAssist;
legacyUsage= new LegacyUsageRecords(store);
passport= new PassportService(store);
revisit= new RevisitService(store);
readerState= new ReaderStateService(store);
sourceStructure= new SourceStructureStore(store);
archiveNavigation= new ArchiveNavigationQuery(store);
archiveOriginal= new ArchiveOriginalQuery(store);
archiveOrderPreference= new ArchiveOrderPreferenceService(store);
sourceOrderRegistry= new SourceOrderRegistry([['chatgpt',unavailableSourceOrderProvider('UNVERIFIED')]]);
originalOrganizer=new SimpleOriginalOrganizerRunner(store,{provider:unavailableAIProvider,credentials:unavailableAICredentials});
organizeConfiguration=readOrganizeServiceConfiguration();
organizeActionSource=organizeConfiguration===null?null:createOrganizeActionSource(store,startupEvents);
aiOrganizer=createConfiguredOrganizeRunner(store,organizeConfiguration,{actionSource:organizeActionSource});
boundedOrganizer=new BoundedOrganizerWorkflow(store,{original:originalOrganizer,ai:aiOrganizer});
onboarding=new OnboardingService(store);
integrity=new IntegrityChecker(store);
memory=new MemoryService(store,{session:privacySession});
contextTopics=new ContextTopicAccessService(store);
contextCards=new ContextCardsService(store,{topicSummary:(t,epoch)=>contextTopics.summaryInTransaction(t,epoch)});
backups=new BackupService(store,{appVersion:chrome.runtime.getManifest().version});
imports= new ImportHandler(store,chrome.runtime);
runner=new FilterRunner(store,{changed:()=>{void trackApplicationWork(runtime.sendMessage?.({type:'ARCHIVE_CHANGED'})).catch(()=>{});}});
safety=new SafetyRunner(store);
libraryRunner=new LibraryRunner(store);
// Real original instances only. No command consumes a source hold until an
// admitted global selection contract exists; construction grants no readiness.
applicationWorkerCoordination=createApplicationWorkerCoordination({store,safety,libraryRunner,filterRunner:runner,maintenanceRunner,contextConnections,promptAssist,promptNext,promptCommands:promptReuse,promptSurface,boundedOrganizer});
applicationLocalToolsCoordination=createApplicationLocalToolsCoordination({imports,backups,integrity,store,runtime:chrome.runtime});
applicationTransportCoordination=createApplicationTransportCoordination({sourceCoordination:applicationWorkerCoordination,captureRecovery,promptInsertionReceipts,store,api:chrome});
}
chrome.tabs?.onRemoved?.addListener(id=>{void trackApplicationWork(ready.then(()=>{promptInsertionReceipts.removeTab(id);promptSurface.removeTab(id);promptNext.removeTab(id);promptAssist.removeTab(id);archiveArrival.removeTab(id);}).catch(()=>{}));});
chrome.tabs?.onUpdated?.addListener((id,change)=>{void trackApplicationWork(ready.then(()=>{if(change.url||change.status==='loading'){promptInsertionReceipts.removeTab(id);promptNext.removeTab(id);promptAssist.removeTab(id);}archiveArrival.changedTab(id,change);}).catch(()=>{}));});
// Missing new suggestion preferences are off; installation/update never resets a user preference.
let recoveryDrafts=null;
const recoveryDraftStore=()=>recoveryDrafts??=new RecoveryDraftStore(chrome.storage.local);
// Recovery storage and canonical IndexedDB are separate stores. Keep admission,
// storage completion and Source purge in one worker-owned serialized boundary.
let recoveryTail=Promise.resolve();
function withRecoveryFence(work){const result=recoveryTail.then(work);recoveryTail=result.catch(()=>{});return result;}
async function saveRecoveryDraft(draft){
 if(draft.kind==='settings_feedback'&&Object.keys(draft).some(key=>!['kind','ownerId','token','operation','sourceRecordIds','epoch'].includes(key)))throw new ArchiveError('INVALID_REQUEST');
 if(!(await store.status()).consented)throw new ArchiveError('CONSENT_REQUIRED');
 if(draft.epoch!==await store.recoveryDraftEpoch())throw new ArchiveError('INVALID_REQUEST');
 const sourceRecordIds=await (draft.kind==='context_item'?contextCards.recoverySources(draft):store.recoveryDraftSourceIds(draft));
 return recoveryDraftStore().save({...draft,sourceRecordIds});
}
async function loadRecoveryDraft({kind,ownerId,epoch}={}){
 if(kind==='settings_feedback'&&!(await store.status()).consented)throw new ArchiveError('CONSENT_REQUIRED');
 const current=await store.recoveryDraftEpoch();if(epoch!==current)throw new ArchiveError('INVALID_REQUEST');
 const draft=await recoveryDraftStore().load(kind,ownerId);if(!draft)return null;
 try{if((draft.epoch||'initial')!==current)throw new ArchiveError('INVALID_REQUEST');if(draft.kind==='context_item'&&await contextCards.recoveryCommitted(draft)){await recoveryDraftStore().clear(kind,ownerId,draft.token);return null;}await (draft.kind==='context_item'?contextCards.recoverySources(draft,{stored:true}):store.recoveryDraftSourceIds(draft));return draft;}
 catch(error){if(!['INVALID_REQUEST','CONTEXT_INVALIDATED'].includes(error?.code))throw error;await recoveryDraftStore().clear(kind,ownerId,draft.token);return null;}
}
// Bind recovery identity to the same read that supplied editor bodies. A
// replacement during a multi-transaction read discards that read; a later
// replacement leaves an old, correctly fenced token on the returned snapshot.
async function recoverySnapshot(read,decorate=(value,epoch)=>({...value,recoveryEpoch:epoch})){
 const epoch=await store.recoveryDraftEpoch(),value=await read();
 if(epoch!==await store.recoveryDraftEpoch())throw new ArchiveError('BACKUP_CHANGED');
 return decorate(value,epoch);
}
function recoveryDocumentPage(page,epoch){
 const tagged=value=>value?{...value,recoveryEpoch:epoch}:value;
 return {...page,recoveryEpoch:epoch,topic:tagged(page.topic),sections:page.sections?.map(tagged),items:page.items?.map(item=>item.entry?{...item,entry:tagged(item.entry)}:tagged(item))};
}

async function purgeWithRecovery(id,permanent){
 // A resident linked human/unknown draft is a B-02 dependency, not permission
 // to clear it. Admission and final revalidation happen before any cleanup.
 return permanent?store.permanentDelete(id):store.purge(id);
}
const UPDATE_STATE_KEY='paia-consumer-update:v1';
// Chrome owns installation. Keep only the version transition as local status;
// never force a worker reload while an archive page may have unsaved edits.
chrome.runtime.onUpdateAvailable?.addListener(details=>{
  if(typeof details?.version!=='string')return;
  void trackApplicationWork(ready.then(()=>chrome.storage.local.set({[UPDATE_STATE_KEY]:{
    state:'available',fromVersion:chrome.runtime.getManifest().version,toVersion:details.version,at:Date.now(),
  }})).catch(()=>{}));
});
chrome.runtime.onInstalled?.addListener(details=>{
  if(details?.reason!=='update')return;
  void trackApplicationWork(ready.then(()=>chrome.storage.local.set({[UPDATE_STATE_KEY]:{
    state:'installed',fromVersion:details.previousVersion||null,toVersion:chrome.runtime.getManifest().version,at:Date.now(),
  }})).catch(()=>{}));
});
// ChatGPT source ordering remains unavailable until a live provider contract is certified.
// No credential reader or direct provider is constructed by this worker.
const unavailableSession={get:async()=>{throw new ArchiveError('UNAVAILABLE');},set:async()=>{throw new ArchiveError('UNAVAILABLE');},remove:async()=>{throw new ArchiveError('UNAVAILABLE');}};
const privacySession=chrome.storage.session||unavailableSession;
chrome.runtime.onConnect?.addListener(port=>{if(port.name==='official-export-session')port.onDisconnect.addListener(()=>{void trackApplicationWork(ready.then(()=>imports.disconnect(port.sender)).catch(()=>{}));});});
chrome.runtime.onConnect?.addListener(port=>{if(port.name.startsWith('bounded-organizer:')&&isExtensionPage(port.sender)){const id=port.name.slice('bounded-organizer:'.length);port.onDisconnect.addListener(()=>{void trackApplicationWork(ready.then(()=>{if(boundedOrganizer.currentId===id&&boundedOrganizer.running)return boundedOrganizer.stop();}).catch(()=>{}));});}});
// Fail closed if storage isolation cannot be established; never expose records
// directly to a content script, including the brief worker-startup period.
const applicationIsolation=chrome.storage.local.setAccessLevel({ accessLevel: 'TRUSTED_CONTEXTS' });
const ready = applicationIsolation.then(initializeApplicationServices).then(async()=>{syncLifecycle=await createConfiguredSyncLifecycle(store,chrome);await syncLifecycle.attachPromptService(promptReuse.service);await syncLifecycle.attachContextService(contextCards);if(syncSuspended)syncLifecycle.suspend();});
const applicationEditors=createApplicationEditorGuard(chrome);
const applicationWorkerActivity=createApplicationWorkerActivity({remaining:()=>[safety?.running,libraryRunner?.running,runner?.running]});
function trackApplicationWork(task){return applicationWorkerActivity.track(task);}
chrome.runtime.onConnect?.addListener(port=>applicationEditors.connect(port));
const applicationSelection=createApplicationSelectionCommands(chrome,{isolated:()=>applicationIsolation,ready:()=>ready,lifecycle:()=>syncLifecycle,activity:applicationWorkerActivity});
const privacyReady=Promise.resolve(privacySession.setAccessLevel?.({accessLevel:'TRUSTED_CONTEXTS'}));
privacyReady.catch(()=>{});
ready.catch(() => {});
trackApplicationWork(ready).catch(()=>{});
// Register synchronously; startup only reconciles local receipts, never unknown IO.
chrome.runtime.onStartup?.addListener(()=>{void trackApplicationWork(ready.then(()=>syncLifecycle.reconcile()).catch(()=>{}));});
chrome.runtime.onSuspend?.addListener(()=>{syncSuspended=true;syncLifecycle?.suspend();applicationSelection.close();});
chrome.runtime.onSuspendCanceled?.addListener(()=>{syncSuspended=false;void trackApplicationWork(ready.then(()=>syncLifecycle.resumeAfterSuspend()).catch(()=>{}));});
const captureRecovery=installCaptureRecovery(chrome, ready);
// Register lifecycle listeners synchronously; the fixed facade reaches the one
// selected owner only after initialization. It grants no store/writer capability.
installContextConnectionLifecycle({
 resumeAuthorized:()=>trackApplicationWork(ready.then(()=>contextConnections.resumeAuthorized())),
 // A worker suspended before initialization has no live connection to checkpoint.
 // Do not promise deferred suspension work that Chrome may never execute.
 checkpointForSuspend:()=>trackApplicationWork(contextConnections?contextConnections.checkpointForSuspend():Promise.resolve({state:'uninitialized'})),
 resumeAfterSuspend:()=>trackApplicationWork(contextConnections?contextConnections.resumeAfterSuspend():Promise.resolve({resumed:0})),
 dispose:()=>{void trackApplicationWork(ready.then(()=>contextConnections.dispose()).catch(()=>{}));},
},chrome,ready);
const backupReady=ready.then(()=>backups.recoverSettings());backupReady.catch(()=>{});
const originalReady=Promise.all([ready,privacyReady,backupReady]).then(()=>Promise.all([originalOrganizer.reconcileInterrupted(),aiOrganizer.reconcileInterrupted(),boundedOrganizer.reconcileInterrupted()]));
originalReady.catch(()=>{});
trackApplicationWork(originalReady).catch(()=>{});

function isExtensionPage(sender) {
  if (sender.id !== chrome.runtime.id) return false;
  if (['ui/popup.html', 'ui/archive.html'].some(path => sender.url === chrome.runtime.getURL(path))) return true;
  return typeof sender.url==='string'&&sender.url.startsWith(chrome.runtime.getURL('ui/archive.html')+'#')&&topicRootTarget(sender.url)!==null;
}

function isChatGPTContent(sender) {
  if (sender.id !== chrome.runtime.id || !sender.tab || sender.frameId !== 0 || sender.tab.incognito) return false;
  try { return new URL(sender.url).origin === 'https://chatgpt.com'; }
  catch { return false; }
}

async function handle(request, sender, activityControl) {
  if(typeof request?.type==='string'&&request.type.startsWith('PAIA_GENERATION_'))return applicationSelection.handle(request,sender,activityControl);
  assertApplicationWorkerAdmission(applicationEditors,request,sender);
  if(request?.type==='PAIA_SYNC_STATUS'&&applicationSelection.enabled){
   await applicationIsolation;try{await ready;}catch(error){if(error?.code!=='GENERATION_SELECTION_PENDING')throw error;}
   const view=syncLifecycle?await syncLifecycle.handle(request,sender):{version:1,state:'unavailable',reason:'provider-not-configured',productionActivation:false};
   return applicationSelection.decorate(request,sender,view);
  }
  await ready;
  if (!request || typeof request.type !== 'string') throw new ArchiveError('INVALID_REQUEST');
  // Startup awaits cannot carry an earlier admission across a newly held page.
  assertApplicationWorkerAdmission(applicationEditors,request,sender);
  if(request.type.startsWith('PAIA_SYNC_'))return syncLifecycle.handle(request,sender);
  if(request.type.startsWith('PAIA_MAINTENANCE_PROCESSING_'))return maintenanceProcessing.handle(request,sender);
  if(request.type.startsWith('PAIA_ARCHIVE_ARRIVAL_'))return archiveArrival.handle(request,sender);
  if(request.type==='PAIA_PROMPT_INSERTION_RECEIVER_REGISTER')return promptInsertionReceipts.registerReceiver(request,sender);
  if(request.type==='PAIA_PROMPT_INSERTION_ACK')return promptInsertionReceipts.handleAck(request,sender);
  if(request.type==='PAIA_PROMPT_INSERTION_RECONCILE')return promptInsertionReceipts.handleReconcile(request,sender);
  if(request.type==='PAIA_PROMPT_INSERTION_QUALIFY')return promptInsertionReceipts.handleQualify(request,sender);
  if(request.type.startsWith('PAIA_PROMPT_ASSIST_'))return promptAssist.handle(request,sender);
  if(request.type.startsWith('PAIA_PROMPT_NEXT_'))return promptNext.handle(request,sender);
  if(request.type.startsWith('PAIA_PROMPT_SURFACE_'))return promptSurface.handle(request,sender);
  if(request.type.startsWith('PAIA_PROMPT_'))return promptReuse.handle(request,sender);
  if(request.type.startsWith('IMPORT_'))return imports.handle(request,sender);
  const ui = isExtensionPage(sender);
  const content = isChatGPTContent(sender);
  if (content && request.type === 'RESPONSE_POLL') return {arm:false,fingerprintAllowed:false};
  if (!ui && !content) throw new ArchiveError('FORBIDDEN');
  if (request.type === 'GET_STATUS') {
    const status = await store.status();
    return content ? {...status, runtimeVersion: chrome.runtime.getManifest().version} : status;
  }
  if (content && request.type === 'DIAGNOSTIC') {
    // A mismatched content version may report only this fixed reason, never its
    // own version string, structural payload, or any other page-derived fields.
    if (request.code === 'ADAPTER_VERSION_MISMATCH') {
      return store.diagnose({ code: 'ADAPTER_VERSION_MISMATCH', scanned: 0 });
    }
    if (request.adapterVersion !== ADAPTER_VERSION) throw new ArchiveError('INVALID_REQUEST');
    return store.diagnose({ code: request.code, scanned: request.scanned, structure: request.structure, captureHealth: request.captureHealth });
  }
  if (content && ['CAPTURE', 'ENRICH_SOURCE_METADATA', 'OBSERVE_SOURCE_STRUCTURE'].includes(request.type) &&
      request.contentVersion !== chrome.runtime.getManifest().version) throw new ArchiveError('CONTEXT_INVALIDATED');
  if (content && request.type === 'OBSERVE_SOURCE_STRUCTURE') {
    if(Object.keys(request).some(key=>!['type','epoch','adapterVersion','contentVersion','chat','observations'].includes(key))||
       request.adapterVersion!==ADAPTER_VERSION||!Array.isArray(request.observations)||
       !request.observations.length||request.observations.length>4)throw new ArchiveError('INVALID_REQUEST');
    const source=canonicalChat(sender.tab.url ?? sender.url);
    const target=canonicalChat(request.chat?.url);
    if(!source||!target||source.id!==target.id||source.id!==request.chat?.id)throw new ArchiveError('FORBIDDEN');
    const trustedProject=canonicalProjectChat(sender.tab.url ?? sender.url);
    const trustedPlain=canonicalPlainChat(sender.tab.url ?? sender.url);
    const status=await store.status();
    if(!status.consented)throw new ArchiveError('CONSENT_REQUIRED');
    if(!status.enabled)throw new ArchiveError('PAUSED');
    if(status.epoch!==request.epoch||
       request.observations.some(observation=>observation?.epoch!==request.epoch))throw new ArchiveError('STALE_CAPTURE');
    const admitted=await admitChatGPTSourceStructureBatch(request.observations);
    for(const item of admitted){
      if(item.kind==='conversation'){
        if(item.conversationRef.platform!=='chatgpt'||item.conversationRef.sourceConversationId!==source.id)throw new ArchiveError('FORBIDDEN');
        if(item.membership?.state==='project'){
          if(!trustedProject||trustedProject.id!==source.id||
             item.membership.projectRef.namespace!==CHATGPT_PROJECT_STRUCTURE_POLICY.namespace||
             item.membership.projectRef.projectId!==trustedProject.projectId)throw new ArchiveError('FORBIDDEN');
        }else if(item.membership?.state==='unassigned'){
          if(!trustedPlain||trustedPlain.id!==source.id)throw new ArchiveError('FORBIDDEN');
        }
      }else if(item.kind==='project'){
        if(!trustedProject||trustedProject.id!==source.id||
           item.projectRef.namespace!==CHATGPT_PROJECT_STRUCTURE_POLICY.namespace||
           item.projectRef.projectId!==trustedProject.projectId||
           item.witnessConversationRef?.platform!=='chatgpt'||
           item.witnessConversationRef?.sourceConversationId!==source.id)throw new ArchiveError('FORBIDDEN');
      }else throw new ArchiveError('FORBIDDEN');
    }
    return sourceStructure.observeAdmittedBatch(admitted);
  }
  if (content && ['CAPTURE', 'ENRICH_SOURCE_METADATA'].includes(request.type)) {
    // sender.url can stay at the document's initial address after pushState.
    // Chrome supplies the tab's current URL on MessageSender without a tabs
    // permission. Prefer it to verify SPA routing; never query browser history.
    const source = canonicalChat(sender.tab.url ?? sender.url);
    const target = canonicalChat(request.chat?.url);
    if (!source || !target || source.id !== target.id || source.id !== request.chat?.id) throw new ArchiveError('FORBIDDEN');
    return request.type === 'CAPTURE' ? store.capture(request) : store.enrich(request);
  }
  if (!ui || ['ENRICH_SOURCE_METADATA','OBSERVE_SOURCE_STRUCTURE'].includes(request.type)) throw new ArchiveError('FORBIDDEN');
  const styleRequest=request.type==='PAIA_SETTINGS_AI_STYLE'||isAIStyleOnlyRequest(request);
  if(styleRequest){
    if(sender.url===chrome.runtime.getURL('ui/popup.html')||(sender.frameId!==undefined&&sender.frameId!==0)||sender.tab?.incognito)throw new ArchiveError('FORBIDDEN');
    const allowed=request.type==='PAIA_SETTINGS_AI_STYLE'?['type']:['type','changes'];if(Object.keys(request).some(key=>!allowed.includes(key)))throw new ArchiveError('INVALID_REQUEST');
  }
  if(request.type==='PURGE_SOURCE'&&(request.confirm!==true||Object.keys(request).some(key=>!['type','id','confirm'].includes(key))))throw new ArchiveError('INVALID_REQUEST');
  const needsConsent=request.type.startsWith('PAIA_AI_FILTER_')||request.type==='START_BOUNDED_ORGANIZER'||request.type==='EDIT_DOCUMENT'&&request.edit?.removeScope!==undefined||request.type.startsWith('PAIA_ARCHIVE_')||request.type.startsWith('PAIA_RECOVERY_')||['PURGE_SOURCE','PURGE_RECORD','ADD_TO_TOPICS','CONTINUE_THINKING','COMPARE_THOUGHT_INPUT','RESTORE_THOUGHT_INPUT','THOUGHT_EDIT_HISTORY','THOUGHT_POSITION','GET_THOUGHT_REVERSE_EDIT','SET_THOUGHT_REVERSE_EDIT','GET_THOUGHT_LAYOUT','SET_THOUGHT_LAYOUT'].includes(request.type)||request.type.startsWith('PAIA_CONTEXT_')||request.type.startsWith('PAIA_READER_')||request.type.startsWith('PAIA_MEMORY_')||request.type.startsWith('PAIA_REVISIT_')||request.type.startsWith('PAIA_INTEGRITY_')||request.type.startsWith('PAIA_BACKUP_')||request.type==='PAIA_CORE_LOOP_ACTION'||request.type.includes('LIBRARY')||request.type.includes('AI_PRESENTATION')||request.type==='TOPIC_DOCUMENT_PAGE'||request.type==='PAIA_PASSPORT_CREATE'||request.type==='PAIA_CONTEXT_BIND';
  if(needsConsent&&request.type!=='GET_LIBRARY_FOUNDATION_STATUS'&&!(await store.status()).consented)throw new ArchiveError('CONSENT_REQUIRED');
  assertFeatureAvailable(request);
  if(['START_BOUNDED_ORGANIZER','STOP_BOUNDED_ORGANIZER','GET_BOUNDED_ORGANIZER','UPDATE_AI_PRESENTATION','GET_AI_PRESENTATION_SCOPE','GET_AI_PRESENTATION_OPERATION_OUTCOME','STOP_AI_PRESENTATION','GET_AI_PRESENTATION_STATUS','EDIT_AI_PRESENTATION','UPDATE_ORIGINAL_LIBRARY_VIEW','STOP_ORIGINAL_LIBRARY_VIEW','GET_ORIGINAL_ORGANIZER_STATUS'].includes(request.type))await originalReady;
  if(request.type.startsWith('PAIA_BACKUP_')||styleRequest)await backupReady;
  if(request.type==='PAIA_LIBRARY_SECTION_PROMOTION')return sectionPromotion.handle(request,sender);
  switch (request.type) {
    case 'PAIA_SETTINGS_AI_STYLE': return store.aiStylePreference();
    case 'PAIA_SETTINGS_UPDATE_STATUS': {
      if(sender.url===chrome.runtime.getURL('ui/popup.html')||(sender.frameId!==undefined&&sender.frameId!==0)||sender.tab?.incognito)throw new ArchiveError('FORBIDDEN');
      if(Object.keys(request).some(key=>key!=='type'))throw new ArchiveError('INVALID_REQUEST');
      return readSettingsUpdateStatus(chrome.storage.local,chrome.runtime.getManifest().version);
    }
    case 'PAIA_CONTEXT_ITEM_BASIS': {
      if(sender.url!==chrome.runtime.getURL('ui/archive.html')||(sender.frameId!==undefined&&sender.frameId!==0)||sender.tab?.incognito)throw new ArchiveError('FORBIDDEN');
      if(Object.keys(request).some(key=>!['type','options'].includes(key)))throw new ArchiveError('INVALID_REQUEST');
      return contextCards.basis(request.options);
    }
    case 'PAIA_CONTEXT_SCOPE_PREVIEW': {
      if(sender.url!==chrome.runtime.getURL('ui/archive.html')||(sender.frameId!==undefined&&sender.frameId!==0)||sender.tab?.incognito)throw new ArchiveError('FORBIDDEN');
      if(Object.keys(request).some(key=>!['type','kind','options'].includes(key)))throw new ArchiveError('INVALID_REQUEST');
      return contextScopePreview.preview(localScopePreviewCapability,{kind:request.kind,options:request.options});
    }
    case 'PAIA_CONTEXT_CARDS_DRAFTS': return withRecoveryFence(async()=>{const captured=await contextCards.recoveryBatchFence(),drafts=[];for(const ref of await recoveryDraftStore().list('context_item')){const draft=await loadRecoveryDraft(ref);if(draft)drafts.push(draft);}await contextCards.recoveryBatchFence(captured);return drafts;});
    case 'PAIA_AI_FILTER_STATUS':
    case 'PAIA_AI_FILTER_CONFIGURE': return aiFilterRuntime.handle(request,sender);
    case 'PAIA_CONTEXT_CONNECTIONS_STATUS': {
      if(Object.keys(request).some(key=>key!=='type'))throw new ArchiveError('INVALID_REQUEST');return contextConnections.status();
    }
    case 'PAIA_CONTEXT_CONNECTIONS_PAIR':
    case 'PAIA_CONTEXT_CONNECTIONS_REPAIR':
    case 'PAIA_CONTEXT_CONNECTIONS_CHANGE': {
      if(sender.url!==chrome.runtime.getURL('ui/archive.html')||(sender.frameId!==undefined&&sender.frameId!==0)||sender.tab?.incognito)throw new ArchiveError('FORBIDDEN');
      if(Object.keys(request).some(key=>!['type','options'].includes(key)))throw new ArchiveError('INVALID_REQUEST');
      const options=request.options,keys=request.type!=='PAIA_CONTEXT_CONNECTIONS_CHANGE'?['expectedRevision','port']:['id','action','expectedRevision'];
      if(options&&Object.hasOwn(options,'authorizationPolicyId')){if(typeof options.authorizationPolicyId!=='string'||request.type==='PAIA_CONTEXT_CONNECTIONS_CHANGE'&&options.action!=='reconnect')throw new ArchiveError('INVALID_REQUEST');keys.push('authorizationPolicyId');}
      if(!options||typeof options!=='object'||Array.isArray(options)||Object.keys(options).length!==keys.length||Object.keys(options).some(key=>!keys.includes(key)))throw new ArchiveError('INVALID_REQUEST');
      return request.type!=='PAIA_CONTEXT_CONNECTIONS_CHANGE'?contextConnections.pair(options,{replaceStale:request.type==='PAIA_CONTEXT_CONNECTIONS_REPAIR'}):contextConnections.change(options);
    }
    case 'PAIA_CONTEXT_CARDS_SNAPSHOT': {if(Object.keys(request).some(key=>!['type','mode'].includes(key)))throw new ArchiveError('INVALID_REQUEST');const snapshot=await contextCards.snapshot(request.mode);if(snapshot.automaticEvaluation?.complete===false)throw new ArchiveError('CONTEXT_INVALIDATED');const connectionStatus=await contextConnections.status(),maintenance=maintenanceRunner.status();return {...snapshot,maintenance,connectionStatus,connections:connectionStatus.connectedCount,capabilities:{...snapshot.capabilities,automatic:maintenance.available,external:connectionStatus.connectedCount>0}};}
    case 'PAIA_CONTEXT_CARDS_CHANGE': return contextCards.change(request.change);
    case 'PAIA_CONTEXT_CARDS_OUTCOME': return contextCards.outcome(request.query);
    case 'PAIA_CONTEXT_TOPICS_PAGE':
      if(Object.keys(request).some(key=>!['type','options'].includes(key)))throw new ArchiveError('INVALID_REQUEST');
      return contextTopics.page(request.options===undefined?{}:request.options);
    case 'PAIA_CONTEXT_TOPICS_CHANGE':
      if(Object.keys(request).some(key=>!['type','change'].includes(key)))throw new ArchiveError('INVALID_REQUEST');
      return contextTopics.change(request.change);
    case 'PAIA_CONTEXT_TOPICS_OUTCOME':
      if(Object.keys(request).some(key=>!['type','query'].includes(key)))throw new ArchiveError('INVALID_REQUEST');
      return contextTopics.outcome(request.query);
    case 'PAIA_ARCHIVE_SOURCE_PURGE_PREFLIGHT': {
      if(Object.keys(request).some(key=>!['type','id'].includes(key)))throw new ArchiveError('INVALID_REQUEST');
      return withRecoveryFence(()=>store.sourcePurgePreflight(request.id));
    }
    case 'PAIA_RECOVERY_DRAFT_SAVE': return withRecoveryFence(()=>saveRecoveryDraft(request.draft||{}));
    case 'PAIA_RECOVERY_DRAFT_LOAD': return withRecoveryFence(()=>loadRecoveryDraft(request.draft));
    case 'PAIA_RECOVERY_DRAFT_CLEAR': {const d=request.draft||{};return withRecoveryFence(()=>recoveryDraftStore().clear(d.kind,d.ownerId,d.token??null));}
    case 'PAIA_RECOVERY_DRAFT_CLEAR_MANY': return withRecoveryFence(()=>recoveryDraftStore().clearMany(request.drafts||[]));
    case 'PAIA_RECOVERY_DRAFT_PRUNE': return withRecoveryFence(()=>recoveryDraftStore().prune());
    case 'PAIA_ARCHIVE_OPERATION_OUTCOME': {
      if(Object.keys(request).some(key=>!['type','query'].includes(key)))throw new ArchiveError('INVALID_REQUEST');
      return store.operationOutcome(request.query);
    }
    case 'PAIA_ARCHIVE_PREPARE_REMOVAL': {
      if(Object.keys(request).some(key=>!['type','removal'].includes(key)))throw new ArchiveError('INVALID_REQUEST');
      return store.prepareRemoval(request.removal);
    }
    case 'PAIA_ARCHIVE_PREPARE_REVISION': {
      if(Object.keys(request).some(key=>!['type','revision'].includes(key)))throw new ArchiveError('INVALID_REQUEST');
      return store.prepareWorkingRevision(request.revision);
    }
    case 'PAIA_ARCHIVE_ORIGINAL_PAGE': {
      if(Object.keys(request).some(key=>!['type','page'].includes(key)))throw new ArchiveError('INVALID_REQUEST');
      return archiveOriginal.page(request.page);
    }
    case 'PAIA_ARCHIVE_NAV_PAGE': return archiveNavigation.page(request.page);
    case 'PAIA_ARCHIVE_NAV_STATUS': return archiveNavigation.status(request.page);
    case 'PAIA_ARCHIVE_ORDER_PREFERENCE': {
      if(Object.keys(request).some(key=>!['type','mode'].includes(key)))throw new ArchiveError('INVALID_REQUEST');
      const preference=request.mode===undefined?await archiveOrderPreference.read():await archiveOrderPreference.write(request.mode);
      return {...preference,providers:{chatgpt:sourceOrderRegistry.status('chatgpt')}};
    }
    case 'PAIA_ARCHIVE_SOURCE_DETAIL': {
      if(Object.keys(request).some(key=>!['type','subject'].includes(key)))throw new ArchiveError('INVALID_REQUEST');
      const subject=subjectRef(request.subject),current=subject.kind==='conversation'?await sourceStructure.conversation(subject.conversationRef):await sourceStructure.project(subject.projectRef),history=await sourceStructure.history(subject,{limit:40});
      return {subject,current:current?{...sourceStructureSnapshot(current),lastObservedAt:current.lastObservedAt,relationshipRevision:current.relationshipRevision}:null,history:history.items.map(row=>({observedAt:row.observedAt,change:[...row.change],after:structuredClone(row.after)})),hasMore:history.nextCursor!==null};
    }
    case 'PAIA_PRODUCT_STATUS': return legacyUsage.status();
    case 'PAIA_PRODUCT_SETTINGS': return legacyUsage.settings(request.settings);
    case 'PAIA_PRODUCT_CLEAR': if(request.confirm!==true)throw new ArchiveError('INVALID_REQUEST');return legacyUsage.clear();
    case 'PAIA_REVISIT_STATUS': return revisit.status(request.options);
    case 'PAIA_REVISIT_OPEN': return revisit.open(request.options);
    case 'PAIA_REVISIT_CLOSE': return revisit.close(request.options);
    case 'PAIA_READER_RECENT': return readerState.recent();
    case 'PAIA_READER_RESOLVE': return readerState.resolve(request.documentId);
    case 'PAIA_READER_SAVE': return readerState.save(request.anchor);
    case 'PAIA_READER_POLICY': return readerState.policy();
    case 'PAIA_READER_CONFIGURE': return readerState.configure(request.change);
    case 'PAIA_READER_CAPTURE_SCOPE': return readerState.captureScope(request.options);
    case 'PAIA_REVISIT_MARK': return revisit.mark(request.anchor);
    case 'PAIA_PASSPORT_STATUS': return passport.status();
    case 'PAIA_PASSPORT_REVOKE': return passport.revoke(request.grantId);
    case 'PAIA_PASSPORT_REVOKE_ALL': {
      if(Object.keys(request).some(key=>key!=='type'))throw new ArchiveError('INVALID_REQUEST');
      return passport.revokeAll();
    }
    case 'PAIA_PASSPORT_CLEAR_AUDITS': if(request.confirm!==true)throw new ArchiveError('INVALID_REQUEST');return passport.clearAudits();
    case 'REMOVE_LIBRARY_TOPIC': return store.removeTopic(request.edit);
    case 'RESTORE_LIBRARY_TOPIC': return store.restoreTopicContainer(request.edit);
    case 'GET_LIBRARY_REMOVED_TOPICS': return store.removedTopics(request.options);
    case 'GET_LIBRARY_RENAME_SUGGESTIONS': return store.topicRenameSuggestions();
    case 'GET_LIBRARY_MERGE_SUGGESTIONS': return store.topicMergeSuggestions();
    case 'KEEP_LIBRARY_TOPICS_SEPARATE': return store.keepTopicsSeparate(request.options);
    case 'PAIA_MEMORY_STATUS': return memory.status(request.options);
    case 'PAIA_MEMORY_AUTHORIZE': return memory.authorize(request.options);
    case 'PAIA_MEMORY_EXCLUDE': return memory.exclude(request.options);
    case 'PAIA_MEMORY_SETTINGS': {const result=await memory.settings(request.options);if(request.options?.localOnly===true)await boundedOrganizer.stop();return result;}
    case 'PAIA_MEMORY_ENTRIES': return memory.entries(request.options);
    case 'PAIA_INTEGRITY_BEGIN': return integrity.begin();
    case 'PAIA_INTEGRITY_PAGE': return integrity.page(request.options);
    case 'PAIA_INTEGRITY_CANCEL': return integrity.cancel(request.options);
    case 'PAIA_BACKUP_BEGIN_RESTORE': return backups.beginRestore();
    case 'PAIA_BACKUP_STAGE': return backups.stageRestore(request.options);
    case 'PAIA_BACKUP_PREVIEW': return backups.previewRestore(request.options);
    case 'PAIA_BACKUP_RESTORE': return withRecoveryFence(async()=>{await promptNext.configure(false);await promptAssist.configure({replyAccess:false,remoteProcessing:false});const result=await backups.restore(request.options);if(request.options?.mode!=='merge')await recoveryDraftStore().clearAll().catch(()=>{});return result;});
    case 'PAIA_BACKUP_CANCEL': return backups.cancel(request.options);
    case 'GET_BOUNDED_ORGANIZER': return boundedOrganizer.status();
    case 'STOP_BOUNDED_ORGANIZER': return boundedOrganizer.stop();
    case 'GET_ONBOARDING': return onboarding.status();
    case 'SET_ONBOARDING': return onboarding.action(request.action);
    case 'GET_ORGANIZER_CONTROLS': return store.organizerControls();
    case 'SET_ORGANIZER_CONTROLS': return store.setOrganizerControls(request.changes);
    case 'GET_AI_PRESENTATION_REVISIONS': return store.aiPresentationRevisions(request.options);
    case 'LIBRARY_UPDATES': return store.suggestionPage(request.options);
    case 'RESOLVE_LIBRARY_UPDATE': return store.resolveSuggestion(request.edit);
    case 'LIBRARY_ORGANIZER_JOBS': return store.organizerJobPage(request.options);
    case 'GET_LIBRARY_DUAL_VIEW_STATUS': return store.dualViewStatus();
    case 'GET_ORIGINAL_ORGANIZER_STATUS': return store.originalOrganizerStatus();
    case 'GET_AI_PRESENTATION_OPERATION_OUTCOME': return store.aiPresentationOperationOutcome(request.options);
    case 'GET_AI_PRESENTATION_SCOPE': return aiOrganizer.handle(request,sender);
    case 'UPDATE_AI_PRESENTATION': return aiOrganizer.handle(request,sender);
    case 'STOP_AI_PRESENTATION': return aiOrganizer.stop({topicId:request.topicId});
    case 'GET_AI_PRESENTATION_STATUS': return recoverySnapshot(()=>aiOrganizer.status(request.options),(value,epoch)=>({...value,topics:value.topics.map(topic=>({...topic,recoveryEpoch:epoch,presentation:topic.presentation?{...topic.presentation,recoveryEpoch:epoch}:null}))}));
    case 'RECOVER_AI_PRESENTATION_DRAFT': return store.recoverAIDraft(request.options);
    case 'EDIT_AI_PRESENTATION': return store.editAIPresentation(request.edit);
    case 'STOP_ORIGINAL_LIBRARY_VIEW': return originalOrganizer.stop('CANCELLED');
    case 'CONTROL_LIBRARY_ORGANIZER_JOB': return store.controlOrganizer(request.edit);
    case 'FILTER_RECOVER': return store.recoverFilters();
    case 'FILTER_STATUS': return store.filterStatus();
    case 'FILTER_MODE': return store.setFilterMode(request.mode);
    case 'FILTER_NOTICE': return store.takeFilterNotice();
    case 'FILTER_RECENT': return store.recentFiltered(request.options);
    case 'FILTER_PROTECT': return store.protectUserInput(request.id);
    case 'FILTER_KEEP': return store.keepInput(request.id);
    case 'SEARCH_INPUTS': return store.searchInputs(request.options);
    case 'GET_INPUT': return recoverySnapshot(()=>store.input(request.id));
    case 'RECORD_TOPIC_READ': return store.recordTopicRead(request.id);
    case 'LIBRARY_INDEX_PAGE': return store.libraryIndexPage(request.options);
    case 'GET_LIBRARY_ROOT_PROJECTION': {
      thoughtLibraryRead.validateRootOptions(request.options);
      if(!request.options?.cursor)await prepareTopicRootActivity(store);
      return thoughtLibraryRead.rootPage(request.options);
    }
    case 'GET_LIBRARY_ROOT_PREVIEWS': {
      if(Object.keys(request).some(key=>!['type','options'].includes(key)))throw new ArchiveError('INVALID_REQUEST');
      return thoughtLibraryRead.rootPreviews(request.options);
    }
    case 'GET_LIBRARY_SECTION_PROJECTION': return thoughtLibraryRead.sectionPage(request.options);
    case 'GET_LIBRARY_TOPIC_READING_METADATA': {
      if(Object.keys(request).some(key=>!['type','id'].includes(key)))throw new ArchiveError('INVALID_REQUEST');
      return thoughtLibraryRead.topicReadingMetadata({id:request.id});
    }
    case 'GET_LIBRARY_SECTION_READING': {
      if(Object.keys(request).some(key=>!['type','options'].includes(key)))throw new ArchiveError('INVALID_REQUEST');
      const page=await thoughtSectionReading.page(request.options);
      // Preserve the epoch captured with these bodies; never retag an old read
      // with a separately fetched post-restore epoch. Decoration is synchronous.
      return typeof page.recoveryEpoch==='string'?recoveryDocumentPage(page,page.recoveryEpoch):page;
    }
    case 'GET_LIBRARY_ROOT_SEARCH': {
      const options=request.options;if(!options||typeof options.query!=='string'||!options.query.trim()||Object.keys(options).some(key=>!['query','cursor','authority','limit'].includes(key)))throw new ArchiveError('INVALID_REQUEST');
      const page=await store.libraryIndexPage({mode:'stable',...options});return thoughtLibraryRead.qualifySearchPage(page,options.query);
    }
    case 'TOPIC_DOCUMENT_PAGE': return recoverySnapshot(()=>store.topicDocumentPage(request.options),recoveryDocumentPage);
    case 'GET_LIBRARY_TRACKED_ENTRIES': return store.trackedLibraryEntries(request.options);
    case 'GET_LIBRARY_TOPIC_SECTIONS': return recoverySnapshot(()=>store.topicSectionsPage(request.options),recoveryDocumentPage);
    case 'GET_LIBRARY_TOPIC_ADJACENCY': return store.topicAdjacency(request.options);
    case 'GET_LIBRARY_TOPIC_TIMELINE': return recoverySnapshot(()=>store.topicTimelinePage(request.options),recoveryDocumentPage);
    case 'GET_LIBRARY_TOPIC': return recoverySnapshot(()=>store.topic(request.id));
    case 'THOUGHT_POSITION': return store.topicPosition(request.position);
    case 'THOUGHT_EDIT_HISTORY': return store.thoughtEditHistory(request.edit);
    case 'ADD_TO_TOPICS': return store.addToTopics(request.selection);
    case 'CONTINUE_THINKING': return store.continueThinking(request.thought);
    case 'COMPARE_THOUGHT_INPUT': return store.compareThought(request.id);
    case 'RESTORE_THOUGHT_INPUT': return store.restoreThoughtInput(request.edit);
    case 'GET_THOUGHT_LAYOUT': return store.thoughtLayout();
    case 'SET_THOUGHT_LAYOUT': return store.thoughtLayout(request.layout);
    case 'GET_THOUGHT_REVERSE_EDIT': return store.reverseEditSetting();
    case 'SET_THOUGHT_REVERSE_EDIT': return store.reverseEditSetting(request.enabled);
    case 'GET_LIBRARY_ENTRY': return recoverySnapshot(()=>store.readingEntry(request.id));
    case 'GET_LIBRARY_REMOVED_PLACEMENTS': return store.removedPlacements(request.options);
    case 'RESTORE_LIBRARY_PLACEMENT': return store.restoreRemovedPlacement(request.edit);
    case 'GET_LIBRARY_PLACEMENT': return store.libraryPlacement(request.topicId,request.entryId);
    case 'GET_LIBRARY_PATHS': return store.entryPaths(request.id);
    case 'GET_LIBRARY_PROVENANCE': return store.libraryProvenance(request.id);
    case 'GET_LIBRARY_UNPLACED': return store.unplacedEntries(request.options);
    case 'GET_LIBRARY_REMOVED': return store.removedEntries(request.options);
    case 'SEARCH_LIBRARY': return store.searchLibrary(request.options);
    case 'GET_LIBRARY_LAYOUT': return store.layoutStatus(request.id);
    case 'RETRY_LIBRARY_MAINTENANCE': void trackApplicationWork(libraryRunner.wake({retry:true}));return {ok:true};
    case 'REBUILD_LIBRARY_SEARCH': return store.rebuildLibrarySearch();
    case 'CREATE_LIBRARY_ENTRY': {
      const r=request.entry;
      if(!r||Object.keys(r).some(k=>!['title','body','note','type','operationId'].includes(k)))throw new ArchiveError('INVALID_REQUEST');
      return store.createEntry({...r,actor:'user',formation:'explicit',evidence:[]});
    }
    case 'EDIT_LIBRARY_FIELDS': return store.editLibraryFields(request.edit);
    case 'EDIT_LIBRARY_BATCH': return store.editLibraryBatch(request.edit);
    case 'REMOVE_LIBRARY_ENTRY': return store.removeEntry(request.edit);
    case 'RESTORE_LIBRARY_ENTRY': return store.restoreEntry(request.edit);
    case 'CREATE_LIBRARY_TOPIC': return store.createTopic(request.topic);
    case 'EDIT_LIBRARY_TOPIC': return store.editTopic(request.edit);
    case 'CREATE_LIBRARY_SECTION': return store.createSection(request.section);
    case 'EDIT_LIBRARY_SECTION': return store.editSection(request.edit);
    case 'PLACE_LIBRARY_ENTRY': return store.placeEntry(request.placement);
    case 'REORDER_LIBRARY_ENTRY': return store.reorderPlacement(request.placement);
    case 'START_LIBRARY_LAYOUT': return store.startLayout(request.layout);
    case 'GET_LIBRARY_FOUNDATION_STATUS': return store.libraryStatus();
    case 'GET_IA_STATUS': return store.iaStatus();
    case 'GET_REVISIONS': return store.revisions(request.options);
    case 'RESTORE_REVISION': return store.restoreRevision(request.restore);
    case 'PRUNE_REVISIONS': return store.pruneRevisions();
    case 'GET_THOUGHTS': return store.thoughtPage(request.options);
    case 'GET_THOUGHT': return store.thought(request.id);
    case 'EDIT_THOUGHT': return store.editThought(request.edit);
    case 'PURGE_SOURCE': return withRecoveryFence(()=>purgeWithRecovery(request.id,true));
    case 'GET_PAGE': return recoverySnapshot(()=>store.page(request.page));
    case 'GET_MIGRATION_STATUS': {const m=await store.migrationStatus();return m?{phase:m.phase,verified:m.verified,recoveryVerified:m.recoveryVerified,recordCount:m.recordCount,blockCount:m.blockCount}:{phase:'not_started'};}
    case 'RECOVER_MIGRATION': return store.recoverMigration();
    case 'EDIT_DOCUMENT': return store.editDocument(request.edit);
    case 'UPDATE_PREFERENCES': return store.updatePreferences(request.changes);
    case 'RESOLVE_LEGACY': return store.resolveLegacy(request.id,request.include);
    case 'UPDATE_LIBRARY': return store.updateLibrary(request.id, request.changes);
    case 'EXCLUDE_LIBRARY': return store.excludeLibrary(request.id, request.excluded);
    case 'UPDATE_DOCUMENT': return store.updateDocument(request.id, request.changes);
    case 'GET_MEMORY_CONTEXT': return store.memoryContext();
    case 'GET_STATE': return recoverySnapshot(()=>store.snapshot());
    case 'CONSENT': {if(request.accepted!==true){contextConnections.invalidate();aiFilterRuntime.invalidate();}return store.consent(request.accepted);}
    case 'SET_ENABLED': return store.setEnabled(request.enabled);
    case 'UPDATE_RECORD': return store.update(request.id, request.changes);
    case 'TRASH_RECORD': return store.trash(request.id);
    case 'RESTORE_RECORD': return store.restore(request.id);
    case 'PURGE_RECORD': return withRecoveryFence(()=>purgeWithRecovery(request.id,false));
    default: throw new ArchiveError('INVALID_REQUEST');
  }
}

const runtime=chrome.runtime;
let importNotification=null;
function notifyArchiveChanged(type){
 const send=cause=>trackApplicationWork(Promise.resolve(chrome.runtime.sendMessage?.({type:'ARCHIVE_CHANGED',cause})).catch(()=>{}));
 if(type==='IMPORT_COMMIT'){
  if(!importNotification){
   let settle;const pending=new Promise(resolve=>settle=resolve);
   const notification={timer:null,settle};importNotification=notification;trackApplicationWork(pending);
   notification.timer=setTimeout(()=>{if(importNotification===notification)importNotification=null;void send(type).finally(settle);},500);
  }
  return Promise.resolve();
 }
 // Coalescing a timer does not lose its accepted publication tail. The original
 // pending promise settles only after the replacement notification completes.
 const previous=importNotification;importNotification=null;if(previous)clearTimeout(previous.timer);
 const result=send(type);if(previous)void result.finally(previous.settle);return result;
}
function notifySourceStructureChanged(){
 return trackApplicationWork(Promise.resolve(chrome.runtime.sendMessage?.({type:'SOURCE_STRUCTURE_CHANGED'})).catch(()=>{}));
}
// Original Organizer is cost-gated: capture, startup, timers, and rerenders may
// maintain local state but can never dispatch its remote provider.
const scheduleFilter=(options)=>trackApplicationWork(Promise.all([safety.wake(options),libraryRunner.wake(options),runner.wake(options)]));
// Only original successful semantic-write messages offer an opportunity. Reads,
// settings, source metadata and duplicate capture never spend an accumulated
// Maintenance window. The session still proves actual eligible delta/consent.
const maintenanceWrites=new Set(['CAPTURE','EDIT_DOCUMENT','EXCLUDE_LIBRARY','PAIA_CONTEXT_CARDS_CHANGE','CREATE_LIBRARY_ENTRY','CONTINUE_THINKING','ADD_TO_TOPICS','EDIT_LIBRARY_FIELDS','EDIT_LIBRARY_BATCH','RESTORE_LIBRARY_ENTRY','EDIT_THOUGHT','RESTORE_THOUGHT_INPUT','PLACE_LIBRARY_ENTRY','RESTORE_LIBRARY_PLACEMENT','EDIT_LIBRARY_TOPIC','EDIT_LIBRARY_SECTION','RESTORE_LIBRARY_TOPIC']);
const maintenanceWrite=request=>maintenanceWrites.has(request?.type)&&(request.type!=='EDIT_DOCUMENT'||request.edit?.blocks?.length>0)&&(request.type!=='PAIA_CONTEXT_CARDS_CHANGE'||['put','delete','restore'].includes(request.change?.kind))&&(request.type!=='EDIT_LIBRARY_TOPIC'||['name','summary'].some(key=>Object.hasOwn(request.edit?.changes||{},key)));
const maintenanceMutation=(request,data)=>{
 if(!maintenanceWrite(request)||!data||data.ok===false||data.conflict===true||data.unavailable===true)return false;
 if(request.type==='CAPTURE')return Number(data.added)>0;
 if(['EDIT_DOCUMENT','PAIA_CONTEXT_CARDS_CHANGE'].includes(request.type))return data.ok===true;
 if(request.type==='EDIT_LIBRARY_FIELDS')return !!data.revisionId;
 if(request.type==='EDIT_LIBRARY_BATCH')return data.items?.some(item=>!!item.revisionId)===true;
 if(['EDIT_LIBRARY_TOPIC','EDIT_THOUGHT','EDIT_LIBRARY_SECTION','RESTORE_LIBRARY_ENTRY','RESTORE_LIBRARY_TOPIC'].includes(request.type))return data.revision>request.edit?.expectedRevision;
 return true;
};
let maintenanceOpportunity=null;
const scheduleMaintenance=(local=trackApplicationWork(ready.then(()=>scheduleFilter())))=>{
 trackApplicationWork(local);
 // Coalescing optional remote work must not skip ordinary local maintenance
 // for writes arriving while the earlier opportunity is still in flight.
 if(maintenanceOpportunity){void local.catch(()=>{});return maintenanceOpportunity;}
 const task=local.then(async()=>{
  // Local runners may have accepted another wake during their current drain.
  // Await those original drains too, and fail closed on local safety failure.
  for(;;){const pending=[safety.running,libraryRunner.running,runner.running].filter(Boolean);if(!pending.length)break;await Promise.all(pending);}
  if(safety.failed||libraryRunner.failed||runner.failed)return;
  return maintenanceRunner.wake();
 }).catch(()=>{});
 maintenanceOpportunity=task;trackApplicationWork(task);
 void task.finally(()=>{if(maintenanceOpportunity===task)maintenanceOpportunity=null;});
 return task;
};
const localToolRequest=type=>['PAIA_MAINTENANCE_PROCESSING_STATUS','PAIA_MAINTENANCE_PROCESSING_CONFIGURE'].includes(type)||type==='PAIA_LIBRARY_SECTION_PROMOTION'||['PAIA_SETTINGS_AI_STYLE','PAIA_SETTINGS_UPDATE_STATUS','GET_LIBRARY_ROOT_PROJECTION','GET_LIBRARY_ROOT_PREVIEWS','GET_LIBRARY_SECTION_PROJECTION','GET_LIBRARY_SECTION_READING','GET_LIBRARY_TOPIC_READING_METADATA'].includes(type)||type.startsWith('PAIA_PROMPT_')||type.startsWith('PAIA_ARCHIVE_')||type.startsWith('PAIA_RECOVERY_')||['GET_THOUGHT_LAYOUT','SET_THOUGHT_LAYOUT','GET_THOUGHT_REVERSE_EDIT','SET_THOUGHT_REVERSE_EDIT','THOUGHT_POSITION','RECORD_TOPIC_READ','COMPARE_THOUGHT_INPUT','GET_LIBRARY_TRACKED_ENTRIES','GET_LIBRARY_TOPIC_SECTIONS','GET_LIBRARY_TOPIC_ADJACENCY'].includes(type)||type.startsWith('PAIA_READER_')||type.startsWith('PAIA_PRODUCT_')||type.startsWith('PAIA_PASSPORT_')||type.startsWith('PAIA_CONTEXT_')||type.startsWith('PAIA_REVISIT_')||type.startsWith('PAIA_CORE_LOOP_');
const startupMaintenance=()=>{void scheduleMaintenance();};
runtime.onStartup?.addListener(startupMaintenance);
runtime.onInstalled?.addListener(()=>{void trackApplicationWork(ready.then(()=>scheduleFilter()).catch(()=>{}));});
// Startup may reconcile an unknown prior outcome, but it never dispatches Original.
if(runtime.onStartup)startupMaintenance();

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  const accepted=applicationWorkerActivity.dispatch(control=>handle(request, sender, control)
    .then(async data => {
      if(request.type.startsWith('PAIA_GENERATION_')){sendResponse({ok:true,data});return;}
      if(request.type.startsWith('PAIA_SYNC_')){
        if(['PAIA_SYNC_RESTORE','PAIA_SYNC_CONTINUE'].includes(request.type)&&data?.task?.phase==='confirmed')await notifyArchiveChanged(request.type);
        sendResponse({ok:true,data});return;
      }
      const archiveMutation=request.type==='CAPTURE'?(Number(data?.added)>0||data?.timeChanged===true):request.type==='ENRICH_SOURCE_METADATA'?Number(data?.enriched)>0:request.type==='OBSERVE_SOURCE_STRUCTURE'?false:true;
      if(request.type==='PAIA_LIBRARY_SECTION_PROMOTION'&&['confirm','resume','proposal_resume','restore'].includes(request.command)&&data?.state==='committed')void notifyArchiveChanged(request.type);
      if(request.type==='PURGE_SOURCE')await notifyArchiveChanged(request.type);
      if(['PAIA_CONTEXT_CARDS_CHANGE','PAIA_CONTEXT_TOPICS_CHANGE'].includes(request.type)&&data?.ok===true)await promptAssist.contextChanged();
      sendResponse({ ok: true, data });
      if(request.type==='CONSENT'||request.type==='UPDATE_PREFERENCES'&&data?.ok===true&&['appearance','language'].some(key=>Object.hasOwn(request.changes||{},key)))void trackApplicationWork(chrome.tabs.query({url:'https://chatgpt.com/*'}).then(tabs=>Promise.allSettled(tabs.filter(t=>!t.incognito).map(t=>chrome.tabs.sendMessage(t.id,{type:'PAIA_PROMPT_SURFACE_ACTIVATE',...(request.type==='UPDATE_PREFERENCES'?{reason:'display-preferences'}:{})},{frameId:0})))).catch(()=>{}));
      if(request.type==='OBSERVE_SOURCE_STRUCTURE'&&data?.event===true)void notifySourceStructureChanged();
      if(['PAIA_CONTEXT_CARDS_CHANGE','PAIA_CONTEXT_TOPICS_CHANGE'].includes(request.type)&&data?.ok===true)void trackApplicationWork(chrome.runtime.sendMessage?.({type:'PAIA_CONTEXT_CARDS_CHANGED'})).catch(()=>{});
      if(request.type==='PAIA_PROMPT_CHANGE')void trackApplicationWork(chrome.runtime.sendMessage?.({type:'PAIA_PROMPT_CHANGED'})).catch(()=>{});
      if(isAIStyleOnlyRequest(request)&&data?.ok===true&&data.changed===true)void trackApplicationWork(chrome.runtime.sendMessage?.({type:'PAIA_SETTINGS_AI_STYLE_CHANGED'})).catch(()=>{});
      if(request.type==='SET_THOUGHT_REVERSE_EDIT')notifyArchiveChanged(request.type);
      if(['PAIA_READER_CONFIGURE','PAIA_READER_CAPTURE_SCOPE'].includes(request.type))void trackApplicationWork(chrome.runtime.sendMessage?.({type:'PAIA_READER_POLICY_CHANGED'})).catch(()=>{});
      if(maintenanceMutation(request,data)){
        const local=trackApplicationWork(ready.then(()=>scheduleFilter()));
        if(maintenanceRunner.consumeSemanticWrite(data))void scheduleMaintenance(local);
        else void local.catch(()=>{});
      }
      else if(request.type!=='OBSERVE_SOURCE_STRUCTURE'&&!isAIStyleOnlyRequest(request)&&!localToolRequest(request.type)&&(!request.type.startsWith('IMPORT_')||['IMPORT_COMMIT','IMPORT_COMPLETE','IMPORT_RESOLVE_BRANCH'].includes(request.type))&&!['GET_ONBOARDING','SET_ONBOARDING'].includes(request.type)&&!request.type.startsWith('PAIA_MEMORY_')&&!request.type.startsWith('PAIA_INTEGRITY_')&&!request.type.startsWith('PAIA_BACKUP_')&&request.type!=='GET_BOUNDED_ORGANIZER'&&!['GET_AI_PRESENTATION_STATUS','GET_AI_PRESENTATION_SCOPE','GET_AI_PRESENTATION_OPERATION_OUTCOME'].includes(request.type)&&request.type!=='GET_ORIGINAL_ORGANIZER_STATUS'&&request.type!=='GET_DEEPSEEK_STATUS'&&request.type!=='FILTER_DIAGNOSTICS'&&!['SAVE_DEEPSEEK_CREDENTIAL','CLEAR_DEEPSEEK'].includes(request.type))void scheduleFilter({retry:['FILTER_RECOVER','FILTER_MODE'].includes(request.type)});
      if(request.type!=='PURGE_SOURCE'&&archiveMutation&&!isAIStyleOnlyRequest(request)&&!localToolRequest(request.type)&&!['PAIA_MEMORY_STATUS','PAIA_MEMORY_BUILD','PAIA_MEMORY_SHARE','PAIA_MEMORY_ENTRIES'].includes(request.type)&&!request.type.startsWith('PAIA_INTEGRITY_')&&!['PAIA_BACKUP_BEGIN_EXPORT','PAIA_BACKUP_EXPORT_PAGE','PAIA_BACKUP_BEGIN_RESTORE','PAIA_BACKUP_STAGE','PAIA_BACKUP_PREVIEW','PAIA_BACKUP_CANCEL','GET_BOUNDED_ORGANIZER','GET_LIBRARY_REMOVED_TOPICS','GET_LIBRARY_REMOVED_PLACEMENTS','GET_LIBRARY_RENAME_SUGGESTIONS','GET_LIBRARY_MERGE_SUGGESTIONS','GET_ORGANIZER_CONTROLS','GET_AI_PRESENTATION_REVISIONS','GET_AI_PRESENTATION_SCOPE','GET_AI_PRESENTATION_OPERATION_OUTCOME','GET_AI_PRESENTATION_STATUS','GET_ORIGINAL_ORGANIZER_STATUS','GET_DEEPSEEK_STATUS','SAVE_DEEPSEEK_CREDENTIAL','CLEAR_DEEPSEEK','LIBRARY_UPDATES','LIBRARY_ORGANIZER_JOBS','GET_LIBRARY_UNPLACED','GET_LIBRARY_PLACEMENT','LIBRARY_INDEX_PAGE','GET_LIBRARY_ROOT_SEARCH','TOPIC_DOCUMENT_PAGE','GET_LIBRARY_TOPIC_TIMELINE','GET_LIBRARY_TOPIC','GET_LIBRARY_ENTRY','GET_LIBRARY_PATHS','GET_LIBRARY_PROVENANCE','GET_LIBRARY_REMOVED','SEARCH_LIBRARY','GET_LIBRARY_LAYOUT','GET_LIBRARY_FOUNDATION_STATUS','GET_LIBRARY_DUAL_VIEW_STATUS','PREVIEW_AI_LIBRARY_UPDATE','FILTER_DIAGNOSTICS','FILTER_STATUS','FILTER_NOTICE','FILTER_RECENT','SEARCH_INPUTS','GET_INPUT','GET_IA_STATUS','GET_REVISIONS','GET_THOUGHTS','GET_THOUGHT','GET_STATUS','GET_STATE','GET_PAGE','GET_MIGRATION_STATUS','RESPONSE_POLL','RESPONSE_VIEW','RESPONSE_ARM','DIAGNOSTIC','GET_ONBOARDING','SET_ONBOARDING','IMPORT_LATEST','IMPORT_CANCEL','IMPORT_CAPABILITIES','IMPORT_TASKS','IMPORT_STATUS','IMPORT_BEGIN','IMPORT_PREFLIGHT','IMPORT_READY','IMPORT_PAUSE'].includes(request.type))notifyArchiveChanged(request.type);
    })
    .catch(error => sendResponse({ ok: false, ...(['UPDATE_AI_PRESENTATION','UPDATE_ORIGINAL_LIBRARY_VIEW'].includes(request?.type)?{phase:'message_handler'}:{}), ...(request?.type==='PAIA_LIBRARY_SECTION_PROMOTION'&&error?.phase==='promotion_not_confirmed'?{phase:'promotion_not_confirmed'}:{}), error: typeof request?.type==='string'&&request.type.startsWith('PAIA_SYNC_')?syncLifecycleError(error):request?.type==='PAIA_LIBRARY_SECTION_PROMOTION'&&['BNS_GROUP_OWNER_UNSUPPORTED','BNS_HUMAN_UNSUPPORTED_MUTATION'].includes(error?.code)?error.code:typeof request?.type==='string' && request.type.startsWith('IMPORT_') ? safeImportError(error) : ['UPDATE_AI_PRESENTATION','UPDATE_ORIGINAL_LIBRARY_VIEW'].includes(request?.type)&&!(error instanceof ArchiveError)?'INTERNAL_RUNTIME_ERROR':safeErrorCode(error) }))
  );
  return true;
});

installToolbarEntry(chrome,{clients:globalThis.clients});
