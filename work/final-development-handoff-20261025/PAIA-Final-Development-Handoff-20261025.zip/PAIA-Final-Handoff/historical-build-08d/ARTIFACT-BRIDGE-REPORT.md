# Static artifact-verifier bridge inspection

Result: the genuine 08d06a3c candidate is byte-consistent with its ordinary build evidence, but it is **not compatible with the current 98761c8 identity contract**. The actual unchanged verifier was called exactly once and correctly refused. No native readiness, browser Source/Release parity, certification, installation, publication, or latest-release delivery is established.

## Scope and preservation

- Candidate directory: `/workspace/scratch/ff1c41bf9b29/paia-internal-candidate-08d06a3c.TzbtkMPp`.
- All outputs of this investigation are in this new inspection directory. No production, harness, candidate, source, root index, root stage, or published artifact was written.
- First inspected `artifacts.mjs`, `policy.mjs`, the pinned source manifest, README, receipt, input/output vectors and checksum list read-only. Also inspected the standard builder as text, not executable code, to verify fingerprint algorithms.
- Executed one standalone Python standard-library JSON/hash/file inspection and one Node diagnostic invoking only the inspected static verifier. No product module, Python builder/guard module, runner, fixture body, test suite, browser, native adapter, server, network, package manager, installation, or build executed. The diagnostics spawn no subprocesses.
- No new native attempt, retry, alternate route, repin, reset, cleanup, version change, or source substitution occurred. Existing failures and spent allowances remain untouched.

## Exact candidate and static evidence

- Declared source commit: `08d06a3c3a143bb8db42dfb3ff4f152a05b9722b`.
- Declared source tree: `6978fc14379cd9d03df5be65f7ca09310dd54cfd`.
- 712 inputs: 706 release assets and six Python helper/guard files, including ten PNGs.
- All 712 current input sizes, SHA256 digests and Git blob-object digests match the audited vector. Before/after input vector bytes are identical. This byte check does not independently establish commit/tree membership or execution history; those require the separate provenance review.
- All 703 current output files match the complete inventory; exact path set, 8,254,325 bytes, no symlinks, no extra files.
- All 26 entries in `EVIDENCE.sha256` match. SHA256 of that checksum list itself is `143a7ee52feb1334275021776dafb3b3eb6a5cfe6f73c973bcd451595969368a`.
- Recomputed source fingerprint: `4f186ea4f1e3f0ca911a31bd385ae8ffc51728c9c16dbdcaf319d412a3f04b29`.
- Recomputed complete output fingerprint: `a13b7c8bb7a053f0f33702da409e62d739384d987cf0bfac22dae33a2b94629b`.
- Both recomputations match the vectors, receipt and builder sidecars.
- Source and Release have distinct roots and none of the 703 copied files share device/inode identity.
- The sole changed copied file is `background/service-worker.js`: remove exactly one `    case 'FILTER_DIAGNOSTICS': return store.filterDiagnostics();` line including newline.
- Exactly three source assets are excluded: `ui/structure-diagnostics.js`, `ui/fingerprint-display.js`, `ui/source-time-display.js`.
- Every other emitted byte equals its corresponding source byte. These are the four standard transforms: one line removal plus three file exclusions.

The existing receipt records one ordinary builder execution, exit 0, 3.615112012019381 seconds, reused=false, 30-second hard watchdog, 25 CPU seconds, 1 GiB address space, 64 MiB file limit. Its raw log records 24,655 package checks, 679 runtime resources and RELEASE_PRODUCT_GUARD_PASS for 703 files. Those statements were read and hash-checked, not recreated by a build here.

Independent provenance review was separately provided and read: `/workspace/scratch/ff1c41bf9b29/paia-independent-candidate-provenance-08d06a3c-gqtpafm8/INDEPENDENT-CANDIDATE-PROVENANCE.md`, 5,128 bytes, SHA256 `dd14342fe8390a2e755d728e98539aba7ac07231b1dd2d45bceef36b147ddaf2`. It reports independent verification of clean detached source commit/tree, all 712 pre/post hashes/blob IDs/modes, exact 703 outputs, single supervised build, retained initial preparation-only NOT_RUN, and unchanged root/prior artifacts. Its PASS is limited to ordinary offline packaging provenance/static guards. The reviewer materialized existing findings without rerunning checks or a build; this report did not infer independence from the author's receipt.

Important coverage distinction: the standard source fingerprint binds 706 assets plus three builder dependencies (709 files). It does not bind `scripts/build_internal.py`, `scripts/check_package.py`, or `scripts/check_release_product.py`. The complete external 712-file vectors bind those too. The old preparation manifest has five builder/guard hashes and omits `build_internal.py`. None of this authorizes executing `build_internal()`.

## Compatibility with the existing verifier

The inspected verifier imports only node:assert/strict, node:crypto and `policy.mjs`; the policy is constants plus an unconditional refusal function. It imports no product, runner, fixture, browser, process, build or network module. Its immutable-snapshot construction has no external side effect.

Current policy identity:

- Commit `98761c8c627ee66445c20dee452959d644fcd634`.
- Tree `b3b243627bf9ff117565d27d646f126a63e6c55b`.
- Source manifest SHA256 `798736cc88a97530c6270c5455b59ff3bd3a0d1cd258a9deee7a418a70c64b2a`.
- Fixture SHA256 `0b516daf11378ecc98791499e8e7359f96fe56eea6d6eac06aff93e761caa35d`.

Compatible facts, independently read from actual candidate bytes:

1. All 474 pinned core/background JS module names and hashes are identical at the current 08d source. No additions, removals or hash changes.
2. All five pinned builder/guard hashes match actual 08d bytes.
3. Fixture bytes match the fixed hash; all nine harness-file hashes were recorded. The artifacts/policy/manifest/fixture files also match the current integration worktree's corresponding files.
4. All 703 Release hashes, full output fingerprint and unchanged-builder correspondence are statically valid, including all non-runtime emitted files.
5. Recorded builder entry point, exit, non-reuse flag and elapsed time can be mapped without invention to the verifier's scalar contract.

Incompatibility is not runtime drift: source commit and tree identities genuinely differ. Exact 474-module equality must not be promoted to whole-tree equivalence or a claim that the 08d build was produced from 987.

### One actual preserved-pin invocation

Created a clearly labeled **diagnostic input only** in this inspection directory. It maps the existing receipt/vector fields into schema-1 Release shape but retains the actual 08d commit/tree and the unchanged historical source-manifest bytes. Its evidence class is the current contract's `STANDARD_BUILD_RECEIPT_UNVERIFIED`; it is not a certified manifest or a new source pin. This file must not be consumed as admitted native evidence.

Command, from this directory:

`env -u NODE_OPTIONS -u NODE_PATH node verify_actual_candidate_once.mjs`

The diagnostic read all 474 actual Source module files, all 703 actual Release files, and fixed fixture bytes. It invoked `verifyArtifactSnapshots` once. The verifier passed its historical manifest, source-module and fixture checks, then stopped at `artifacts.mjs:42`:

- Code: `ERR_ASSERTION`.
- Message: `Release source commit mismatch`.
- Actual: `08d06a3c3a143bb8db42dfb3ff4f152a05b9722b`.
- Expected: `98761c8c627ee66445c20dee452959d644fcd634`.

The diagnostic host exits 0 because it asserted the expected refusal, **not because the candidate passed admission**. The artifact-return/WeakSet-registration path was never reached. Tree mismatch at line 43 would also remain, but was not executed after the first failure. Checks after line 42 were not reached in this invocation; the independent hash inspection establishes the compatible byte facts above, not an accepted verifier result.

No second invocation, patched pin, falsified commit, fabricated 987 Release receipt, or modified verifier was attempted. Four critical harness hashes were checked before and after the invocation and remained unchanged.

## Missing manifest fields and trust gaps

The candidate contains `receipt.json` plus separate vectors, not the verifier's schema-1 Release manifest. These are schema/data-layout gaps, not grounds to fabricate facts:

- `schema`, `variant`, camelCase `sourceCommit`/`sourceTree`, and a source-manifest binding.
- Full `files` path-to-SHA256 object, presently available as the 703-row inventory.
- `build.entrypoint`, `builderFiles`, `exitCode`, `guardrails`, `reused`, `elapsedMs`, `sourceFingerprint`, `outputFingerprint`, and explicit non-native evidence class. Their values are mostly available across the receipt, execution evidence and input vector rather than one object.
- There is **no accepted Source manifest for 08d** in the current harness. The old manifest is valid historical evidence for 987 and is only a limited runtime-byte comparison reference for 08d.
- The current verifier checks supplied bytes and scalar assertions, not build provenance. It does not bind the execution log/command, all 712 inputs, full Git commit/tree membership, physical filesystem separation, absence of symlinks, or before/after filesystem stability. Its comments explicitly place those obligations on a future trusted supervisor.
- The source-fingerprint field is checked only for hex syntax by the existing verifier. A complete bridge must recompute it and separately bind the complete 712-input vector; it cannot trust a copied 64-character value.
- The current runtime correspondence loop covers 474 modules, not all 703 output/source relationships. A candidate-provenance bridge must verify the entire 706-to-703 mapping and exact four transforms.

## Smallest proposed bridge, not implemented

Do not change `policy.mjs`, `source-manifest.json`, the existing verifier, its WeakSet, fixture bodies, runner, old receipts or their history. Add an explicitly **new, separately reviewed 08d static provenance descriptor** and an isolated pure verifier/test file only if the parent authorizes that scoped change after this report.

The new descriptor should bind:

1. Its own schema/version and non-native evidence classification; the genuine 08d commit/tree and source root identity. Keep the 987 preparation in a separately named historical-reference section, never as the new candidate's source identity.
2. The complete 712-row input vector with path, role, regular-file mode, size, SHA256 and Git blob ID, plus audited-vector and before/after-vector hashes, exact counts and source-tree membership evidence.
3. The full 703-row output inventory with paths, sizes and hashes, exact path set, byte total and full output fingerprint.
4. All six helper/guard hashes, exact unchanged entry point, execution/command/raw-log/receipt/checksum-list hashes, one recorded execution, exit/non-reuse/elapsed facts and recorded standalone limits. Preserve the failed initial preparation and authorized correction history.
5. The 709-file builder source-fingerprint calculation plus the separate full 712-file provenance vector. Explicitly bind the three standard exclusions and the exact one-line, single-occurrence removal; all other output bytes must equal source bytes.
6. Frozen harness/fixture hashes and the limited 474-module equality comparison to historical 987, expressly not whole-tree equivalence or native acceptance.
7. Static result only, with native readiness remaining NOT_READY and no execution authorization. The result must not provide browser routes, a launcher, a verified-artifact token, a caller-set approval flag, or any path into the current artifact WeakSet.

Use a separate result such as `STATIC_PROVENANCE_MATCH_NOT_NATIVE`, not `PASS`, `READY`, `NATIVE_PASS`, `SOURCE_RELEASE_PARITY`, or `DELIVERED`. Evidence bytes must match an independently reviewed pinned descriptor; mutually consistent attacker-controlled receipt/vector fields are not sufficient trust.

This additive bridge can close the **ordinary 08d packaging-provenance accounting** gap. It cannot make the old 987 verifier accept 08d, grant permission, qualify fixture behavior, or reset spent attempts. If eventual native scope is moved to 08d, that requires a distinct reviewed acceptance decision and separately scoped manifest/policy change, not this diagnostic bridge.

## Proposed pure test matrix, not run

No runner, fixture body or product import is needed. Use bytes/JSON/hash inputs, optionally frozen actual vectors, with fresh small in-memory mutations; no build/browser/server/child-process/network calls.

- Authentic frozen 08d descriptor and vectors yield only the static provenance class; native readiness remains unconditionally NOT_READY.
- Genuine 08d identity versus old 987 identity remains a refusal even when all 474 runtime bytes match. Preserve the actual refusal receipt rather than rerunning it under this task.
- Wrong source commit, tree, input blob binding, manifest hash, descriptor hash, fixture or harness hash fails.
- Every input is required: missing/changed sixth helper, 709-only sidecar substitution, duplicate/unsafe path, wrong mode, symlink, shared source/output identity, changed pre/post vector, count or byte total fails.
- Every output is required: stale 687-file artifact, missing/extra output, changed digest/bytes, self-consistent altered receipt and output vector, wrong complete fingerprint fails.
- Exact transform checks reject extra exclusions, restored excluded files, zero/two removal occurrences, wrong removal text, or any unrelated changed emitted byte.
- Wrong entry point/helper, nonzero exit, reused=true, invalid or over-30,000 ms duration, missing/mutated log/command/receipt evidence, or unbound source fingerprint fails.
- Descriptor mutation after verification cannot change the returned immutable static summary; no runner-admissible token is returned.
- Static import-surface checks exclude product/fixture/runner/process/browser/network modules and dynamic execution. These tests prove contract behavior only, not execution provenance or OS containment.

## Explicit remaining NOT_READY prerequisites

All five current policy reasons remain applicable to the unchanged 987 preparation. More precisely:

1. Fresh explicit native execution authorization is absent. It must bind exact accepted source, frozen harness, the eight fixed Source/Release case rows, one launch, budgets and environment; ordinary build permission is not native permission.
2. No genuine Release for the accepted 987 identity has been admitted. The new 08d ordinary build is real separate evidence, not fulfillment by relabeling. A reviewed new 08d descriptor alone still is not native admission.
3. No real adapter or independently verified Chromium executable has been supplied. Sandbox availability, exact executable identity and no-profile/no-credentials conditions remain unproven.
4. The standalone build's recorded hard 30-second bound does not prove future native <=120 seconds, whole-job <=300 seconds, descendant termination or uncertain-launch cleanup. Whether a future separately authorized gate may consume this prior build evidence requires explicit review; this report neither mandates nor authorizes another build.
5. OS-level network denial and actual Chromium sandbox containment remain unproven. Page routing and offline flags alone are not that proof.

Native IndexedDB/internal-slot checks, all eight actual cases and Source/Release browser parity have not run. Full/C/129-group/100k/old-cloud, provider/account/paid/remote/local-Codex, installation and final release delivery remain outside this task.

## Files produced

- `inspect_bridge.py`: standalone standard-library read/hash inspection.
- `static-inspection.json` and identical stdout capture: full findings and all nine harness hashes.
- `projected-release-diagnostic-input.json`: actual08d diagnostic mapping that intentionally fails the historical987 contract, never an accepted manifest.
- `verify_actual_candidate_once.mjs`: one-invocation static diagnostic; do not rerun without new applicable authority.
- `actual-verifier-result.json`, `.stderr`, `.exit`: exact refusal, empty stderr and host exit0.
- This `REPORT.md`; `REPORT-FILES.sha256` records local investigation outputs.
