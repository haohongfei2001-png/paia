# PAIA Product

Status: **current product source of truth**

Current runtime baseline: **v0.12.0 + post-release consolidation rounds**

This document defines what PAIA is now, what it is trying to become, and which product bets are intentionally frozen while they are being validated. Historical version specifications remain evidence of past implementation decisions, but they do not override this document for new product work.

## Current consumer scope

Input Archive, Thought Library and AI Context remain the product direction. AI Context execution remains disabled. The current consumer scope supersedes conflicting feature descriptions and follow-up tasks in historical packages:

- Remove dedicated multi-Profile management, Thought response relations, Material Tray, activity-retention configuration and Product Signals collection/dashboard. Preserve independent Thoughts, edits, history and necessary legacy-data compatibility.
- Hide Candidate approval management; retain saved drafts, revision checks and protection against overwriting human edits. Do not auto-apply candidates.
- Keep only minimal internal diagnostics/audit and maintenance. Ordinary Settings has no diagnostic, trace, usage-audit or integrity dashboard; recovery appears only for an actual data/index failure. Do not expand collection or audit retention.
- Remove user API keys, model/address/request-count/batch settings and direct AI transport. Do not read or clear stored legacy credentials.
- Cancel all content/statistics/Context exports, backup creation and dedicated sharing, including their implementation and follow-up work. Old commands must refuse without side effects. Existing files and data are not automatically deleted; existing-file restore, integrity and deletion fences remain supported.
- Ordinary AI entry points are the Topic reader's AI Organize action and Settings' Membership / AI service. The service is not launched; saved AI work remains readable/editable. Real payment, server-side membership validation and a unified AI backend remain unimplemented; see the [service task](docs/consumer-product-v1/MASTER_PLAN.md#paid-ai-service--not-implemented).

Local search, Smart Filter, Project recognition, history import, Prompt Reuse and Passport privacy/revocation remain in scope. This does not open future sync, semantic retrieval, mobile or connector implementation.

## Production Readiness v1 validation focus

The current active product-validation package is
`PAIA-PRODUCTION-READINESS-v1`. Its purpose is not to add another capability;
it must prove that the existing Catch → Read → Remember → Organize → Reuse system
can be depended on in ordinary daily use.

Production readiness separates three claims: engineering-green, release-candidate
certified, and production-certified. Current synthetic/browser certification is
strong engineering evidence, but it is not by itself proof of current logged-in
ChatGPT compatibility, the user's daily-profile update/restart path, current
Backup/restore boundaries, or longitudinal retrieval value.

Until this package closes, production work prioritizes live capture compatibility,
local durability/recovery, supported scale and actual retrieval/reread/reuse.
Semantic Engine integration, new providers, sync and new durable content layers
remain frozen unless separately authorized.

Canonical package: [docs/production-readiness-v1/README.md](docs/production-readiness-v1/README.md).


## Archive navigation and continuous Thought reading

The Archive Navigation & Source Structure v1 package implements the current
`global navigation | Archive Navigator | Reader` presentation. Project groups
start collapsed; the Navigator stays available while switching Windows, with a
mobile sheet at narrow widths. Unknown Project membership is distinct from a
confirmed lack of Project. Source Project moves/renames are metadata, and an
external confirmed deletion leaves the PAIA archive intact. PAIA permanent purge
retains its separate, stronger deletion semantics.

Input order is one ascending/descending toggle using the existing preference;
source send time is visible without hover and unknown time stays explicit.
Archive Window ordering is a separate device-local PAIA/source setting. Reliable
scoped source order is used only when available; ChatGPT Project/order/delete
capabilities remain unverified and fall back honestly to PAIA ordering.

Thought overview, search/unplaced results and Topic original text load
continuously. Bounded pages and edit-safe windows preserve original/AI separation,
manual revisions, IME, selection and save failure buffers. Normal temporary
selections and reference validation remain available without a Material Tray.
Versions remain readable; ordinary reading/order/scrolling makes no provider call.
Archive opens with its narrow project/conversation navigator and a blank Reader.
Only selecting a conversation opens its title, time, order and body. Returning to
the root clears the Reader while retaining navigator state; explicit reading routes,
unsaved edits and reading anchors remain protected.

Implementation completion, integration certification and provider coverage are
separate claims. Consult the package [canonical status](docs/archive-navigation-source-v1/STATUS.md),
[coverage matrix](docs/archive-navigation-source-v1/INTEGRATION_MATRIX.md) and receipts;
synthetic integration tests do not certify real ChatGPT Project APIs or Claude exports.

## 1. Product definition

PAIA is a **local-first personal AI input and context system**.

Its job is not merely to archive prompts. PAIA helps a person preserve what they said to AI, read it again as durable personal material, organize recurring ideas without losing the original expression, and selectively reuse relevant context with AI later.

The current product loop is:

**Catch → Read → Remember → Organize → Reuse**

A cross-cutting authorization layer, **Passport**, preserves external-use restrictions and revocation without owning another copy of the user's content. Context release is disabled.

PAIA is not intended to become another general note editor, another chat client, or an autonomous agent that silently rewrites a person's archive.

## 2. Product thesis

AI conversations are producing a rapidly growing body of user-authored material: questions, judgments, preferences, decisions, plans, hypotheses, personal explanations and evolving ideas. Today most of that material remains trapped inside individual AI products and is difficult to reread, search, compare over time or reuse elsewhere.

PAIA's core thesis is:

> A person's own AI inputs are a durable personal data asset and should remain readable, attributable, editable without destroying provenance, and reusable across future AI interactions under explicit user control.

The strongest near-term product promise is deliberately narrower:

> **Important things I have said to AI should be easier to reread, find and reuse in PAIA than in the original AI application.**

If this promise does not hold in real use, deeper organization, memory and authorization features do not have a strong foundation.

## 3. Capability model

The following six capabilities describe the product. They are **not six required pages** and must not automatically become six separate durable data layers.

### 3.1 Input Catch

Purpose: reliably acquire eligible user-authored AI inputs with stable source identity and provenance.

Current state:

- ChatGPT Web live capture is implemented.
- Historical completion/import paths exist under explicit user action.
- User-selected official-export import can structurally distinguish registered ChatGPT and Claude export adapters and fails closed on unknown or ambiguous formats.
- The Claude adapter currently validates the provider-neutral import boundary at synthetic-contract level only: `realExportVerified=false` until an actual user-exported Claude file is verified.
- Claude import accepts only user/human-authored text into the existing Source/Input pipeline. Assistant text is not imported as user evidence, and non-current branches remain review-only.
- Live `claude.ai` capture is **not** implemented, no Claude page/network capture permission has been added, and Claude source permalinks are intentionally left blank rather than guessed before real verification.
- Source snapshots are immutable facts and remain separate from editable working content.

Direction:

- Keep the capture/import adapter boundary provider-specific and the archive model provider-neutral.
- Round 5A has demonstrated that a second import adapter can reuse the existing Source/Input model without creating another durable fact store or changing historical ChatGPT identity semantics.
- Do not treat synthetic Claude compatibility as proof of real export compatibility or product demand. Verify a real export before claiming support.
- Do not proliferate additional providers or live capture adapters until real-source evidence and user value justify the added trust, maintenance and permission surface.

### 3.2 Input Reader

Purpose: make archived inputs substantially better to read, find and reuse than the original chat history.

Current state:

- Continuous reading, editing, ordering, source navigation and local per-surface search exist.
- Reader search results can open directly around the matched Input and highlight the query.
- Input/Thought/Context lexical retrieval shares a common Search Service foundation.
- **Visible search is page-scoped**: Archive root, one Archive document, Thought Library root and one Thought topic each expose one search for that container; Settings has no content search or search launcher.
- **Universal Search** remains a bounded internal coordinator across Input Archive, Thought Library and existing AI-organized projections. It is not a competing normal-page launcher and creates no additional search index or truth layer.
- Search can reopen matching Input/Thought/AI-organized locations. It does not launch the retired Context execution path.
- **“以前的我”** is a time-oriented projection over matching Input expressions. It orders available source-send-time evidence from earlier to later and explicitly does not infer that the user's belief changed.
- **Revisit / 回访** is an on-demand local Reader surface. UX-R2 shows true reading positions, a fixed window of newly collected visible Inputs and bounded topic material changes. Older Inputs appear only after explicit opt-in; Input/conversation/topic exclusions also suppress related previews.
- **Thought Library / 思想库** uses the adopted Topic list, without a Recent Reading section on its root. Reading-position and recent-read metadata remain available to existing Reader/Revisit services. Whole/selected-text placement, independent Thoughts without a required topic, and safe body editing remain. The first actual edit normally stops following its Input and leaves the archive unchanged. Following can be restored through an explicit comparison. Advanced reverse editing remains off by default and after Backup restore, applies only to a valid whole one-to-one reference, and never broadens AI or external-use authorization. Explicit Thought response creation/viewing is removed; legacy relation data remains compatible.
- Older resurfacing is deliberately explainable: PAIA prefers Inputs at least 90 days old that the user edited or that already became Thought evidence; it does not use random engagement sampling or a hidden recommendation model.

Direction:

- Reader is a **presentation capability**, not a new database.
- Universal Search and Revisit are coordinators/projections over existing trusted state, not new truth stores.
- Revisit should remain user-initiated: no push-notification growth loop, no background AI generation, and no inference of read completion. Visit boundaries advance separately on leaving or beginning a later visit; imports do not create unread debt.
- Longitudinal reading should remain grounded in attributable user expression; AI may later help retrieval only if it does not silently convert chronology into invented personal conclusions.
- Reader/Search/Revisit advantage still requires real-use validation rather than being inferred from implementation quality.

### 3.3 Thought Record

Purpose: preserve durable ideas that recur across conversations while retaining evidence back to the user's own expressions.

Current state:

- Topic / Section / Entry organization, provenance, revision history and human protection semantics exist.
- Exact original Thoughts may share canonical working content with an Input only when the relationship is unambiguous.

Direction:

- The current Thought Library is feature-complete enough for validation.
- Do **not** add new Thought entities or new automatic organization layers merely because they are technically possible.
- Prefer better reading, retrieval and product validation over further Thought Library feature expansion.

### 3.4 Thought Organize

Purpose: help the user turn accumulated expressions into a more useful current view without erasing uncertainty, contradictions or historical evolution.

Current state:

- New AI generation is unavailable until the paid service exists. The Topic reader's AI Organize entry and Settings' Membership / AI service show that boundary honestly; no other ordinary AI launchers remain.
- v0.12.0 includes evidence-grounded current understanding and thought-evolution reading.
- AI-generated organization is separated from Source and protected human work.
- Existing AI results remain readable/editable, and saved candidates remain readable. Hidden approval management does not remove version checks or permit automatic replacement of human work.

Direction:

- Treat organization as a derived projection over trusted data, not as the owner of personal truth.
- No hidden background paid requests, automatic retries or silent AI rewrites.
- Further sophistication is frozen until real usage shows that organization is a retention driver.

### 3.5 AI Context

Purpose: compile relevant, authorized personal material into context that can be reused with AI.

Current state:

- The previous Context retrieval/build/preview/release execution path is disabled; old commands must refuse without reading protected content or causing side effects.
- Dedicated Profile management, Material Tray, Context copy/export and sharing are cancelled.
- Legacy scope/exclusion data remains compatible without creating a new canonical content layer or reactivating authorization.

Direction:

- AI Context should still be understood as a **Context Compiler**, not yet a universal autonomous AI memory service.
- Context Package is the reusable boundary for future integrations; do not create bespoke output contracts for every consumer.
- Do not persist a general Context Package body history without a separate product/privacy decision.

### 3.6 Passport

Purpose: preserve controlled external-use permissions, privacy restrictions and revocation without expanding authorized scope.

Current state:

- Existing permissions and revocation remain available. Legacy scope, allow/deny/never and exclusions remain restrictive compatibility data.
- Grants can expire or be revoked; internal access audit remains metadata-only under its existing retention bounds. This does not authorize new grants or Context release.
- Passport metadata does not contain Context body text and is deliberately excluded from PAIA Backup so restore cannot silently reactivate old external-use permissions.

Direction:

- Passport remains a **cross-cutting governance layer**, not another body-text database and not another primary navigation surface by default.
- The minimum implementation is sufficient to validate the concept; do not expand it into MCP/API/autonomous-agent access merely because the authorization model now exists.
- Broader Passport work should wait for repeated Context reuse to demonstrate that cross-AI authorization solves an observed problem.

## 4. Product architecture from a user's point of view

The product should conceptually behave like this:

```text
Capture
  ↓
Source Record
  ↓
Working Input ────────────────┐
  ↓                           │
Thought evidence / Topics     │
  ↓                           │
Organized projections         │
  ↓                           │
Context (future; disabled)    │
                              │
Reader + Search + Revisit ────┘

Passport governs external Context use without owning content.
```

Important consequences:

- Reader does not own another canonical copy of text.
- Search/Revisit do not own another canonical copy of text or a parallel product truth.
- AI Context does not become a fourth body-text truth store.
- Passport does not own content; it owns authorization and audit metadata.
- Derived views may be rebuilt. User-authored facts and edits must not be silently regenerated away.

### Current interface — UI Simplification v1

The interaction model is current location → current content → current actions.

| Surface | Visible search scope |
| --- | --- |
| Archive root | Eligible Archive/Input content |
| One Archive document | That document/window only |
| Thought Library root | Thought Library content |
| One Thought topic | That topic/document only |
| Settings | No search box or search launcher |

Search-focus shortcuts target the current surface rather than opening global search. Temporary selections and reference validation do not launch AI or expand authorization.

Archive root has no redundant Archive intro or Browse by source heading. History completion/import remains contextual. Archive, Topic and Settings have no export, backup-generation or dedicated sharing actions. Settings retains existing-file restore and its validation/confirmation safeguards.

Thought Library root has no Recent Reading section and no primary AI organization controls. Independent Thoughts, user edits, saved AI projections, version history and read metadata remain intact. Retiring controls and execution paths does not delete their historical data or weaken Source/Input/Thought ownership, tombstones or revision protection.

## 5. Current product priorities

For the next development stages, priorities are:

1. **Rereading quality** — opening PAIA should feel useful before the user invokes any AI organization.
2. **Retrieval quality** — page-scoped Archive/Thought search and local Reader search should make old expression retrieval visibly easier than returning to the original chat product.
3. **Return value without engagement tricks** — Revisit should give a concrete reason to come back by surfacing real newly accumulated or older meaningful material, without push loops or opaque recommendation logic.
4. **Longitudinal understanding without fabrication** — time-oriented views should help the user compare their own earlier expressions without silently claiming a change of belief.
5. **Reuse rate** — Search, reading and Prompt Reuse should solve repeated tasks. Future Context integration must prove value separately before execution is reopened.
6. **Trust** — source identity, deletion, edit boundaries, authorization and provenance must remain understandable and reliable.
7. **Complexity control** — new product value should not automatically imply a new durable entity, index or schema store.

## 6. Deliberate freezes

Until evidence justifies reopening them:

- No new Thought Library ontology layer.
- No new durable fact database for Reader/Revisit.
- No automatic background Organizer.
- No broad cloud-sync implementation.
- No Web/mobile app merely to duplicate the extension UI.
- No knowledge graph as a product goal.
- No provider proliferation.
- No embedding/vector-store migration before measured retrieval failures justify it.
- No broad Passport agent/API/MCP access solely because the minimum Grant model is implemented.
- No notification/engagement machinery justified only by wanting higher return frequency.

These are product freezes, not claims that the ideas are permanently rejected.

## 7. Product validation

PAIA currently has stronger engineering validation than product-market validation. Product Signals collection and its validation dashboard are removed. Existing records are not automatically cleared. Product validation uses deliberate testing and user feedback without adding hidden telemetry.

## 8. Success gates for expansion

PAIA should not move into expensive multi-device, platform or agent expansion merely because the architecture can support it.

Before prioritizing cloud sync, Web App, native apps or broad Passport integrations, at least the following should be true in real use:

- Reader/Search is clearly better than returning to ChatGPT history for a meaningful class of tasks.
- Users repeatedly retrieve material older than the current session/week.
- Page-scoped search produces result opening and rereading rather than only searches with no follow-through.
- Revisit produces voluntary opening of older/newly accumulated material rather than becoming an ignored badge or notification substitute.
- Thought organization produces repeat visits rather than one-time curiosity.
- Any future Context integration must separately demonstrate that cross-AI authorization solves an observed problem; this gate does not reopen disabled execution.

The explicit decisions to implement Minimum Passport and the Round 5A second-import-adapter validation early are implementation-order overrides, not evidence that this gate has been met.

## 9. Relationship to historical documents

For new product work, this file is authoritative together with `ARCHITECTURE.md` and `ROADMAP.md`.

The following remain important evidence but are not current product source-of-truth documents:

- `PRODUCT_SPEC.md`
- `DECISIONS.md`
- version-specific `V*_*.md` and `ROUND*.md`
- foundation/acceptance documents
- `README_HISTORY.md`

`PRIVACY.md`, `BACKUP.md`, `AI_CONTEXT.md` and other feature contracts still contain detailed behavioral/security constraints for existing implemented features. Consult them when changing those features, but do not infer new product priorities from old version plans.

The UX-R4 Material Tray, Profile and preview/release workflows are historical implementation evidence. They do not authorize restoring retired products or outputs. Only normal temporary selections, reference validation, historical compatibility and existing privacy restrictions remain.
