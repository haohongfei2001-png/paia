/* ISOLATED: raw response metadata stays in this document's bounded memory. */
(() => {
  'use strict';
  globalThis.PAIAResponseBridge?.dispose();
  const lifecycle = globalThis.PAIACaptureLifecycle;
  const contentVersion = lifecycle?.version || (() => { try { return chrome.runtime.getManifest().version; } catch { return null; } })();
  let disposed = false;
  let generation = 0;
  const requests = new Set();
  function available() {
    try { return !disposed && lifecycle?.active !== false && (!lifecycle || globalThis.PAIACaptureLifecycle === lifecycle) && !!chrome.runtime.id; }
    catch { return false; }
  }
  function current(token = generation) {
    if (!available()) { if (!disposed) invalidate(); return false; }
    return !stopped && token === generation;
  }
  function invalidate() { if (lifecycle?.active) lifecycle.dispose(); else dispose(); }
  const protocol = globalThis.ResponseTimeProtocol;
  const model = new protocol.Model();
  const fingerprints = new globalThis.JSONFingerprintProtocol.Model();
  const semantics = new globalThis.SourceTimeProtocol.Model();
  const history = new globalThis.HistoryTime.Model();
  let fingerprintAllowed = false;
  const adapter = new globalThis.ChatGPTAdapter();
  let session = crypto.randomUUID();
  let historySession = crypto.randomUUID();
  const proofs = new Map();
  const acknowledged = new Map();
  let flushing = false;
  let flushAgain = false;
  let proofGroup = 0;
  let proofChat = null;
  let epoch = -1;
  let active = false;
  let arm = 0;
  let stopped = false;
  let polling = false;
  let pollTimer = null;
  let responseObservation={state:'NOT_OBSERVED',acceptedRows:0,rejectedFrames:0};
  let canonicalAt = 0;
  function control() {
    window.postMessage({channel: 'archive-response-control-v2', active: active && current(), chat: model.chat, epoch, session, historySession, arm, fingerprint: fingerprintAllowed, history: active}, 'https://chatgpt.com');
  }
  function clear() {
    generation++;
    fingerprints.clear(); semantics.clear(); fingerprintAllowed = false;
    model.reset(); active = false; arm = 0; canonicalAt = 0; session = crypto.randomUUID(); control();
    responseObservation={state:'NOT_OBSERVED',acceptedRows:0,rejectedFrames:0};
    history.reset(); proofs.clear(); acknowledged.clear(); proofChat = null; historySession = crypto.randomUUID();
  }
  async function request(message) {
    if (!current()) { if (!available()) invalidate(); return null; }
    const token = generation;
    let deadline, cancel;
    try {
      const cancelled = new Promise(resolve => { cancel = () => resolve(null); requests.add(cancel); });
      const reply = await Promise.race([chrome.runtime.sendMessage({...message, contentVersion}), cancelled, new Promise(resolve => {
        deadline=setTimeout(()=>resolve({ok:false,error:'MESSAGE_RESPONSE_TIMEOUT'}),35000);
      })]);
      if (!available() || reply?.error === 'CONTEXT_INVALIDATED') invalidate();
      return current(token) ? reply : null;
    } catch (error) {
      if (!available() || /extension context invalidated/i.test(String(error?.message || ''))) invalidate();
      throw error;
    } finally { globalThis.clearTimeout?.(deadline); requests.delete(cancel); }
  }
  function eligible() { return current() && active && adapter.route().id === model.chat && adapter.route().code === 'READY'; }
  function onMetadata(event) {
    if (event.source !== window || event.origin !== 'https://chatgpt.com' || !eligible()) return;
    const data = event.data;
    if (data?.channel !== 'archive-response-metadata-v2' || data.epoch !== epoch || data.chat !== model.chat) return;
    if(data.historyState&&data.historySession===historySession){
      const value=globalThis.ArchiveDiagnostics?.sanitizeResponseObservation(data.historyState);
      if(value)responseObservation=value;
      return;
    }
    if (data.history) {
      if (data.historySession === historySession && history.ingest(data.history)) void flush();
      return;
    }
    if (data.session !== session) return;
    if (data.fingerprint || data.fingerprintFailure === true) {
      if (fingerprintAllowed) {
        if (data.fingerprint) {
          if (fingerprints.ingest(data.fingerprint)) semantics.ingest(data.fingerprint, model.chat);
        }
        else fingerprints.failures = Math.min(1000000, fingerprints.failures + 1);
      }
      return;
    }
    if (data.observedFetchResponse === true) { model.recordObservation(); return; }
    model.recordTrace(data.trace);
    if (data.trace?.outcome === 'skipped') return;
    if (data.error === 'LIMIT') model.limitedResponses = Math.min(1000000, model.limitedResponses + 1);
    else if (data.error === 'SCHEMA') model.rejectedResponses = Math.min(1000000, model.rejectedResponses + 1);
    else if (!model.ingest(data)) model.rejectedResponses = Math.min(1000000, model.rejectedResponses + 1);
  }
  window.addEventListener('message', onMetadata);
  async function flush() {
    if (flushing) { flushAgain = true; return; }
    if (!eligible() || !proofChat || !proofs.size) return;
    flushing = true;
    const generation = historySession, batchEpoch = epoch, chat = {...proofChat};
    try {
      const groups = new Map();
      for (const [id,proof] of proofs) {
        if (!groups.has(proof.group)) groups.set(proof.group,[]);
        groups.get(proof.group).push({id,...proof});
      }
      // Only compare messages confirmed together; cache insertion order is not
      // conversation order, and separately loaded fragments have no global rank.
      for (const group of groups.values()) {
        group.sort((a,b)=>a.pageOrder-b.pageOrder);
        const evidence = history.match(group.map(proof=>proof.id));
        const pending = group.map(proof => ({sourceMessageId:proof.id,pageOrder:proof.pageOrder,sourceTime:evidence.get(proof.id) || null,...(proof.domTime?{domTime:proof.domTime}:{})}))
          .filter(message => acknowledged.get(message.sourceMessageId) !== JSON.stringify(message));
        for (let start = 0; start < pending.length; start += 200) {
          if (!eligible() || historySession !== generation || epoch !== batchEpoch) return;
          const messages = pending.slice(start, start + 200);
          const reply = await request({type:'ENRICH_SOURCE_METADATA',epoch:batchEpoch,adapterVersion:globalThis.ChatGPTAdapter.version,chat,messages});
          if (!reply?.ok || !eligible() || epoch !== batchEpoch || historySession !== generation) return; // Keep evidence for the next authorized poll.
          // Only the trusted writer can confirm persistence or an explicit exclusion.
          // Missing sources keep their evidence pending, even after an OK response.
          for (let index=0; index<messages.length; index++) {
            if (reply.data?.settled?.[index] === true || reply.data?.excluded === true) {
              const message=messages[index];
              acknowledged.set(message.sourceMessageId,JSON.stringify(message));
            }
          }
        }
      }
    } catch {} finally {
      flushing = false;
      if (flushAgain) { flushAgain = false; void flush(); }
    }
  }
  const api = Object.freeze({
    persisted() { void flush(); },
    owns(chatId,messageId) { return eligible()&&chatId===model.chat&&history.rows.has(messageId); },
    health(snapshot,status) {
      if(!eligible()||status?.epoch!==epoch||snapshot?.chat?.id!==model.chat)return null;
      const evidence=history.match((snapshot.messages||[]).map(m=>m.sourceMessageId));
      let available=0,missing=0,blocked=0;
      for(const message of snapshot.messages||[]){const e=evidence.get(message.sourceMessageId);if(e?.state==='valid')available++;else if(e?.state==='blocked'&&e.reason!=='MISSING')blocked++;else missing++;}
      return globalThis.ArchiveDiagnostics?.sanitizeCaptureHealth({schemaVersion:1,responseState:history.limited?'LIMIT':responseObservation.state,responseRows:responseObservation.acceptedRows,rejectedFrames:responseObservation.rejectedFrames,canonicalProofs:proofs.size,unsettledSources:Math.max(0,proofs.size-acknowledged.size),sourceTimesAvailable:available,sourceTimesMissing:missing,sourceTimesBlocked:blocked})||null;
    },
    evidence(snapshot,status) {
      if(!active||status.epoch!==epoch||!eligible()||snapshot.chat?.id!==model.chat)return new Map();
      return history.match(snapshot.messages.map(m=>m.sourceMessageId));
    },
    observe(snapshot, status) {
      if (!active || status.epoch !== epoch || !eligible()) return;
      if (snapshot.chat?.id === model.chat && Array.isArray(snapshot.messages)) {
        const ids = snapshot.messages.map(message => message.sourceMessageId);
        if (snapshot.chat.url && ids.length <= 2000) {
          proofChat = {id:snapshot.chat.id,url:snapshot.chat.url};
          proofGroup++;
          for (const message of snapshot.messages) {
            if (/^[A-Za-z0-9_-]{8,128}$/.test(message.sourceMessageId) && Number.isSafeInteger(message.pageOrder) && message.pageOrder > 0 && message.pageOrder <= 1000000 &&
                (proofs.has(message.sourceMessageId) || proofs.size < 2000)) proofs.set(message.sourceMessageId,{pageOrder:message.pageOrder,group:proofGroup,...(message.domTime?{domTime:message.domTime}:{})});
            else if (proofs.size >= 2000) history.limited = true;
          }
          void flush();
        } else if (ids.length > 2000) history.limited = true;
        model.observe(model.chat, ids); canonicalAt = Date.now();
        if (fingerprintAllowed) semantics.observe(model.chat, ids, canonicalAt);
      } else { model.canonical = []; semantics.observe(model.chat, []); canonicalAt = 0; }
    }
  });
  async function poll() {
    if (!current() || polling) return;
    polling = true;
    const token = generation;
    try {
      const response = await request({type: 'GET_STATUS'});
      if (!current(token)) return;
      const status = response?.ok ? response.data : null;
      if (status && (!contentVersion || status.runtimeVersion && status.runtimeVersion !== contentVersion)) { invalidate(); return; }
      const route = adapter.route();
      const allowed = status?.enabled === true && status.consented === true && status.adapterVersion === (adapter.version || globalThis.ChatGPTAdapter.version) && route.code === 'READY';
      if (!allowed) { if (active) clear(); }
      else {
        if (!active || epoch !== status.epoch || model.chat !== route.id) {
          clear(); epoch = status.epoch; model.reset(route.id); history.reset(route.id); active = true;
        }
        control();
      }
      const pollGeneration = generation;
      await flush();
      if (!current(pollGeneration)) return;
      let reply;
      // Diagnostic transport/lease failure must not clear authorized formal evidence.
      try { reply = await request({type: 'RESPONSE_POLL', session, epoch, summary: {...model.summary(), fingerprints: fingerprints.summary(model.chat, model.canonical, fingerprintAllowed), semantics: semantics.summary(fingerprintAllowed)}}); } catch {}
      if (!current(pollGeneration)) return;
      const allowFingerprint = reply?.ok === true && reply.data?.fingerprintAllowed === true && eligible();
      if (!allowFingerprint) {
        fingerprints.clear(); semantics.clear();
        // A revoked lease cannot revive an in-flight copy after eligibility returns.
        if (fingerprintAllowed) session = crypto.randomUUID();
      }
      fingerprintAllowed = allowFingerprint; control();
      if (reply?.ok && reply.data?.arm === true && eligible() && canonicalAt && Date.now() - canonicalAt < 5000 && model.canonical.length) {
        model.arm(); arm++; control();
      }
    } catch { if (current(token)) clear(); }
    finally {
      polling = false;
      if (current()) pollTimer=setTimeout(() => { pollTimer=null; void poll(); }, 500);
    }
  }
  function cancelRequests() { for (const cancel of requests) cancel(); requests.clear(); }
  function onPageHide() {
    stopped = true; globalThis.clearTimeout?.(pollTimer); pollTimer=null;
    clear(); cancelRequests();
  }
  function onPageShow() {
    if (!available() || !stopped) return;
    stopped=false; void poll();
  }
  function dispose() {
    if (disposed) return;
    disposed = true;
    onPageHide();
    window.removeEventListener?.('message', onMetadata);
    window.removeEventListener?.('pagehide', onPageHide);
    window.removeEventListener?.('pageshow', onPageShow);
    if (globalThis.ArchiveResponseTime === api) delete globalThis.ArchiveResponseTime;
  }
  globalThis.PAIAResponseBridge = Object.freeze({dispose});
  globalThis.ArchiveResponseTime = api;
  window.addEventListener('pagehide', onPageHide);
  window.addEventListener('pageshow', onPageShow);
  lifecycle?.add(dispose);
  void poll();
})();
