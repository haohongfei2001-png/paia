# Current restore-only contract

Backup-file generation, all content/statistics/Context exports and dedicated sharing are cancelled. Their old commands must refuse without side effects; no Settings entry remains. Existing backup files, content and credentials are not automatically deleted.

Existing-file restore remains: select a file, validate its supported format and integrity, preview its effect, then explicitly confirm. Restore must preserve current data on failure, enforce deletion/tombstone and revision protections, and never reactivate external grants, restore credentials or invoke AI. Supported restore modes and size limits follow the current format validator and acceptance coverage.

The version-specific sections below document historical formats and compatibility, including retired creation paths. They are decoder/migration history, not current backup-generation features or development tasks.

## UX-R4 compatibility (MIG-07/08/10)

Existing Memory config gains a strictly validated optional boolean `localOnly`, defaulting only when absent. Backup preserves its value, the independent `externalAccess` value, Profiles and exact exclusions. Old false connection access remains false; restore creates no consumers or Grants. The new fixed manual materials, revisions/spans selected for this task, output generations, overrides, redactions and note remain ephemeral and never enter Backup. Old Preview identity is not migrated into manual authorization. Unknown config fields/types remain rejected; format version, physical schema and existing size limits are unchanged.

# UX-R3 / v0.12 compatibility

UX-R3 adds binding metadata (`bodyBinding`, `workingInputId`, `bindingRevision`, `bindingLength`, `thoughtEditedAt`) to the existing Thought Backup whitelist. Existing revision snapshots retain the body/binding and protection state required for safe Undo. The portable `thought-layout:v1` preference preserves grid/list choice. `thought-binding:v1` migration progress, `thought-reverse-edit:v1` permission and Topic/Input reading anchors are not exported. Restore resumes the same strict classifier and resets reverse editing to off. Old Backups without binding metadata remain supported; ambiguous references preserve their existing text as protected independent Thoughts. Unknown binding values are rejected. Source/Input bodies and historical edits are never rewritten by this migration.

Response-only evidence for a new, independently authored Thought is `context_only`. Purging that Source clears the citation; a referenced rewrite is cleared, while the independent new body and independently authored notes are preserved. Binding changes do not remove tombstones, source dependencies or existing refusal policies. See `docs/ux/rounds/UX_R3_REPORT.md` for certification evidence.

## UX-R2 compatibility retained

Backup v1/schema 5 now explicitly accepts current v0.12 application headers and validates the two body-free policy records `revisit-policy:v1` and `capture-policy:v1` in the existing organization-state allowlist. Known editable shell preferences round-trip through their validator. Unknown newer formats, policy versions and fields are rejected.

Input/document/topic Revisit exclusions and exact conversation capture exclusions travel with the content. Restore always resets old-content resurfacing to **off**, preserves existing local capture exclusions, and clears `reading:v1`, `revisit:v2` and historical `revisit:v1` positions before establishing a fresh local visit boundary. It never infers read completion, restores AI credentials, changes capture consent or bypasses tombstones. This adds no new body section, format version or database schema.

The existing empty-library, 64 MB / 100,000 item limits remain. The UX-R2 100,000-Input browser fixture verifies bounded Reader/Revisit reads; it does not claim that a 100,000-Source whole-library Backup fits those limits.

# v0.9.2 大库与归属一致性补充

恢复继续限制空库、64 MB / 100000 项。Source、Input、状态、版本分别计项，100000 Sources 的导出通常超出当前恢复边界。导出超限会明确提醒保留原库；本轮不扩大恢复上限、不宣称 100k 全库恢复已通过。分段导出与 UI 心跳在 10k/100k 合成数据上验证。恢复重建索引同时覆盖工作文档与原始 Source 聊天，移走最后 Input 不能令原始档案失去计数。

# PAIA Backup v1

v0.9.0 保持 v1 文件和 schema 5 兼容。Source 可携带标准化的导入时间/provider/profile，以及只含身份哈希与分支关系的可选 importEvidence；恢复时回到 importSources 事实元数据表。不会保存或恢复 ZIP、raw JSON、导入任务、文件指纹、批次、原始预检缓存或自动执行状态。旧 v0.8.1 备份仍可恢复；当前版本不支持降级恢复到旧扩展。

v0.8.1 在 Settings 提供主动创建备份、选择文件、校验预览和确认恢复。所有处理在本机完成，不上传，不包含 API Key。文件包含私人内容，由用户自行保管；当前没有应用层加密。

## 格式

扩展名 `.paia-backup`，UTF-8 NDJSON：一行 header、若干 item、一行 footer。header 包含 `format: PAIA Backup`、`formatVersion: 1`、应用版本、物理数据库 schema 5、创建时间和内容分区。每个 item 使用明确的领域字段白名单；不是 IndexedDB raw dump。footer 包含各分区数量、总数量和 SHA-256 链根。第一个哈希为 SHA256(换行 + header JSON)，随后为 SHA256(前一哈希 + 换行 + 本行 JSON)。这是完整性校验，不是数字签名。

内容包括仍可恢复的 Source、Input 工作层及文档、Thought Entries、Topics、Sections、Placements、证据与依赖、用户编辑与保护、重要修订、删除/抑制标记、已完成的布局历史、操作回执、必要的 Organizer 检查点、共享预算与阅读偏好。搜索索引、运行中的任务、导入临时数据、原始诊断、API Key、会话凭证和捕获授权不导出。已保存的 AI presentation 保留其证据与人工保护；无效生成内容继续按现有规则隐藏。

导出分段读取（每段最多 40 项，通常不超过 1 MB），用内容版本标记检测并发变更。正在付费整理或更改主题布局时不能开始。期间出现编辑或永久删除会使本次导出失效；重复分块请求是幂等的。页面不会同步 stringify 整个数据库。浏览器下载仍需容纳最终 Blob，超大库不属于本版验收范围。

## 恢复

首版只恢复到空库，最大 64 MB / 100,000 项 / 单行 8 MB。文件流式解码，在 UI 与后台分别校验版本、结构、字段、数量和完整性；后台额外验证来源身份、引用关系、布局、人工保护与固定设置。未确认前只在有限的会话内存中暂存，15 分钟无活动失效；关闭页面或重启后重新选择文件。

预览显示日期、应用/格式版本、Input、Topic、Entry 与修订数量。必须明确点击“确认恢复到空库”。后台在写入事务内再次检查当前库和删除标记，再以一个 strict IndexedDB 事务恢复领域数据并重建必要索引。事务失败整体回滚。搜索索引随后在本机分批重建。必要的小型设置通过同事务中的恢复标记完成；若恰在数据提交后重启，可幂等补齐设置。当前 API Key 和捕获授权保持当前会话设置，恢复不会调用 Provider 或恢复连续请求。

有现有正文、主题、修订、输入移除或 suppression 时拒绝覆盖。已有 Source / snapshot 墓碑优先，即使待恢复的旧备份自身没有墓碑，也拒绝导入冲突来源。备份自身包含的墓碑同样参与检查。

永久删除不会回收已经下载到扩展之外的旧备份。完全新的空库无法知道另一个已删除数据库中的后续墓碑；因此旧文件的生命周期仍由用户掌握。本机新建备份会排除当前已永久删除的来源和相应可恢复历史。

## 升级

v0.8.1 保持物理 schema 5，没有破坏性数据迁移，不额外复制整个私人数据库。新增阅读偏好缺失时采用正序/默认原话视图；新状态按需写入。已有 v0.7.x → v5 的分阶段迁移与失败恢复机制继续保留。本轮使用冻结 v0.7.2c 和 v0.8.0 的真实程序 schema，在同一个隔离扩展实例中验证升级、部分旧 AI 缓存与重复运行。未访问日常私人库。
