import {fail,LIMITS} from './errors.js';
import {identify,identifySource,hashText} from '../dedupe.js';
import {canonicalChat} from '../validation.js';
export const validHash=v=>typeof v==='string'&&/^[a-f0-9]{64}$/.test(v);
const id=v=>typeof v==='string'&&/^[A-Za-z0-9_-]{8,128}$/.test(v);
const fields=new Set(['platform','chatId','messageId','title','text','role','sent','contentType','createTime','order','branch','parentMessageId']);
const platforms=new Set(['chatgpt','claude']);
export const sourceIdentityChat=(platform,chatId)=>platform==='chatgpt'?chatId:`${platform}:${chatId}`;
const identityChat=r=>sourceIdentityChat(r.platform,r.chatId);
export function validPortableSourceRecord(r){
 const platform=r?.platform??'chatgpt';if(!platforms.has(platform)||typeof r?.originalText!=='string')return false;
 if(platform==='chatgpt'){const chat=canonicalChat(r.chatUrl);return !!chat&&(!r.chatId||chat.id===r.chatId);}
 return r.chatUrl===''&&r.importProvider==='official_export'&&r.importProfile==='claude-conversations-v1'&&id(r.chatId)&&id(r.sourceMessageId);
}
export function timestamp(v,now=Date.now()){if(v===null)return null;if(typeof v!=='string'||!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(v))return null;const n=Date.parse(v);return Number.isFinite(n)&&n>=946684800000&&n<=now&&new Date(n).toISOString()===v?v:null;}
// This is PAIA's internal projection, never a claim about official JSON fields.
export function validateRows(input){if(!Array.isArray(input)||!input.length||input.length>LIMITS.batchRows)fail('INVALID_IMPORT');let chars=0;return input.map(r=>{const platform=r?.platform??'chatgpt';if(!r||typeof r!=='object'||Array.isArray(r)||Object.keys(r).some(k=>!fields.has(k))||!platforms.has(platform)||!id(r.chatId)||!id(r.messageId)||r.role!=='user'||r.sent!==true||r.contentType!=='text'||typeof r.text!=='string'||!r.text.length||r.text.length>LIMITS.stringChars||typeof r.title!=='string'||r.title.length>1000||!['current','other','ambiguous'].includes(r.branch)||r.parentMessageId!==null&&!id(r.parentMessageId)||r.parentMessageId===r.messageId||r.order!==null&&(!Number.isSafeInteger(r.order)||r.order<1||r.order>1000000)||r.createTime!==null&&typeof r.createTime!=='string')fail('INVALID_IMPORT');chars+=new TextEncoder().encode(r.text+r.title).length;if(chars>LIMITS.batchBytes)fail('RESOURCE_LIMIT');return {platform,chatId:r.chatId,messageId:r.messageId,title:r.title,text:r.text,role:'user',sent:true,contentType:'text',createTime:r.createTime,order:r.order,branch:r.branch,parentMessageId:r.parentMessageId};});}
export async function prepareRows(input){const rows=validateRows(input),prepared=[];for(const r of rows){const keyChat=identityChat(r),identity=await identify(keyChat,r.messageId,r.text);prepared.push({...r,...identity,chatHash:await hashText(keyChat),parentSourceKey:r.parentMessageId?await identifySource(keyChat,r.parentMessageId):null,time:timestamp(r.createTime),timeInvalid:r.createTime!==null&&!timestamp(r.createTime)});}return {rows:prepared,digest:await hashText(JSON.stringify(rows))};}
