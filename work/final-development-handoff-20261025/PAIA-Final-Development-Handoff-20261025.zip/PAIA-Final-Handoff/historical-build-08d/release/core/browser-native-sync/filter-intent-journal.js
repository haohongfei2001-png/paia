import {validateOperation} from './core.js';
import {validateEntity,validateEntityAsync,projectEntity} from './codecs.js';
import {JournalRestoreFence} from './prompt-journal.js';
import {clone,equal,fail,hash} from './value.js';

// Optional existing-Source-only owner. No Source creation, restore, or transport.
const LIMIT=16, BODY_LIMIT=1024*1024;
async function sources(t,key){
 if(!hash(key))fail('BNS_FILTER_SOURCE_UNQUALIFIED');
 if(await t.get('tombstones','source:'+key))fail('BNS_FILTER_SOURCE_PURGED');
 const indexes=await t.all('recordIndex','bySource',key,LIMIT+1);
 if(!indexes.length||indexes.length>LIMIT)fail('BNS_FILTER_SOURCE_UNQUALIFIED');
 const rows=[];let bodyChars=0;
 for(const index of indexes){
  const row=(await t.get('records',index.id))?.value;
  if(!row||row.id!==index.id||row.sourceKey!==key||index.sourceKey!==key||index.dedupeKey!==row.dedupeKey||typeof row.originalText!=='string'||row.originalText.length>BODY_LIMIT)fail('BNS_FILTER_SOURCE_UNQUALIFIED');
  if(await t.get('tombstones','snapshot:'+row.dedupeKey))fail('BNS_FILTER_SOURCE_PURGED');
  if((bodyChars+=row.originalText.length)>BODY_LIMIT)fail('BNS_FILTER_SOURCE_UNQUALIFIED');
  rows.push(projectEntity('source',row));
 }
 return rows;
}

const restoredProofs=new WeakMap();
export async function prepareRestoredFilterSources(records){
 if(!Array.isArray(records)||records.length>128)fail('BNS_FILTER_SOURCE_UNQUALIFIED');
 const byKey=new Map();for(const candidate of records){const row=projectEntity('source',candidate);await validateEntityAsync('source',row);const rows=byKey.get(row.sourceKey)||[];rows.push(row);if(rows.length>LIMIT||rows.reduce((n,x)=>n+x.originalText.length,0)>BODY_LIMIT)fail('BNS_FILTER_SOURCE_UNQUALIFIED');byKey.set(row.sourceKey,rows);}
 const cap=Object.freeze({});restoredProofs.set(cap,byKey);return cap;
}

const originalFilterIntentOwners=new WeakMap();
export class FilterIntentSyncJournal{
 constructor(core){this.core=core;this.fence=new JournalRestoreFence(core);this.prepared=new WeakMap();this.working=new WeakSet();originalFilterIntentOwners.set(this,{core:this.core,fence:this.fence,prepared:this.prepared,working:this.working});}
 assertStore(store){if(store.repository!==this.core.repository)fail('BNS_BINDING_CHANGED');}
 async qualify(keys){
  keys=[...new Set(keys)];if(!keys.length||keys.length>LIMIT)fail('BNS_FILTER_SOURCE_UNQUALIFIED');
  const before=await this.core.transaction(false,async t=>({fence:await this.fence.snapshot(t),generation:(await t.get('meta','backup-data-generation'))?.value||0,sources:await Promise.all(keys.map(key=>sources(t,key))),local:await Promise.all(keys.map(key=>t.get('filterIntents',key)))}));
  for(const rows of before.sources)for(const row of rows)await validateEntityAsync('source',row);
  // Bounded transient verified bodies support exact commit comparison; never persisted.
  return {...before,keys};
 }
 async current(t,before){
  if(!equal(await this.fence.snapshot(t),before.fence)||((await t.get('meta','backup-data-generation'))?.value||0)!==before.generation)fail('BNS_FILTER_SOURCE_CHANGED');
  for(let i=0;i<before.keys.length;i++)if(!equal(await sources(t,before.keys[i]),before.sources[i])||!equal((await t.get('filterIntents',before.keys[i]))??null,before.local[i]??null))fail('BNS_OWNER_CHANGED');
 }
 async restoredSources(t,cap,keys){
  const proof=restoredProofs.get(cap);if(!proof||!Array.isArray(keys)||!keys.length||keys.length>LIMIT||new Set(keys).size!==keys.length)fail('BNS_PREPARATION_REQUIRED');
  const rows=[];for(const key of keys){const current=await sources(t,key),expected=proof.get(key);if(!expected||!equal([...current].sort((a,b)=>a.id.localeCompare(b.id)),[...expected].sort((a,b)=>a.id.localeCompare(b.id))))fail('BNS_FILTER_SOURCE_CHANGED');rows.push(current);}
  return {keys,sources:rows,local:await Promise.all(keys.map(key=>t.get('filterIntents',key))),fence:await this.fence.snapshot(t),generation:(await t.get('meta','backup-data-generation'))?.value||0};
 }
 async prepareKeep(store,id){
  this.assertStore(store);
  const binding=await store.run(()=>store.repository.transaction(false,async t=>{
   const b=(await t.get('blocks',id))?.value;if(!b||b.excluded||b.branchStatus||!Array.isArray(b.provenance)||b.provenance.length>LIMIT)fail('BNS_FILTER_SOURCE_UNQUALIFIED');
   return {provenance:clone(b.provenance),keys:await Promise.all(b.provenance.map(async p=>(await t.get('recordIndex',p.sourceRecordId))?.sourceKey))};
  }));
  const before=await this.qualify(binding.keys),at=store.clock(),changes=[];
  for(let i=0;i<before.keys.length;i++){
   const key=before.keys[i],head=await this.core.read('head','filterIntent',key),old=before.local[i];
   if(head?.purged)fail('BNS_ENTITY_PURGED');if(head?.revisions.length>1)fail('BNS_CONFLICT_REQUIRES_RESOLUTION');
   if(head){const previous=await this.core.read('revision',head.revisions[0]);if(!equal(previous?.operation.value,old))fail('BNS_OWNER_CHANGED');}
   else if(old)fail('BNS_BOOTSTRAP_REQUIRED');
   changes.push({type:'filterIntent',value:{id:key,keep:true,reason:'restored_from_filter',at},expectedParents:head?.revisions||[]});
  }
  const prepared=await this.fence.prepare(()=>this.core.prepare(changes));this.prepared.set(prepared,{before,id,at,binding});return prepared;
 }
 async prepareWorking(store,b,at,{wrapped=false}={}){
  if(typeof wrapped!=='boolean')fail('BNS_WORKING_BINDING_REQUIRED');
  this.assertStore(store);const keys=await this.core.transaction(false,t=>Promise.all(b.provenance.map(async p=>(await t.get('recordIndex',p.sourceRecordId))?.sourceKey)));
  const before=await this.qualify(keys),changes=[];
  for(let i=0;i<before.keys.length;i++){const key=before.keys[i];if(wrapped&&await this.core.read('head','filterIntent',key))fail('BNS_WORKING_LEGACY_HEAD_UNSUPPORTED');const head=await this.core.read('head',wrapped?'inputWorkingMember':'filterIntent',wrapped?'filterIntent:'+key:key),old=before.local[i];if(head?.purged||head?.revisions.length>1)fail('BNS_OWNER_CHANGED');if(head){const row=await this.core.read('revision',head.revisions[0]);if(!equal(wrapped?row?.operation.value.entity:row?.operation.value,old))fail('BNS_OWNER_CHANGED');}else if(old)fail('BNS_BOOTSTRAP_REQUIRED');changes.push({type:'filterIntent',value:{id:key,keep:true,reason:'user_edit',at},expectedParents:head?.revisions||[]});}
  const capability=Object.freeze({});this.prepared.set(capability,{before,id:b.id,at,binding:{keys,provenance:clone(b.provenance)},changes,wrapped});return capability;
 }
 workingChanges(capability){const value=this.prepared.get(capability);if(!value?.changes)fail('BNS_PREPARATION_REQUIRED');return clone(value.changes);}
 bindWorking(capability,prepared){const value=this.prepared.get(capability);if(!value?.changes||!equal(prepared.operations.filter(x=>value?.wrapped?x.type==='inputWorkingMember'&&x.value.entityType==='filterIntent':x.type==='filterIntent').map(x=>value.wrapped?x.value.entity:x.value),value.changes.map(x=>x.value)))fail('BNS_PREPARATION_REQUIRED');this.prepared.set(prepared,value);this.working.add(prepared);this.prepared.delete(capability);}
 async authorize(t,prepared,b,reason,userEdited){
  const saved=this.prepared.get(prepared),working=this.working.has(prepared);if(!saved||saved.id!==b.id||(working?reason!=='user_edit'||userEdited!==true:reason!=='restored_from_filter'||userEdited))fail('BNS_FILTER_WRITER_UNSUPPORTED');
  const keys=await Promise.all(b.provenance.map(async p=>(await t.get('recordIndex',p.sourceRecordId))?.sourceKey));
  if(!equal(b.provenance,saved.binding.provenance)||!equal(keys,saved.binding.keys))fail('BNS_OWNER_CHANGED');
  await this.current(t,saved.before);if(!working)await this.fence.commit(t,prepared);return saved.at;
 }
 release(prepared){this.prepared.delete(prepared);}
 async commit(t,prepared){if(!this.prepared.has(prepared))fail('BNS_PREPARATION_REQUIRED');return this.core.commitPrepared(t,prepared,{materialize:false});}
 async applyRestored(t,cap,sourceProof){
  const a=filterApplications.get(cap);if(!a||a.journal!==this)fail('BNS_PREPARATION_REQUIRED');const operation=a.operation,before=await this.restoredSources(t,sourceProof,[operation.entityId]);
  return applyFilterOwner(this,t,operation,before);
 }
 async receive(input){
  const operation=clone(await validateOperation(input));if(operation.datasetId!==this.core.datasetId)fail('BNS_DATASET_MISMATCH');
  if(operation.type!=='filterIntent'||operation.kind!=='put'||operation.value?.reason!=='restored_from_filter')fail('BNS_FILTER_WRITER_UNSUPPORTED');validateEntity('filterIntent',operation.value);
  const before=await this.qualify([operation.entityId]);
  // This bounded owner does not admit unresolved dependency queues or full restore.
  return this.core.transaction(true,async t=>{
   await this.current(t,before);
   return applyFilterOwner(this,t,operation,before);
  });
 }
}

const filterApplications=new WeakMap();
export async function prepareFilterApplication(journal,input){
 if(!(journal instanceof FilterIntentSyncJournal))fail('BNS_BINDING_CHANGED');const operation=clone(await validateOperation(input));
 if(operation.datasetId!==journal.core.datasetId)fail('BNS_DATASET_MISMATCH');
 if(operation.type!=='filterIntent'||operation.kind!=='put'||operation.value?.reason!=='restored_from_filter')fail('BNS_FILTER_WRITER_UNSUPPORTED');
 const cap=Object.freeze({});filterApplications.set(cap,{journal,operation});return cap;
}
async function applyFilterOwner(journal,t,operation,before){
   for(const parent of operation.parents)if(!await journal.core.get(t,'revision',parent))fail('BNS_FILTER_ANCESTRY_REQUIRED');
   const old=await journal.core.get(t,'head','filterIntent',operation.entityId),local=before.local[0];
   if(old?.purged)fail('BNS_ENTITY_PURGED');
   if(local){const values=await Promise.all((old?.revisions||[]).map(async id=>(await journal.core.get(t,'revision',id))?.operation.value));if(!values.some(value=>equal(value,local)))fail('BNS_OWNER_CHANGED');}
   const result=await journal.core.applyInTransaction(t,operation,{origin:'remote',materialize:false});
   const head=await journal.core.get(t,'head','filterIntent',operation.entityId);
   if(head?.revisions.length===1&&head.revisions[0]===operation.revisionId&&!equal(before.local[0]??null,operation.value))await t.put('filterIntents',clone(operation.value));
   return result;
}

// Constructor-private identity only for the selected native Source/Working
// profile. No registration, reader, transport or write authority is exported.
const originalFilterIntentOwnersDescriptor=Object.getOwnPropertyDescriptor, originalFilterIntentOwnersOwn=Object.hasOwn, originalFilterIntentOwnersPrototype=Object.getPrototypeOf;
const originalFilterIntentOwnersMethods=new Map(Object.getOwnPropertyNames(FilterIntentSyncJournal.prototype).filter(name=>name!=='constructor').map(name=>[name,originalFilterIntentOwnersDescriptor(FilterIntentSyncJournal.prototype,name)?.value]));
export function assertOriginalFilterIntentOwner(journal,core){
 const binding=originalFilterIntentOwners.get(journal);if(arguments.length!==2||!binding||binding.core!==core||originalFilterIntentOwnersPrototype(journal)!==FilterIntentSyncJournal.prototype)fail('BNS_SOURCE_WORKING_OWNER_REQUIRED');
 for(const [name,value]of Object.entries(binding)){const d=originalFilterIntentOwnersDescriptor(journal,name);if(!d||!originalFilterIntentOwnersOwn(d,'value')||d.value!==value)fail('BNS_SOURCE_WORKING_OWNER_REQUIRED');}
 for(const [name,value]of originalFilterIntentOwnersMethods){const own=originalFilterIntentOwnersDescriptor(journal,name),d=own||originalFilterIntentOwnersDescriptor(FilterIntentSyncJournal.prototype,name);if(!d||!originalFilterIntentOwnersOwn(d,'value')||typeof value!=='function'||d.value!==value)fail('BNS_SOURCE_WORKING_OWNER_REQUIRED');}
}
