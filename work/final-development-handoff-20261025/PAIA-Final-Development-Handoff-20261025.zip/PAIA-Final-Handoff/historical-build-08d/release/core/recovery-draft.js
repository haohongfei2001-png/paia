const PREFIX='paia-recovery-draft:v1:';
const VERSION=1;
const DEFAULT_TTL_MS=7*24*60*60*1000;
const DEFAULT_MAX_BYTES=1250*1024;
const DEFAULT_MAX_DRAFTS=32;
const DEFAULT_MAX_TOTAL_BYTES=4*1024*1024;
const KINDS=new Set(['document','library_entry','topic_metadata','section_metadata','ai_presentation','context_item','settings_feedback']);
const plain=value=>!!value&&typeof value==='object'&&!Array.isArray(value);
const validId=value=>typeof value==='string'&&value.length>0&&value.length<=512;
const clone=value=>JSON.parse(JSON.stringify(value));
const bytes=value=>new TextEncoder().encode(JSON.stringify(value)).length;
const key=(kind,ownerId)=>PREFIX+kind+':'+ownerId;

export const FEEDBACK_DRAFT_OWNER='settings-feedback';
export function validFeedbackDraft(draft){
 const op=draft?.operation;
 return draft?.kind==='settings_feedback'&&draft.ownerId===FEEDBACK_DRAFT_OWNER&&validId(draft.token)&&validId(draft.epoch)&&
  Array.isArray(draft.sourceRecordIds)&&draft.sourceRecordIds.length===0&&plain(op)&&
  Object.keys(op).length===3&&op.type==='SETTINGS_FEEDBACK_DRAFT'&&typeof op.body==='string'&&
  bytes(op.body)<=1024*1024&&Object.hasOwn(op,'expectedToken')&&(op.expectedToken===null||validId(op.expectedToken));
}

function rowValid(row){
 return plain(row)&&row.version===VERSION&&KINDS.has(row.kind)&&validId(row.ownerId)&&validId(row.token)&&
  Array.isArray(row.sourceRecordIds)&&row.sourceRecordIds.length<=2000&&row.sourceRecordIds.every(validId)&&
  (row.kind!=='settings_feedback'||validFeedbackDraft(row))&&Number.isFinite(row.updatedAt)&&Number.isFinite(row.expiresAt)&&plain(row.operation);
}

export class RecoveryDraftStore{
 constructor(local,{clock=()=>Date.now(),ttlMs=DEFAULT_TTL_MS,maxBytes=DEFAULT_MAX_BYTES,maxDrafts=DEFAULT_MAX_DRAFTS,maxTotalBytes=DEFAULT_MAX_TOTAL_BYTES}={}){
  if(!local?.get||!local?.set||!local?.remove)throw new TypeError('recovery storage unavailable');
  this.local=local;this.clock=clock;this.ttlMs=ttlMs;this.maxBytes=maxBytes;this.maxDrafts=maxDrafts;this.maxTotalBytes=maxTotalBytes;
 }
 async save({kind,ownerId,token,operation,sourceRecordIds=[],epoch}){
  if(!KINDS.has(kind)||!validId(ownerId)||!validId(token)||!plain(operation)||!Array.isArray(sourceRecordIds)||sourceRecordIds.length>2000||sourceRecordIds.some(id=>!validId(id)))throw new TypeError('invalid recovery draft');
  if(epoch!==undefined&&!validId(epoch))throw new TypeError('invalid recovery epoch');
  if(kind==='settings_feedback'&&!validFeedbackDraft({kind,ownerId,token,operation,sourceRecordIds,epoch}))throw Object.assign(new Error('INVALID_REQUEST'),{code:'INVALID_REQUEST'});
  const now=this.clock(),row={version:VERSION,kind,ownerId,token,...(epoch===undefined?{}:{epoch}),operation:clone(operation),sourceRecordIds:[...new Set(sourceRecordIds)],updatedAt:now,expiresAt:now+this.ttlMs};
  const rowBytes=bytes(row);if(rowBytes>this.maxBytes||rowBytes>this.maxTotalBytes)throw Object.assign(new Error('RECOVERY_DRAFT_TOO_LARGE'),{code:'RECOVERY_DRAFT_TOO_LARGE'});
  const ownKey=key(kind,ownerId),all=await this.local.get(null),existing=[],remove=[];
  if(kind==='settings_feedback'){
   const prior=all?.[ownKey],current=rowValid(prior)&&prior.expiresAt>now&&prior.epoch===epoch?prior:null;
   if(current?.token===token){if(JSON.stringify(current.operation)===JSON.stringify(operation))return clone(current);throw Object.assign(new Error('CONFLICT'),{code:'CONFLICT'});}
   if((current?.token??null)!==operation.expectedToken)throw Object.assign(new Error('CONFLICT'),{code:'CONFLICT'});
  }
  for(const [k,value]of Object.entries(all||{})){if(!k.startsWith(PREFIX)||k===ownKey)continue;if(!rowValid(value)||value.expiresAt<=now){remove.push(k);continue;}existing.push([k,value,bytes(value)]);}
  existing.sort((a,b)=>b[1].updatedAt-a[1].updatedAt);let total=rowBytes,kept=1;
  for(const [k,,size]of existing){if(kept<this.maxDrafts&&total+size<=this.maxTotalBytes){total+=size;kept++;}else remove.push(k);}
  if(remove.length)await this.local.remove([...new Set(remove)]);
  await this.local.set({[ownKey]:row});return clone(row);
 }
 async load(kind,ownerId){
  if(!KINDS.has(kind)||!validId(ownerId))return null;
  const k=key(kind,ownerId),value=(await this.local.get(k))?.[k];
  if(!rowValid(value)||value.kind!==kind||value.ownerId!==ownerId||value.expiresAt<=this.clock()){if(value!==undefined)await this.local.remove(k);return null;}
  return clone(value);
 }
 async list(kind){
  if(!KINDS.has(kind))return [];
  const rows=await this.local.get(null);
  return Object.values(rows||{}).filter(row=>rowValid(row)&&row.kind===kind&&row.expiresAt>this.clock()).slice(0,this.maxDrafts).map(row=>({kind:row.kind,ownerId:row.ownerId,epoch:row.epoch}));
 }
 async clear(kind,ownerId,expectedToken=null){
  if(kind==='settings_feedback'&&(ownerId!==FEEDBACK_DRAFT_OWNER||!validId(expectedToken)))return false;
  if(!KINDS.has(kind)||!validId(ownerId))return false;const k=key(kind,ownerId);
  if(expectedToken!==null){const value=(await this.local.get(k))?.[k];if(!rowValid(value)||value.token!==expectedToken)return false;}
  await this.local.remove(k);return true;
 }
 async clearMany(items=[]){
  if(!Array.isArray(items)||items.length>100)return 0;
  const normalized=items.filter(item=>plain(item)&&KINDS.has(item.kind)&&validId(item.ownerId)&&validId(item.token));
  if(!normalized.length)return 0;
  const keys=normalized.map(item=>key(item.kind,item.ownerId)),all=await this.local.get(keys),remove=[];
  for(let i=0;i<normalized.length;i++){const row=all?.[keys[i]];if(rowValid(row)&&row.token===normalized[i].token)remove.push(keys[i]);}
  if(remove.length)await this.local.remove(remove);return remove.length;
 }
 async prune(){
  const all=await this.local.get(null),rows=[],remove=[];
  for(const [k,row]of Object.entries(all||{})){if(!k.startsWith(PREFIX))continue;if(!rowValid(row)||row.expiresAt<=this.clock())remove.push(k);else rows.push([k,row]);}
  rows.sort((a,b)=>b[1].updatedAt-a[1].updatedAt);let total=0,kept=0;
  for(const [k,row]of rows){const size=bytes(row);if(kept<this.maxDrafts&&total+size<=this.maxTotalBytes){total+=size;kept++;}else remove.push(k);}
  if(remove.length)await this.local.remove([...new Set(remove)]);
  return {kept,bytes:total,removed:new Set(remove).size};
 }
 async clearForSources(sourceIds){
  const ids=new Set((sourceIds||[]).filter(validId));if(!ids.size)return 0;
  const all=await this.local.get(null),remove=[];
  for(const [k,row]of Object.entries(all||{})){if(!k.startsWith(PREFIX)||!rowValid(row))continue;
   if(row.sourceRecordIds.some(id=>ids.has(id)))remove.push(k);
  }
  if(remove.length)await this.local.remove(remove);return remove.length;
 }
 async clearAll(){
  const all=await this.local.get(null),remove=Object.keys(all||{}).filter(k=>k.startsWith(PREFIX));
  if(remove.length)await this.local.remove(remove);return remove.length;
 }
}
export const recoveryDraftPrefix=PREFIX;
