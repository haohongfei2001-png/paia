# Independent PAIA candidate provenance verification

PASS: independent read-only provenance and ordinary static-package verification. No blocking findings remain.

This report faithfully materializes the completed independent verification delivered on 2026-10-24 at approximately 20:43 UTC. Saving this report on 2026-10-24 does not rerun any checks, build, helpers or tests, and does not add new findings.

## Exact run

Run directory:
/workspace/scratch/ff1c41bf9b29/paia-internal-candidate-08d06a3c.TzbtkMPp

Source directory:
/workspace/scratch/ff1c41bf9b29/paia-internal-candidate-08d06a3c.TzbtkMPp/source

Output directory:
/workspace/scratch/ff1c41bf9b29/paia-internal-candidate-08d06a3c.TzbtkMPp/release

## Verified findings

- Clean detached source 08d06a3c3a143bb8db42dfb3ff4f152a05b9722b; tree 6978fc14379cd9d03df5be65f7ca09310dd54cfd.
- All 712 audited inputs match current bytes, SHA256, pinned Git blob IDs and modes; pre/post vectors are identical. Independently reconstructed release allowlist matches all 706 assets, including 10 PNGs. The remaining six inputs are Python helpers/guards.
- Actual fresh output: 703 regular files, 15 expected directories, 8,254,325 bytes. No symlinks, special files, extra paths or unexpected directories.
- Exactly 702 byte-identical copies; only background/service-worker.js changes through the single expected FILTER_DIAGNOSTICS line removal. Exactly the three standard diagnostic files are omitted: ui/structure-diagnostics.js, ui/fingerprint-display.js and ui/source-time-display.js.
- Every output file's modification time falls within the recorded attempt. Version remains 0.55.9 / v0.55.9 Development.
- Attempt 1: exit 0 in 3.615112 seconds, starting 2026-10-24T20:41:24.903634+00:00 and ending 2026-10-24T20:41:28.518945+00:00. Recorded command enforces a 30-second KILL watchdog, 25 CPU seconds, 1 GiB address space and 64 MiB per file.
- The command uses the pinned source's existing build_current_release.py with Python -B -E -S -X utf8. The reviewed call path is ordinary offline packaging and static guards, not helper entry points that launch Node or tests.
- Raw log: 24,655 package checks across 679 resources; product guard passes 703 files; reused=false.
- Root HEAD/status/index/staged diff, 298 staged/untracked working files, eight prior published references and 29 integration REPORT/ZIP artifacts match before/after and current bytes. Root HEAD remains 2f9250fe817dd9eebc0fc1373c05d01dcd7a0ed6.
- Initial empty-index preparation failure is explicitly preserved as pre-build NOT_RUN; separately authorized materialization and the single later build remain distinct. The initial fresh source had correct pinned HEAD/tree but no indexed files and only .git present. No builder invocation occurred before the corrective materialization.

## Verified hash identities

- Baseline audit inventory: 0789bb2ad92ea403bda74ca6f5ca571969417140447dbf99b0686368d66da3de
- Output fingerprint: a13b7c8bb7a053f0f33702da409e62d739384d987cf0bfac22dae33a2b94629b
- Builder source fingerprint: 4f186ea4f1e3f0ca911a31bd385ae8ffc51728c9c16dbdcaf319d412a3f04b29
- Full 712-input path+NUL+bytes+NUL digest: 4435ccf4d55a0ffef336a374c365fd2c1b651e214bf3ce691a2477863968ef39
- inputs.before.json and inputs.after.json: 0f350798d46f75afa7e736fbbfe9fdff65168ca431d597fe8083f5176c6e043f
- output-inventory.json: 14f7bb4b3cd04625ea9c94e8521ed30dffffe34a6e811242a5bacade44ff9988
- protected-snapshot.before.json and protected-snapshot.after.json: 0169c973fcd479f1f3bdbd297de7b0160b9d64b26b58357b028c90dd9a0fae9c
- execution.json: ab2faead502f9ead09c023a003c6f2487a4c7bc445dc35adc5c02c3ea73f9dc4
- build.log: b448003097eec7b363546931780f617df1c6c2193495ae12429d79b16d913e80
- command.txt: 1d92f8409fd74bd23961922d869199ccf5c197ee6f3dc4ce07214d8cbcdf5283
- EVIDENCE.sha256: 143a7ee52feb1334275021776dafb3b3eb6a5cfe6f73c973bcd451595969368a; all 26 entries verify.
- Root status: 856e084dea38077811f71264899e4bb034435348c3040b4f1f3ad26512c2a4c8
- Root staged binary/full-index diff: a8b65fb6d4fae4a755df081bf8d08a28cdc208f17575fd15de0dfe2cb1613984

The full-vector digest above sorts the 712 audited repository-relative paths, then hashes each UTF-8 path followed by NUL, its exact file bytes and NUL. It is separate from the builder's narrower source-sidecar algorithm.

## Qualification limits

The builder sidecar binds 706 assets plus only three helpers; the independently verified external inventory binds all six helpers. The sidecar alone is not complete helper/guard provenance.

This is the actual 703-file candidate, not the earlier forecast or stale 687-file artifact. No native, browser, Full, provider, installation, publication or final-delivery acceptance is established. No source-equivalence claim is made between this 08d06a3c candidate and a native-preparation package pinned to 98761c8 or any other commit.

The independent verifier reran no build, existing helper or test, launched no browser or native tools, and changed no files while conducting verification. The only subsequent write is this standalone reviewer report, outside candidate/source/root directories.
