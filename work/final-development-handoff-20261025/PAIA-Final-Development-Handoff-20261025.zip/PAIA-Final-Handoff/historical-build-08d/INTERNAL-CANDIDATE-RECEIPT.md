# Private internal PAIA candidate receipt

Status: PASS for one ordinary offline build and its static guards only. This is not native qualification, Full certification, installation, publication or final delivery.

## Exact identity

- Source commit: 08d06a3c3a143bb8db42dfb3ff4f152a05b9722b
- Source tree: 6978fc14379cd9d03df5be65f7ca09310dd54cfd
- Fresh detached source: /workspace/scratch/ff1c41bf9b29/paia-internal-candidate-08d06a3c.TzbtkMPp/source
- Candidate: /workspace/scratch/ff1c41bf9b29/paia-internal-candidate-08d06a3c.TzbtkMPp/release
- Version unchanged: 0.55.9 / v0.55.9 Development.
- Actual output: 703 regular files, 8,254,325 bytes, zero symlinks. It is not the stale 687-file artifact.
- Source fingerprint: 4f186ea4f1e3f0ca911a31bd385ae8ffc51728c9c16dbdcaf319d412a3f04b29
- Output fingerprint: a13b7c8bb7a053f0f33702da409e62d739384d987cf0bfac22dae33a2b94629b

## One execution

Start 2026-10-24T20:41:24.903634+00:00; end 2026-10-24T20:41:28.518945+00:00; elapsed 3.615112s; exit 0; reused=false.

Limits: hard 30-second wall watchdog (KILL), 25 CPU seconds, 1 GiB address space, 64 MiB per file. No timeout, limit increase or builder rerun occurred.

The exact command is in command.txt and execution.json. It uses the audited absolute Python with -B -E -S -X utf8 and existing extension/scripts/build_current_release.py to the fresh external output. Only its existing build_release and static guards ran.

Raw log: build.log, SHA256 b448003097eec7b363546931780f617df1c6c2193495ae12429d79b16d913e80.

- PASS: 24,655 package guardrails across 679 runtime resources.
- RELEASE_PRODUCT_GUARD_PASS: 703 files.
- The builder itself explicitly labels this a static audit and says actual logged-in Chrome verification requires separate recorded evidence.

## Source and copied-output verification

All 712 audited files were verified before and after by exact byte count, SHA256, pinned Git blob ID and regular-file/symlink checks. The vectors are identical. They comprise 706 release inputs including all 10 PNGs plus 6 Python helper/guard files. There are no extra allowlisted source files, and the source remains clean at the exact pinned SHA.

The original inventory SHA256 is 0789bb2ad92ea403bda74ca6f5ca571969417140447dbf99b0686368d66da3de. Its exact copy is audited-input-inventory.json. Full source vectors are inputs.before.json and inputs.after.json. All 703 output hashes are in output-inventory.json; both builder fingerprint sidecars were recomputed independently and matched.

Only the standard copied-output transform differs: exactly one FILTER_DIAGNOSTICS dispatch line is removed from background/service-worker.js, and copied ui/structure-diagnostics.js, ui/fingerprint-display.js and ui/source-time-display.js are excluded. Every other emitted file exactly matches its pinned source bytes, including manifest.json. Source files were not changed.

The builder's own source sidecar covers the 706 release inputs plus 3 helpers, not every guard/helper. The complete external 712-file evidence supplies the missing provenance coverage.

## Preparation history

The first audited preparation sequence created the detached worktree and correct sparse rules but left an empty index and no source files. The clean-status check failed before any builder invocation. preparation.log is retained.

The parent explicitly authorized exactly one corrective materialization after verification of the precise new toplevel, HEAD08d06a3c, index zero and only .git present. Offline git read-tree -mu HEAD succeeded; materialization.log and sparse-patterns.txt are retained. The sparse extension checkout excludes only the four audited unavailable historical design/evidence paths. No fetch, broad reset or different-source substitution occurred. This preparation failure did not consume a build attempt; the builder then executed exactly once.

## Preservation

Pre/post protected snapshots are identical. Root HEAD stays 2f9250fe817dd9eebc0fc1373c05d01dcd7a0ed6. Root status, staged binary/full-index diff, index bytes, 298 staged/untracked working files, eight referenced published REPORT/ZIP artifacts and 29 integration REPORT/ZIP artifacts were unchanged.

Root status SHA256: 856e084dea38077811f71264899e4bb034435348c3040b4f1f3ad26512c2a4c8
Root staged-diff SHA256: a8b65fb6d4fae4a755df081bf8d08a28cdc208f17575fd15de0dfe2cb1613984

No source/publication artifact was replaced and no cleanup was performed. All candidate files, sidecars, preparation evidence, execution log and complete hash vectors remain in this private run directory.

## Boundaries

No browser, native, Full, old C/129-group/100k/old-cloud, provider, account, credentials, paid service, network, installation, deployment, upload or release publication action ran. No npm, historical package(), build_internal(), compatibility sampler, JavaScript test or manifest/version mutation ran. Existing failure identities and spent validation allowances remain unchanged. The only established result is exact ordinary candidate packaging with passing static guards.
