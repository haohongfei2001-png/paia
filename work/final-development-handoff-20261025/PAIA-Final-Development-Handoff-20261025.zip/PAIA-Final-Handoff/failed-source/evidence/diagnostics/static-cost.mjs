import {createOriginalRecoveryWork,withOriginalRecoveryWork,finishOriginalRecoveryWork,currentOriginalRecoveryWork} from '../../../extension/core/idb-repository.js';
import {readFile,writeFile,mkdir,mkdtemp,symlink,rm} from 'node:fs/promises';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {fileURLToPath,pathToFileURL} from 'node:url';
import test from 'node:test';
import assert from 'node:assert/strict';
import {IDBFactory,IDBKeyRange} from '../../../extension/tests/vendor/fake-indexeddb/build/esm/index.js';
import {LibraryDocumentsStore} from '../../../extension/core/library-documents-store.js';
import {local,capture,inputEdit} from '../../../extension/tests/harness/thought-m1.mjs';
import {BrowserNativeSyncCore} from '../../../extension/core/browser-native-sync/core.js';
import {SourceBootstrapJournal} from '../../../extension/core/browser-native-sync/source-bootstrap-journal.js';
import {buildCheckpoint,StagedSyncRestore} from '../../../extension/core/browser-native-sync/checkpoints.js';
import {LocalSyncRecoverySession} from '../../../extension/core/browser-native-sync/recovery-session.js';
import {RecoverableCheckpointPublication} from '../../../extension/core/browser-native-sync/checkpoint-publication.js';
import {GoogleDriveAppDataTransport,GOOGLE_APPDATA_SCOPE} from '../../../extension/core/browser-native-sync/providers/google-drive.js';
import {readObject} from '../../../extension/core/browser-native-sync/segments.js';
import {fakeGoogleCheckpointHTTP} from '../../../extension/tests/harness/checkpoint-publication-http.mjs';
globalThis.IDBKeyRange=IDBKeyRange;
const datasetId='SYNTHETIC_union_runtime',binding={subject:'SYNTHETIC_google_subject',clientId:'000000000000-synthetic.apps.googleusercontent.com',generation:'SYNTHETIC_generation',scopes:[GOOGLE_APPDATA_SCOPE]};
async function fresh(t,deviceId,{storage=local()}={}){const factory=new IDBFactory(),store=new LibraryDocumentsStore(storage,{indexedDB:factory});await store.consent(true);await store.finishFoundation();t.after(()=>store.repository.db?.close());const core=new BrowserNativeSyncCore(store.repository,{datasetId,deviceId});store.sourceBootstrapJournal=new SourceBootstrapJournal(core);return {store,core,storage,factory};}
async function reopen(t,f){const deviceId=f.core.deviceId;await f.store.repository.close();const store=new LibraryDocumentsStore(f.storage,{indexedDB:f.factory});await store.finishFoundation();t.after(()=>store.repository.db?.close());const core=new BrowserNativeSyncCore(store.repository,{datasetId,deviceId});store.sourceBootstrapJournal=new SourceBootstrapJournal(core);return {...f,store,core};}
async function source(f,name){const request=capture((await f.store.status()).epoch,'SYNTHETIC_message_'+name,'SYNTHETIC exact '+name+' 中文🙂');request.chat={id:'SYNTHETIC_chat_'+name,url:'https://chatgpt.com/c/SYNTHETIC_chat_'+name,title:'SYNTHETIC '+name};await f.store.capture(request);}
const transport=(f,cloud)=>new GoogleDriveAppDataTransport(f.core,{binding,request:cloud.request,isCurrent:()=>true});
const producer=(f,cloud)=>new RecoverableCheckpointPublication(f.core,{store:f.store,binding:{...binding,provider:'google-drive-appdata'},request:cloud.request,isCurrent:()=>true});
const recovery=(f,cloud,options={})=>new LocalSyncRecoverySession(f.core,{store:f.store,transport:transport(f,cloud),...options});
const canonical=f=>f.store.repository.transaction(false,async tx=>Object.fromEntries(await Promise.all([...tx.tx.objectStoreNames].filter(k=>k!=='meta').map(async k=>[k,await tx.all(k)]))));
const writes=cloud=>cloud.requests.filter(r=>['POST','PUT'].includes(r.method)).length;
async function fixture(t,{receiverStorage}={}){const cloud=fakeGoogleCheckpointHTTP(binding),seed=await fresh(t,'SYNTHETIC_seed');await source(seed,'ancestor');const ancestor=await buildCheckpoint(seed.core,transport(seed,cloud),{grouped:{store:seed.store}}),heads=[];
 for(const name of ['left','right']){const f=await fresh(t,'SYNTHETIC_'+name);const owner=new StagedSyncRestore(f.core,{grouped:{store:f.store}});await owner.stageCheckpoint(ancestor.ref,ref=>transport(f,cloud).get(ref));await owner.activate();await source(f,name);heads.push(await buildCheckpoint(f.core,transport(f,cloud),{grouped:{store:f.store},parents:[ancestor.ref.id]}));}
 return {cloud,seed,ancestor,heads,c:await fresh(t,'SYNTHETIC_receiver',receiverStorage?{storage:receiverStorage}:{})};}

import {GroupedCheckpointRestore,requireActivatedSourceBootstrapUnion,requireSourceBootstrapUnionPublication} from '../../../extension/core/browser-native-sync/group-checkpoint.js';
import {InputWorkingSyncJournal} from '../../../extension/core/browser-native-sync/input-working-journal.js';
import {FilterIntentSyncJournal} from '../../../extension/core/browser-native-sync/filter-intent-journal.js';
import {SourceBootstrapReceiver} from '../../../extension/core/browser-native-sync/source-bootstrap-receive.js';
import {FilterRunner} from '../../../extension/core/filter-runner.js';
const state=f=>f.store.repository.transaction(false,async t=>Object.fromEntries(await Promise.all([...t.tx.objectStoreNames].map(async name=>[name,await t.all(name)]))));
async function window(f,fn,options){const ticket=createOriginalRecoveryWork(f.core.repository,options);try{return await withOriginalRecoveryWork(f.core.repository,ticket,()=>fn(ticket));}finally{finishOriginalRecoveryWork(f.core.repository,ticket);}}
const qualify=f=>window(f,()=>requireSourceBootstrapUnionPublication(f.core,{store:f.store}));
async function restored(t,{added=1}={}){const f=await fixture(t),session=recovery(f.c,f.cloud);await session.recoverDiscovered();const restore=new GroupedCheckpointRestore(f.c.core,{store:f.c.store,restoreId:session.restoreId});while(!(await window(f.c,()=>restore.cleanup())).complete){}const original=await restore.stage.read('restore');for(let i=0;i<added;i++)await source(f.c,'local_'+i);return {...f,session,restore,original};}
async function manifest(f,ref){return JSON.parse(new TextDecoder().decode(await readObject(ref,r=>transport(f.c,f.cloud).get(r))));}
async function unchangedRefusal(f,action=()=>qualify(f.c)){const before=await state(f.c),n=writes(f.cloud);await assert.rejects(action);assert.deepEqual(await state(f.c),before);assert.equal(writes(f.cloud),n);}


import {measureSourceWorkingPhysicalTree} from '../../../extension/core/browser-native-sync/source-working-physical.js';
test('bounded static five-source retained-cut cost inventory',async t=>{const f=await restored(t,{added:0}),pub=producer(f.c,f.cloud);await pub.prepare();await pub.publish();await source(f.c,'second_0');await source(f.c,'second_1');const rows=await state(f.c),sizes=Object.fromEntries(Object.entries(rows).map(([name,value])=>[name,{rows:value.length,bytes:measureSourceWorkingPhysicalTree(value).B}]));console.log(JSON.stringify({tables:sizes,totalRows:Object.values(sizes).reduce((n,r)=>n+r.rows,0),totalBytes:Object.values(sizes).reduce((n,r)=>n+r.bytes,0),metaGroups:Object.fromEntries(['revision:','receipt:','sequence:','entityRevision:','head:','groupItem:','restore:','google-appdata-allocation:'].map(kind=>{const selected=rows.meta.filter(row=>row.id.includes(':'+kind));return [kind,{rows:selected.length,bytes:measureSourceWorkingPhysicalTree(selected).B}];}))}));});
