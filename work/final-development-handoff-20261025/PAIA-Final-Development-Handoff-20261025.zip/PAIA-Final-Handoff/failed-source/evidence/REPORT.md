# Isolated Source-union continuation: PARTIAL / NOT ACCEPTED

## Identity and scope

- Base: d7604d8d1f7f22563734f0a5349493c8ffc55fab.
- Branch: codex/source-union-publication-continuation-20261024.
- Original integration/root checkout was not edited, reset or cleaned.
- Owned runtime: group-checkpoint.js, source-union-publication-continuation.js,
  recovery-session.js and checkpoint-publication.js only.
- Exact original activation helper remains byte-identical. No durable sourceCut,
  remote format, schema, native/global gate, dependency, version or provider
  implementation change. No remote publication or deployment.
- Runtime and owning-test SHA-256 values: SOURCE-SHA256.txt.
- Independent review remains incomplete. This branch must not be folded into an
  accepted integration or presented as finished.

## Outcome

The publication-only proof admits genuine complete local-device Source groups
following the authenticated original sibling union while retaining the original
Source subset and deriving exact new allocations. The original encoder and both-
parent/real-common-descendant revision retention remain the wire owner.

The private retained cut is checked again at actual upload dispatch and terminal
confirmation. Only exact original provider controls authenticated against the
producer's validated local publication journal are exempt from whole-cut equality.
Initial proof compilation uses the existing discovery ticket; subsequent checks
charge the distinct existing producer ledger. No new/reset/prepaid/enlarged budget.

BLOCKER: the normal restored-union path before disposable stage cleanup still
fails BNS_CHECKPOINT_PUBLICATION_LIMIT with just one new local Source group. The
successful fixtures explicitly completed original cleanup. No cleanup or staged-
body exception was silently introduced. The failing positive test is retained.

## Verification chronology

Each line is its own invocation, not an aggregate relabeling of earlier failures.

- initial-existing.txt: two original publication/lost-ACK controls, 2/2 pass.
- owning-initial.txt: 43 cases, 26 pass / 17 fail. Fixture errors used nonexistent
  FilterRunner.run/core.all and attempted protected marker insertion through the
  guarded writer; corrected to real owner APIs/raw synthetic fixture setup.
- terminal-first.txt: 6 cases, 3 pass / 3 fail. New producer proof was required
  before the original initial #same, but publish still performed #same first.
  Parent discovery now establishes the private cut before original rebuilding.
- terminal-second.txt: 3 cases, 2 pass / 1 fail. Exact recovered Source values
  matched, but canonical snapshot ordering differs after genuine restore; the
  test now compares all exact records by stable ID, not physical insertion order.
- owning-second.txt: 48/48 pass on the earlier same-repository-fence bridge.
- forced-terminal.txt: 6 cases, 5 pass / 1 fail. Forced actual dispatch/terminal
  complete comparisons correctly caught another Store's protocol mutation, but
  unchanged three-restored-plus-two-new common-descendant publication hit quota.
- existing-combination.txt: eight complete preexisting files, 251/251 pass.
- static-cost.txt: bounded read-only diagnostic, 1/1; five Sources had 282 rows,
  182,530 physical bytes, including 232 metadata rows / 148,784 bytes. The original
  restore receipt alone was 26,020 bytes. No budget was altered by this diagnostic.
- owning-final-partial.txt: 49 cases, 48 pass / 1 fail, preserving the forced-cut
  three-plus-two original quota failure before reader deduplication.
- value-only-reader.txt: unchanged original three-plus-two test, 1/1 pass after
  replacing added key/value-wrapper pages with existing bounded value-only reads.
  Exact ordering, every value, all operands and cumulative charges remain.
- final-combination.txt: ten complete files, 322/322 pass, zero failed/skipped/
  cancelled, 56,334.7375 ms. This was BEFORE adding the actual no-cleanup control.
- staged-retention.txt: actual default restored union plus one local group before
  disposable stage cleanup, 0 pass / 1 FAIL, BNS_CHECKPOINT_PUBLICATION_LIMIT.
- owning-frozen-partial.txt: final full owning file, 51 cases, 50 pass / 1 FAIL,
  zero skipped/cancelled, 43,681.820904 ms. The only failure is the retained
  actual no-cleanup positive, BNS_CHECKPOINT_PUBLICATION_LIMIT.

The first terminal-outbox reviewer reproduction was independently reported as
three uploads and a false confirmed result after deleting a required local outbox
following discovery. The candidate's own repaired controls include after-discovery
outbox/active-pointer/append mutation, after-allocation-before-POST mutation,
after-first-POST mutation, second-Store mutation and real repeated-cut quota
exhaustion. No paused reviewer action or artifact was retried.

## Final combination command

Run from repository root:

    node --test extension/tests/source-union-publication-continuation.test.mjs extension/tests/browser-native-sync-source-bootstrap-union.test.mjs extension/tests/browser-native-sync-source-union-restore.test.mjs extension/tests/source-bootstrap-union-recovery.test.mjs extension/tests/checkpoint-publication.test.mjs extension/tests/source-union-protocol-control-work.test.mjs extension/tests/browser-native-sync-local-recovery.test.mjs extension/tests/browser-native-sync-recovery-negative-tail.test.mjs extension/tests/browser-native-sync-recovery-causal-tail.test.mjs extension/tests/source-purge-checkpoint-publication.test.mjs

At that invocation the new owning file had 50 cases; it now has 51 because the
actual no-cleanup control was added afterward. Do not call the current full set
green based on the earlier 322-case subset.

Syntax checks passed for all four changed runtime modules and the owning file.
Source/test/document diff whitespace checks passed. The complete evidence diff
has two trailing-whitespace notices at terminal-second.txt lines 20 and 89; those
raw failed-test outputs remain unmodified. Original helper identity was checked
against the exact base.

## Required next work

1. Obtain independent review of the publication-only proof, immutable retained cut,
   exact transport-control exceptions and actual accounting/dispatch composition.
2. Fix the actual default no-cleanup resource failure through reviewed original
   stage/cleanup ownership, without accepting arbitrary staged subsets, altering
   sourceCut, weakening final checks or changing budgets.
3. Rerun the unchanged actual-path positive, complete owning file and affected
   combination on the reviewed corrected source. Existing red identities remain.

A native browser, actual provider, Full, 129-group/100k, automatic lifecycle,
real account, paid operation, installation or deployment was not run. All prior
product failures and outstanding qualification gates remain unchanged.
