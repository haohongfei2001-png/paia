# PAIA website V2 review / 官网 V2 设计审阅

Open START.html in a desktop browser. The four HTML prototypes also work when opened directly, without a server. All data is fictional and page-local; reload resets it. Do not enter private information. Copying requires an explicit user action and may be denied by a browser's local-file policy; insertion remains available.

打开 START.html，或直接打开四份原型。它们无需安装扩展、填写邮箱或连接 AI。先在首页主题中选“复用这句”，核对后填入草稿，再观察论点与证据边界的演示提示；再去完整 Demo 体验来源、编辑、主题和权限。复制功能可能受本地文件权限限制，不会谎报成功。

No font files are included. Offline HTML uses system fallbacks, so text wrapping can differ slightly from the actual site's fonts. The screenshots show the actual repository build. Beta/status/legal links deliberately open the unchanged public site; these prototypes are not deployed, not extension installers and not a promise of live AI/Pro/cloud availability.

没有合并或部署授权；请在审阅 PR 后明确决定。测试是工程及模拟交互验证，不是消费者研究或留存证明。
